
#define  AppOK          0      
#define  AppError001    101    
#define  AppError002    102    
#define  AppError003    103    
#define  AppError004    1      
#define  AppError005    2      
#define  AppError006    3      
#define  AppError007    4      

 