//---------------------------------------------------------------------------
#ifndef MyApiUnitH
#define MyApiUnitH
//---------------------------------------------------------------------------
void MyDelay(DWORD msec);
BOOL WeAreAlone (LPSTR szName);
bool OsTypeNT();
#endif
