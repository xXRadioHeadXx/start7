//---------------------------------------------------------------------------
#ifndef MainUnitH
#define MainUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ImgList.hpp>
#include <Menus.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
#include <jpeg.hpp>
#include "TOhrObjUnit.h"
#include "TRifSysUnit.h"
#include "TGobiSysUnit.h"
#include <Graphics.hpp>
#include "TSotaSysUnit.h"
//---------------------------------------------------------------------------
class TMainForm : public TForm
{
__published:	// IDE-managed Components
   TStatusBar *StatusBar1;
   TPanel *Panel1;
   TImage *Image1;
   TTimer *CfgTimer;
   TImageList *ImageList1;
   TImage *Image;
   TShape *Shape1;
   void __fastcall FormCreate(TObject *Sender);
   void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
   void __fastcall ImageMouseDown(TObject *Sender, TMouseButton Button,
          TShiftState Shift, int X, int Y);
   void __fastcall ImageMouseMove(TObject *Sender, TShiftState Shift, int X,
          int Y);
   void __fastcall ImageMouseUp(TObject *Sender, TMouseButton Button,
          TShiftState Shift, int X, int Y);
   void __fastcall CfgTimerTimer(TObject *Sender);
   void __fastcall Panel1Resize(TObject *Sender);
private:	// User declarations
public:		// User declarations
   __fastcall TMainForm(TComponent* Owner);

   HANDLE hMapCfg, hMapPlan, hMapOpros;
   LPVOID lpMapCfg, lpMapPlan, lpMapOpros;

   AnsiString VersionInfoStr;
   AnsiString PlanPath;
   AnsiString IconPath;

   bool LoadLocalConfig( AnsiString fp );
   bool SaveLocalConfig( AnsiString fp );

   TOutObj* CfgObj;

   TImage *imgOld;
   AnsiString imgNameOld;

   bool LoadGlobalConfig( AnsiString fp );

   TSsoiSys *SsoiSys;
   int SsoiVersion;
   TRifSys *RifSys;

   int Count;
   bool IconsVisible;

   double dX, dY;
   int iW, iH;
   bool Resize;
};
//---------------------------------------------------------------------------
extern PACKAGE TMainForm *MainForm;
//---------------------------------------------------------------------------
#endif
