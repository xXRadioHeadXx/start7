//---------------------------------------------------------------------------
#ifndef TOhrObjUnitH
#define TOhrObjUnitH
#include "TRifSysUnit.h"
#include "TSotaSysUnit.h"
#include "TGobiSysUnit.h"
//---------------------------------------------------------------------------
struct TOutObj
{
   bool CfgMode;
   char PlanPath[500];
   int FileOperationId;

   int ImgOperationId;
   char ObjName[500];
   char ImgName[500];
   int ImgNum;
   char ImgPath[500];
   int ImgLeft;
   int ImgTop;
   bool IconVisible;
   char ParentName[500];

   bool AlarmResetFlag;

   TOutObj();
};
typedef TOutObj* POutObj;
//---------------------------------------------------------------------------
struct TOprosOutObj
{
   bool OprosMode;
   char PlanPath[500];

   bool AlarmResetFlag;

   int RifRk[RifKanCnt][RifDevCnt*MaxInCnt];

   int GobiSd[KanCnt*BlCnt*SdCnt];
   int GobiIu[KanCnt*BlCnt*IuCnt];
   int GobiVk[KanCnt*BlCnt*IuCnt];

   int TochkaM[RifKanCnt][MaxTochkaMUchCnt];

   bool IconVisible;
   int X, Y;

   TOprosOutObj();
};
typedef TOprosOutObj* POprosOutObj;
//---------------------------------------------------------------------------
#endif
