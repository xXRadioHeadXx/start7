//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "TGobiSysUnit.h"
#include "MainUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
TGobiSd::TGobiSd()
{
   Reset();
}
//---------------------------------------------------------------------------
void TGobiSd::Reset()
{
   Use = false;
   Status = 0;
   Bazalt = false;
   ConnectBlock = false;
   AlarmFlag = false;

   for( int i = 0; i < 8; i++ ) { IconNum[i] = -1; IconPath[i] = ""; }
}
//---------------------------------------------------------------------------
TGobiBl::TGobiBl()
{
   Reset();
}
//---------------------------------------------------------------------------
void TGobiBl::Reset()
{
   Use = false;

   for( int sd = 0; sd < SdCnt; sd++ ) Sd[sd].Reset();
   for( int iu = 0; iu < IuCnt; iu++ ) { Iu[iu].Reset(); Vk[iu].Reset(); }  
}
//---------------------------------------------------------------------------
TGobiKanal::TGobiKanal()
{
   Reset();
}
//---------------------------------------------------------------------------
void TGobiKanal::Reset()
{
   Use = false;

   for( int bl = 0; bl < BlCnt; bl++ ) Bl[bl].Reset();
}
//---------------------------------------------------------------------------
TSsoiSys::TSsoiSys()
{
   Reset();
}
//---------------------------------------------------------------------------
void TSsoiSys::Reset()
{
   Use = false;

   for( int kan = 0; kan < KanCnt; kan++ ) Kanal[kan].Reset();
}
//---------------------------------------------------------------------------

