//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "TRifSysUnit.h"
#include "MainUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
TDd::TDd()
{
   Reset();
}
//---------------------------------------------------------------------------
void TDd::Reset()
{
   Use = false;
   Status = 0;
   Bazalt = false;
   AlarmFlag = false;

   for( int i = 0; i < 8; i++ ) { IconNum[i] = -1; IconPath[i] = ""; }
}
//---------------------------------------------------------------------------
TRif_KoncentratorDev::TRif_KoncentratorDev()
{
   Reset();
}
//---------------------------------------------------------------------------
void TRif_KoncentratorDev::Reset()
{
   Use = false;
   Type = 0;

   for( int in = 0; in < MaxInCnt; in++ ) In[in].Reset();
}
//---------------------------------------------------------------------------
TRifSys::TRifSys()
{
   Reset();
}
//---------------------------------------------------------------------------
void TRifSys::Reset()
{
   Use = false;

   for( int kan = 0; kan < RifKanCnt; kan++ )
      for( int dev = 0; dev < RifDevCnt; dev++ )
         Rk[kan][dev].Reset();
}
//---------------------------------------------------------------------------

