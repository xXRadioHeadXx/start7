//---------------------------------------------------------------------------
#ifndef TGobiSysUnitH
#define TGobiSysUnitH
//---------------------------------------------------------------------------
class TGobiSd
{
public:
   bool Use;

   int Status;       


   bool AlarmFlag;

   int IconNum[8];
   AnsiString IconPath[8];

   bool Bazalt;
   bool ConnectBlock;

   TGobiSd();
   void Reset();
};
//---------------------------------------------------------------------------
#define SdCnt 9
#define IuCnt 3
class TGobiBl
{
public:
   bool Use;

   TGobiSd Sd[SdCnt];
   TGobiSd Iu[IuCnt];
   TGobiSd Vk[IuCnt];

   TGobiBl();
   void Reset();
};
//---------------------------------------------------------------------------
#define BlCnt 128
class TGobiKanal
{
public:
   bool Use;

   TGobiBl Bl[BlCnt];

   TGobiKanal();
   void Reset();
};
//---------------------------------------------------------------------------
#define KanCnt 4
#define MaxErrCnt1 5
class TSsoiSys
{
public:
   bool Use;

   TGobiKanal Kanal[KanCnt];

   TSsoiSys();
   void Reset();
};
//---------------------------------------------------------------------------
#endif
