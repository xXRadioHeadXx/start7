//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "MyApiUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma warn -aus
//---------------------------------------------------------------------------
void MyDelay(DWORD msec)
{
   DWORD start = 0, finish = 0, test = 0;
   start = GetTickCount();
   for(;;)
   {
      test = GetTickCount();
      finish = test - start;
      if( finish > msec ) break;
   }
}
//---------------------------------------------------------------------------
BOOL WeAreAlone (LPSTR szName)
{
   HANDLE hMutex = CreateMutex (NULL, TRUE, szName);
   if (GetLastError() == ERROR_ALREADY_EXISTS)
   {
      CloseHandle(hMutex);
      return FALSE;
   }
   return TRUE;
}
bool OsTypeNT()
{
        OSVERSIONINFO vi;

        vi.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
        GetVersionEx(&vi);
        if (vi.dwPlatformId==VER_PLATFORM_WIN32_NT)
        return true;

        return false;
}
//---------------------------------------------------------------------------

