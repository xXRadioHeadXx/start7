   //---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "TOhrObjUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
TOutObj::TOutObj()
{
   CfgMode = false;
   memset(PlanPath,0,500);
   FileOperationId = 0;

   ImgOperationId = 0;
   memset(ObjName,0,500);
   memset(ImgName,0,500);
   ImgNum = -1;
   memset(ImgPath,0,500);
   ImgLeft = 0;
   ImgTop = 0;
   IconVisible = false;
   memset(ParentName,0,500);

   AlarmResetFlag = false;
}
//---------------------------------------------------------------------------
TOprosOutObj::TOprosOutObj()
{
   OprosMode = false;

   AlarmResetFlag = false;

   for( int kan = 0; kan < RifKanCnt; kan++ )
   for( int i = 0; i < RifDevCnt*MaxInCnt; i++ )
   {
      RifRk[kan][i] = 0;
   }

   for( int i = 0; i < KanCnt*BlCnt*SdCnt; i++ )
   {
      GobiSd[i] = 0;
   }

   for( int i = 0; i < KanCnt*BlCnt*IuCnt; i++ )
   {
      GobiIu[i] = 0;
      GobiVk[i] = 0;
   }

   for( int kan = 0; kan < RifKanCnt; kan++ )
   for( int i = 0; i < MaxTochkaMUchCnt; i++ )
   {
      TochkaM[kan][i] = 0;
   }

   IconVisible = false;
   X = 0;
   Y = 0;
}
//---------------------------------------------------------------------------

