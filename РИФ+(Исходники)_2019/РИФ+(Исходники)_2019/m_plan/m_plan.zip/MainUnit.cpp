//---------------------------------------------------------------------------
#include <vcl.h>
#include <IniFiles.hpp>
#include <jpeg.hpp>
#include <stdio.h>
#pragma hdrstop

#include "MainUnit.h"
#include "TAdmAuditUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TMainForm *MainForm;
//---------------------------------------------------------------------------
__fastcall TMainForm::TMainForm(TComponent* Owner)
   : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::FormCreate(TObject *Sender)
{
   VersionInfoStr = "r.12.11.2019";

   MainForm->DoubleBuffered = true;
   Panel1->DoubleBuffered = true;

   if( FileExists(ExtractFilePath(Application->ExeName) +"m_plan.ini") )
   {
      LoadLocalConfig(ExtractFilePath(Application->ExeName) +"m_plan.ini");
   }
   else
   {
      MainForm->WindowState = wsMaximized;
      Left = Screen->Monitors[0]->Left;
   }

   HANDLE hFile = INVALID_HANDLE_VALUE;
   hMapCfg = CreateFileMapping(hFile, NULL, PAGE_READWRITE, 0, sizeof(TOutObj), "CfgMappingObject");
   if( hMapCfg != NULL )
   {
     lpMapCfg = MapViewOfFile(hMapCfg, FILE_MAP_READ, 0, 0, 0);
     if( lpMapCfg == NULL )
     {
        MessageBox (NULL, "������ ��������� ������!", "������", MB_OK|MB_ICONERROR);
        Application->Terminate();
     }
   }
   else
   {
      MessageBox (NULL, "������ ��������� ������!", "������", MB_OK|MB_ICONERROR);
      Application->Terminate();
   }

   hMapPlan = CreateFileMapping(hFile, NULL, PAGE_READWRITE, 0, sizeof(TOutObj), "PlanMappingObject");
   if( hMapPlan != NULL )
   {
     lpMapPlan = MapViewOfFile(hMapPlan, FILE_MAP_WRITE, 0, 0, 0);
     if( lpMapPlan == NULL )
     {
        MessageBox (NULL, "������ ��������� ������!", "������", MB_OK|MB_ICONERROR);
        Application->Terminate();
     }
   }
   else
   {
      MessageBox (NULL, "������ ��������� ������!", "������", MB_OK|MB_ICONERROR);
      Application->Terminate();
   }

   hMapOpros = CreateFileMapping(hFile, NULL, PAGE_READWRITE, 0, sizeof(TOprosOutObj), "OprosMappingObject");
   if( hMapOpros != NULL )
   {
     lpMapOpros = MapViewOfFile(hMapOpros, FILE_MAP_READ, 0, 0, 0);
     if( lpMapOpros == NULL )
     {
        MessageBox (NULL, "������ ��������� ������!", "������", MB_OK|MB_ICONERROR);
        Application->Terminate();
     }
   }
   else
   {
      MessageBox (NULL, "������ ��������� ������!", "������", MB_OK|MB_ICONERROR);
      Application->Terminate();
   }

   CfgObj = new TOutObj;

   imgOld = new TImage(MainForm);


   if( POprosOutObj(lpMapOpros)->OprosMode )
   {
      MainForm->BorderStyle = bsSingle;

      TBorderIcons tempBI = BorderIcons;
      tempBI >> biMaximize;
      BorderIcons = tempBI;

      if( FileExists(POprosOutObj(lpMapOpros)->PlanPath) )
      {
         Image1->Picture->Bitmap->Dormant();
         Image1->Picture->Bitmap->FreeImage();
         Image1->Update();

         Image1->Picture->LoadFromFile(POprosOutObj(lpMapOpros)->PlanPath);
         PlanPath = POprosOutObj(lpMapOpros)->PlanPath;
         StatusBar1->Panels->Items[2]->Text = PlanPath;

         Panel1->Constraints->MinWidth = Image1->Picture->Width;
         Panel1->Constraints->MinHeight = Image1->Picture->Height;
      }

      LoadGlobalConfig(ExtractFilePath(Application->ExeName) +"rifx.ini");
   }

   Caption = Caption + " - " + VersionInfoStr;
   CfgTimer->Enabled = true;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::FormClose(TObject *Sender, TCloseAction &Action)
{
   CfgTimer->Enabled = false;

   if( lpMapCfg ) UnmapViewOfFile( lpMapCfg );
   lpMapCfg = 0;

   if( hMapCfg ) CloseHandle( hMapCfg );
   hMapCfg = 0;

   if( lpMapPlan ) UnmapViewOfFile( lpMapPlan );
   lpMapPlan = 0;

   if( hMapPlan ) CloseHandle( hMapPlan );
   hMapPlan = 0;

   if( lpMapOpros ) UnmapViewOfFile( lpMapOpros );
   lpMapOpros = 0;

   if( hMapOpros ) CloseHandle( hMapOpros );
   hMapOpros = 0;

   try
   {
      SaveLocalConfig( ExtractFilePath(Application->ExeName) +"m_plan.ini" );
   }
   catch(...)
   {
      ;
   }

   delete CfgObj;
   delete imgOld;
}
//---------------------------------------------------------------------------
bool TMainForm::LoadLocalConfig( AnsiString fp )
{
   TMemIniFile *ini;
   ini = new TMemIniFile( fp );

   MainForm->Left = ini->ReadInteger( "MAINFORM", "MainFormLeft", -10 );
   MainForm->Top = ini->ReadInteger( "MAINFORM", "MainFormTop", -10 );
   MainForm->Width = ini->ReadInteger( "MAINFORM", "MainFormWidth", 0 );
   MainForm->Height = ini->ReadInteger( "MAINFORM", "MainFormHeight", 0 );

   delete ini;

   return true;
}
//---------------------------------------------------------------------------
bool TMainForm::SaveLocalConfig( AnsiString fp )
{
   TMemIniFile *ini;
   ini = new TMemIniFile( fp );

   ini->WriteInteger( "MAINFORM", "MainFormLeft", MainForm->Left );
   ini->WriteInteger( "MAINFORM", "MainFormTop", MainForm->Top );
   ini->WriteInteger( "MAINFORM", "MainFormWidth", MainForm->Width );
   ini->WriteInteger( "MAINFORM", "MainFormHeight", MainForm->Height );

   ini->UpdateFile();
   delete ini;

   return true;
}
//---------------------------------------------------------------------------
bool blMouseDown = false;
int startXpos, startYpos;
//---------------------------------------------------------------------------
void __fastcall TMainForm::ImageMouseDown(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
   if(Button == mbLeft)
   {
      blMouseDown = true;
      Shape1->Visible  = false;

      TImage *tmpimg = (TImage*)Sender;
      StrCopy( POutObj(lpMapPlan)->ImgName, tmpimg->Name.c_str());
      POutObj(lpMapPlan)->ImgOperationId = 4;

      startXpos = X;
      startYpos = Y;

      if( !Shape1->Visible )
      {
         Shape1->Visible = true;
         Shape1->Left = tmpimg->Left - 3;
         Shape1->Top = tmpimg->Top - 3;
      }
   }
/*
   else if( Button == mbRight )
   {
      startXpos = tmpimg->Left + tmpimg->Width;
      startYpos = tmpimg->Top;
   }
*/
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::ImageMouseMove(TObject *Sender, TShiftState Shift,
      int X, int Y)
{
   if( blMouseDown )
   {
      if( POutObj(lpMapPlan)->CfgMode )
      {
         TImage* tmpimg=dynamic_cast<TImage*>(Sender);
         if (tmpimg==NULL) return;

          tmpimg->Top += Y - startYpos;
          tmpimg->Left += X - startXpos;

          if(tmpimg->Top < 0) tmpimg->Top = 0;
          if(tmpimg->Left < 0) tmpimg->Left = 0;
          if(tmpimg->Top > (Panel1->Height - tmpimg->Height)) tmpimg->Top = (Panel1->Height - tmpimg->Height);
          if(tmpimg->Left > (Panel1->Width - tmpimg->Width)) tmpimg->Left = (Panel1->Width - tmpimg->Width);

          if( Shape1->Visible )
          {
             Shape1->Visible = true;
             Shape1->Left = tmpimg->Left - 3;
             Shape1->Top = tmpimg->Top - 3;
          }
      }
   }
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::ImageMouseUp(TObject *Sender, TMouseButton Button,
      TShiftState Shift, int X, int Y)
{
   TImage *tmpimg = (TImage*)Sender;
   if( POutObj(lpMapCfg)->CfgMode )
   {
      StrCopy( POutObj(lpMapPlan)->ImgName, tmpimg->Name.c_str());
      POutObj(lpMapPlan)->ImgLeft = tmpimg->Left;
      POutObj(lpMapPlan)->ImgTop = tmpimg->Top;
      POutObj(lpMapPlan)->ImgOperationId = 5;
   }
   blMouseDown = false;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::CfgTimerTimer(TObject *Sender)
{
   POutObj(lpMapPlan)->CfgMode = POutObj(lpMapCfg)->CfgMode;

   if( Resize )
   {
       if( dX != 0.00 || dY != 0.00 )
       {
          TImage* tmpimg;
          for( int i = 0; i < MainForm->ComponentCount; i++ )
          {
             if( MainForm->Components[i] != NULL )
             {
                tmpimg = dynamic_cast<TImage*>(MainForm->Components[i]);
                if( tmpimg != NULL )
                {
                   if(tmpimg->Name.Pos("img_") != 0 )
                   {
                      tmpimg->Left = (double)tmpimg->Left*dX;
                      tmpimg->Top = (double)tmpimg->Top*dY;
                   }
                }
             }
          }
       }
       iW = Panel1->Width;
       iH = Panel1->Height;

       Resize = false;
   }


   if( POutObj(lpMapCfg)->CfgMode )
   {
//      if( !blMouseDown )
      {
           if( POutObj(lpMapPlan)->FileOperationId != POutObj(lpMapCfg)->FileOperationId &&
               POutObj(lpMapCfg)->FileOperationId != 0 )
           {
               {
                   for( int i = 0; i < MainForm->ComponentCount; i++ )
                   {
                      if( MainForm->Components[i]->ClassNameIs("TImage") &&
                          MainForm->Components[i]->Name.Pos("img_") != 0 )
                      {
                            delete MainForm->Components[i];
                            i = i - 1;
                      }
                   }
               }

               if( POutObj(lpMapCfg)->FileOperationId == 2 )
               {
                  PlanPath = "";
                  LoadGlobalConfig(ExtractFilePath(Application->ExeName) +"rifx.ini");
               }
           }
           POutObj(lpMapPlan)->FileOperationId = POutObj(lpMapCfg)->FileOperationId;

           if( PlanPath != POutObj(lpMapCfg)->PlanPath )
           {
              if( FileExists(POutObj(lpMapCfg)->PlanPath) )
              {
                 Image1->Picture->Bitmap->Dormant();
                 Image1->Picture->Bitmap->FreeImage();
                 Image1->Update();

                 Image1->Picture->LoadFromFile(POutObj(lpMapCfg)->PlanPath);
                 PlanPath = POutObj(lpMapCfg)->PlanPath;

                 Panel1->Constraints->MinWidth = Image1->Picture->Width;
                 Panel1->Constraints->MinHeight = Image1->Picture->Height;

                 iW = Panel1->Width;
                 iH = Panel1->Height;

                 Panel1Resize(this);
              }
           }
           StatusBar1->Panels->Items[2]->Text = PlanPath;

           if( POutObj(lpMapCfg)->ImgOperationId != POutObj(lpMapPlan)->ImgOperationId &&
               POutObj(lpMapPlan)->ImgOperationId != 4 &&
               POutObj(lpMapPlan)->ImgOperationId != 5 )
           {
              if( POutObj(lpMapCfg)->ImgOperationId == 1 || 
                  POutObj(lpMapCfg)->ImgOperationId == 2 )  
              {
                 if( POutObj(lpMapCfg)->IconVisible )
                 {
                    TImage *tmpImg = (TImage*)FindComponent(POutObj(lpMapCfg)->ImgName);
                    if( tmpImg != NULL ) 
                    {
                       tmpImg->Picture->Bitmap->Dormant();
                       tmpImg->Picture->Bitmap->FreeImage();
                       tmpImg->Update();

                       if( FileExists(POutObj(lpMapCfg)->ImgPath) )
                         tmpImg->Picture->LoadFromFile(POutObj(lpMapCfg)->ImgPath);
                       else
                       {
                           if( POutObj(lpMapCfg)->ImgNum < ImageList1->Count )
                           {
                              if( POutObj(lpMapCfg)->ImgNum < ImageList1->Count )
                                 ImageList1->GetBitmap(POutObj(lpMapCfg)->ImgNum,Image->Picture->Bitmap);
                              else ImageList1->GetBitmap(0,Image->Picture->Bitmap);
                           }
                           else ImageList1->GetBitmap(0,Image->Picture->Bitmap);
                           tmpImg->Picture = Image->Picture;
                       }
                       tmpImg->BringToFront();

                       Shape1->Left = tmpImg->Left-3;
                       Shape1->Top = tmpImg->Top-3;
                       Shape1->Visible = true;
                    }
                    else 
                    {
                       TImage *img;
                       img = new TImage(MainForm);
                       img->Parent = MainForm->Panel1;
                       img->Name = POutObj(lpMapCfg)->ImgName;
                       img->Left = 20;
                       img->Top = 20;

                       if( FileExists(POutObj(lpMapCfg)->ImgPath) )
                          img->Picture->LoadFromFile(POutObj(lpMapCfg)->ImgPath);
                       else
                       {
                          if( POutObj(lpMapCfg)->ImgNum < ImageList1->Count )
                             ImageList1->GetBitmap(POutObj(lpMapCfg)->ImgNum,Image->Picture->Bitmap);
                          else ImageList1->GetBitmap(0,Image->Picture->Bitmap);
                          img->Picture = Image->Picture;
                       }
                       img->AutoSize = true;
                       img->Visible = true;
                       img->OnMouseDown = ImageMouseDown;
                       img->OnMouseMove = ImageMouseMove;
                       img->OnMouseUp = ImageMouseUp;

                       img->BringToFront();

                       Shape1->Left = img->Left-3;
                       Shape1->Top = img->Top-3;
                       Shape1->Visible = true;
                    }
                 }
                 else Shape1->Visible = false;
              }
              else if( POutObj(lpMapCfg)->ImgOperationId == 3 ) 
              {
                 TImage *tmpImg2 = (TImage*)FindComponent(POutObj(lpMapCfg)->ImgName);
                 if( tmpImg2 != NULL ) delete tmpImg2;   

                 Shape1->Visible = false;
              }
              else if( POutObj(lpMapCfg)->ImgOperationId == 8 ) 
              {
                 TImage *tmpImg2 = (TImage*)FindComponent(POutObj(lpMapCfg)->ImgName);
                 if( tmpImg2 != NULL )
                 {
                    tmpImg2->Left = 20;
                    tmpImg2->Top = 20;
                    Shape1->Left = tmpImg2->Left-3;
                    Shape1->Top = tmpImg2->Top-3;
                    Shape1->Visible = true;
                 }
              }

              if( POutObj(lpMapCfg)->ObjName != NULL )
                 StatusBar1->Panels->Items[0]->Text = (AnsiString)POutObj(lpMapCfg)->ObjName;

              POutObj(lpMapPlan)->ImgOperationId = POutObj(lpMapCfg)->ImgOperationId;
           }
           else if( POutObj(lpMapCfg)->ImgOperationId == 6 &&
               (POutObj(lpMapPlan)->ImgOperationId == 4 || POutObj(lpMapPlan)->ImgOperationId == 5) )
           {
              POutObj(lpMapPlan)->ImgOperationId = POutObj(lpMapCfg)->ImgOperationId;
           }
           else
           {
              if( POutObj(lpMapCfg)->ImgOperationId == 7 )
              {
                 TImage *tmpImg2 = (TImage*)FindComponent(POutObj(lpMapCfg)->ImgName);
                 if( tmpImg2 != NULL ) delete tmpImg2;   

                 Shape1->Visible = false;
              }
           }
      }
   }
   else if( POprosOutObj(lpMapOpros)->OprosMode )
   {
      AnsiString ImgName;
      TImage *tmpImg;

      bool AlarmResetFlag = POprosOutObj(lpMapOpros)->AlarmResetFlag;

      if( SsoiSys != NULL )
         if( SsoiSys->Use )
         {
            for( int kan = 0; kan < KanCnt; kan++ )
            {
               if( SsoiSys->Kanal[kan].Use )
               {
                  for( int bl = 0; bl < BlCnt; bl++ )
                  {
                     if( SsoiSys->Kanal[kan].Bl[bl].Use )
                     {
                        for( int sd = 0; sd < SdCnt; sd++ )
                        {
                           if( SsoiSys->Kanal[kan].Bl[bl].Sd[sd].Use )
                           {
                              int status = POprosOutObj(lpMapOpros)->GobiSd[kan*BlCnt*SdCnt+SdCnt*bl+sd];

                              if( SsoiSys->Kanal[kan].Bl[bl].Sd[sd].Status != status ||
                                  (AlarmResetFlag != SsoiSys->Kanal[kan].Bl[bl].Sd[sd].AlarmFlag && AlarmResetFlag)  )
                              {
                                 if( SsoiVersion == 1 ) ImgName.sprintf("img_%d_%d_%d_%d", 3, kan+1, bl+1, sd+1);
                                 else ImgName.sprintf("img_%d_%d_%d_%d", 33, kan+1, bl+1, sd+1);

                                 tmpImg = (TImage*)FindComponent(ImgName);
                                 if( tmpImg != NULL )
                                 {
                                    if( SsoiSys->Kanal[kan].Bl[bl].Sd[sd].Status != status ) SsoiSys->Kanal[kan].Bl[bl].Sd[sd].AlarmFlag = false;

                                    if( AlarmResetFlag ) 
                                    {
                                       tmpImg->Tag = 0;
                                       SsoiSys->Kanal[kan].Bl[bl].Sd[sd].AlarmFlag = true;
                                    }

                                    if( status == 1 && tmpImg->Tag == 0 )  
                                    {
                                       if( !SsoiSys->Kanal[kan].Bl[bl].Sd[sd].Bazalt )
                                       {
                                          if( FileExists(SsoiSys->Kanal[kan].Bl[bl].Sd[sd].IconPath[1]) )
                                          {
                                             tmpImg->Picture->Bitmap->Dormant();
                                             tmpImg->Picture->Bitmap->FreeImage();
                                             tmpImg->Picture->LoadFromFile(SsoiSys->Kanal[kan].Bl[bl].Sd[sd].IconPath[1]);
                                          }
                                          else ImageList1->GetBitmap(SsoiSys->Kanal[kan].Bl[bl].Sd[sd].IconNum[1],tmpImg->Picture->Bitmap);
                                       }
                                       else
                                       {
                                          int statusIu = POprosOutObj(lpMapOpros)->GobiIu[kan*BlCnt*IuCnt+IuCnt*bl+sd];
                                          if( statusIu == 1 )
                                          {
                                             if( FileExists(SsoiSys->Kanal[kan].Bl[bl].Sd[sd].IconPath[2]) )
                                             {
                                                tmpImg->Picture->Bitmap->Dormant();
                                                tmpImg->Picture->Bitmap->FreeImage();
                                                tmpImg->Picture->LoadFromFile(SsoiSys->Kanal[kan].Bl[bl].Sd[sd].IconPath[2]);
                                             }
                                             else ImageList1->GetBitmap(SsoiSys->Kanal[kan].Bl[bl].Sd[sd].IconNum[2],tmpImg->Picture->Bitmap);
                                          }
                                          else if( statusIu == 2 ) 
                                          {
                                             if( FileExists(SsoiSys->Kanal[kan].Bl[bl].Sd[sd].IconPath[0]) )
                                             {
                                                tmpImg->Picture->Bitmap->Dormant();
                                                tmpImg->Picture->Bitmap->FreeImage();
                                                tmpImg->Picture->LoadFromFile(SsoiSys->Kanal[kan].Bl[bl].Sd[sd].IconPath[0]);
                                             }
                                             else ImageList1->GetBitmap(SsoiSys->Kanal[kan].Bl[bl].Sd[sd].IconNum[0],tmpImg->Picture->Bitmap);
                                          }
                                       }
                                    }
                                    else if( status == 10 ) 
                                    {
                                       if( !SsoiSys->Kanal[kan].Bl[bl].Sd[sd].Bazalt )
                                       {
                                          if( FileExists(SsoiSys->Kanal[kan].Bl[bl].Sd[sd].IconPath[3]) )
                                          {
                                             tmpImg->Picture->Bitmap->Dormant();
                                             tmpImg->Picture->Bitmap->FreeImage();
                                             tmpImg->Picture->LoadFromFile(SsoiSys->Kanal[kan].Bl[bl].Sd[sd].IconPath[3]);
                                          }
                                          else ImageList1->GetBitmap(SsoiSys->Kanal[kan].Bl[bl].Sd[sd].IconNum[3],tmpImg->Picture->Bitmap);
                                       }
                                       else
                                       {
                                          if( FileExists(SsoiSys->Kanal[kan].Bl[bl].Sd[sd].IconPath[4]) )
                                          {
                                             tmpImg->Picture->Bitmap->Dormant();
                                             tmpImg->Picture->Bitmap->FreeImage();
                                             tmpImg->Picture->LoadFromFile(SsoiSys->Kanal[kan].Bl[bl].Sd[sd].IconPath[4]);
                                          }
                                          else ImageList1->GetBitmap(SsoiSys->Kanal[kan].Bl[bl].Sd[sd].IconNum[4],tmpImg->Picture->Bitmap);
                                       }

                                       if( !SsoiSys->Kanal[kan].Bl[bl].Sd[sd].AlarmFlag ) tmpImg->Tag = 1;
                                       else tmpImg->Tag = 0;
                                    }
                                    else if( status == 11 || status == 13 ) 
                                    {
                                       if( !SsoiSys->Kanal[kan].Bl[bl].Sd[sd].Bazalt )
                                       {
                                          if( FileExists(SsoiSys->Kanal[kan].Bl[bl].Sd[sd].IconPath[4]) )
                                          {
                                             tmpImg->Picture->Bitmap->Dormant();
                                             tmpImg->Picture->Bitmap->FreeImage();
                                             tmpImg->Picture->LoadFromFile(SsoiSys->Kanal[kan].Bl[bl].Sd[sd].IconPath[4]);
                                          }
                                          else ImageList1->GetBitmap(SsoiSys->Kanal[kan].Bl[bl].Sd[sd].IconNum[4],tmpImg->Picture->Bitmap);
                                       }
                                       else
                                       {
                                          if( FileExists(SsoiSys->Kanal[kan].Bl[bl].Sd[sd].IconPath[5]) )
                                          {
                                             tmpImg->Picture->Bitmap->Dormant();
                                             tmpImg->Picture->Bitmap->FreeImage();
                                             tmpImg->Picture->LoadFromFile(SsoiSys->Kanal[kan].Bl[bl].Sd[sd].IconPath[5]);
                                          }
                                          else ImageList1->GetBitmap(SsoiSys->Kanal[kan].Bl[bl].Sd[sd].IconNum[5],tmpImg->Picture->Bitmap);
                                       }

                                       if( !SsoiSys->Kanal[kan].Bl[bl].Sd[sd].AlarmFlag ) tmpImg->Tag = 1;
                                       else tmpImg->Tag = 0;
                                    }
                                    else if( status == 21 ) 
                                    {
                                      if( !SsoiSys->Kanal[kan].Bl[bl].Sd[sd].Bazalt )
                                      {
                                         if( FileExists(SsoiSys->Kanal[kan].Bl[bl].Sd[sd].IconPath[2]) )
                                         {
                                            tmpImg->Picture->Bitmap->Dormant();
                                            tmpImg->Picture->Bitmap->FreeImage();
                                            tmpImg->Picture->LoadFromFile(SsoiSys->Kanal[kan].Bl[bl].Sd[sd].IconPath[2]);
                                         }
                                         else ImageList1->GetBitmap(SsoiSys->Kanal[kan].Bl[bl].Sd[sd].IconNum[2],tmpImg->Picture->Bitmap);

                                         if( !SsoiSys->Kanal[kan].Bl[bl].Sd[sd].AlarmFlag ) tmpImg->Tag = 1;
                                         else tmpImg->Tag = 0;
                                      }
                                      else
                                      {
                                         int statusIu = POprosOutObj(lpMapOpros)->GobiIu[kan*BlCnt*IuCnt+IuCnt*bl+sd];
                                         if( statusIu == 1 ) 
                                         {
                                            if( FileExists(SsoiSys->Kanal[kan].Bl[bl].Sd[sd].IconPath[1]) )
                                            {
                                               tmpImg->Picture->Bitmap->Dormant();
                                               tmpImg->Picture->Bitmap->FreeImage();
                                               tmpImg->Picture->LoadFromFile(SsoiSys->Kanal[kan].Bl[bl].Sd[sd].IconPath[1]);
                                            }
                                            else ImageList1->GetBitmap(SsoiSys->Kanal[kan].Bl[bl].Sd[sd].IconNum[1],tmpImg->Picture->Bitmap);
                                         }
                                         else if( statusIu == 2 )
                                         {
                                            if( FileExists(SsoiSys->Kanal[kan].Bl[bl].Sd[sd].IconPath[3]) )
                                            {
                                               tmpImg->Picture->Bitmap->Dormant();
                                               tmpImg->Picture->Bitmap->FreeImage();
                                               tmpImg->Picture->LoadFromFile(SsoiSys->Kanal[kan].Bl[bl].Sd[sd].IconPath[3]);
                                            }
                                            else ImageList1->GetBitmap(SsoiSys->Kanal[kan].Bl[bl].Sd[sd].IconNum[3],tmpImg->Picture->Bitmap);
                                         }
                                      }
                                    }
                                    else if( status == 20 ) 
                                    {
                                      if( !SsoiSys->Kanal[kan].Bl[bl].Sd[sd].Bazalt )
                                      {
                                         if( FileExists(SsoiSys->Kanal[kan].Bl[bl].Sd[sd].IconPath[2]) )
                                         {
                                            tmpImg->Picture->Bitmap->Dormant();
                                            tmpImg->Picture->Bitmap->FreeImage();
                                            tmpImg->Picture->LoadFromFile(SsoiSys->Kanal[kan].Bl[bl].Sd[sd].IconPath[2]);
                                         }
                                         else ImageList1->GetBitmap(SsoiSys->Kanal[kan].Bl[bl].Sd[sd].IconNum[2],tmpImg->Picture->Bitmap);

                                         if( !SsoiSys->Kanal[kan].Bl[bl].Sd[sd].AlarmFlag ) tmpImg->Tag = 1;
                                         else tmpImg->Tag = 0;
                                      }
                                    }
                                    else if( status == 136 ) 
                                    {
                                       if( FileExists(SsoiSys->Kanal[kan].Bl[bl].Sd[sd].IconPath[0]) )
                                          tmpImg->Picture->LoadFromFile(SsoiSys->Kanal[kan].Bl[bl].Sd[sd].IconPath[0]);
                                       else ImageList1->GetBitmap(SsoiSys->Kanal[kan].Bl[bl].Sd[sd].IconNum[0],tmpImg->Picture->Bitmap);

                                       tmpImg->Tag = 0;
                                    }

                                    tmpImg->Refresh();

                                    SsoiSys->Kanal[kan].Bl[bl].Sd[sd].Status = status;
                                 }
                              }
                           }
                        }

                        for( int iu = 0; iu < IuCnt; iu++ )
                        {
                            if( SsoiSys->Kanal[kan].Bl[bl].Iu[iu].Use )
                            {
                               int status = POprosOutObj(lpMapOpros)->GobiIu[kan*BlCnt*IuCnt+IuCnt*bl+iu];

                               if( SsoiSys->Kanal[kan].Bl[bl].Iu[iu].Status != status ||
                                   (AlarmResetFlag != SsoiSys->Kanal[kan].Bl[bl].Iu[iu].AlarmFlag && AlarmResetFlag ) )
                               {
                                  if( SsoiVersion == 1 )  ImgName.sprintf("img_%d_%d_%d_%d", 4, kan+1, bl+1, iu+1);
                                  else ImgName.sprintf("img_%d_%d_%d_%d", 43, kan+1, bl+1, iu+1);

                                  tmpImg = (TImage*)FindComponent(ImgName);
                                  if( tmpImg != NULL )
                                  {
                                      SsoiSys->Kanal[kan].Bl[bl].Iu[iu].AlarmFlag = false;

                                      if( AlarmResetFlag )  
                                      {
                                         tmpImg->Tag = 0;
                                         SsoiSys->Kanal[kan].Bl[bl].Iu[iu].AlarmFlag = true;
                                      }

                                      if( status == 10 ) 
                                      {
                                         if( FileExists(SsoiSys->Kanal[kan].Bl[bl].Iu[iu].IconPath[3]) )
                                         {
                                            tmpImg->Picture->Bitmap->Dormant();
                                            tmpImg->Picture->Bitmap->FreeImage();
                                            tmpImg->Picture->LoadFromFile(SsoiSys->Kanal[kan].Bl[bl].Iu[iu].IconPath[3]);
                                         }
                                         else ImageList1->GetBitmap(SsoiSys->Kanal[kan].Bl[bl].Iu[iu].IconNum[3],tmpImg->Picture->Bitmap);

                                         if( !SsoiSys->Kanal[kan].Bl[bl].Iu[iu].AlarmFlag ) tmpImg->Tag = 1;
                                         else tmpImg->Tag = 0;
                                      }
                                      else if( status == 1 ) 
                                      {
                                         if( FileExists(SsoiSys->Kanal[kan].Bl[bl].Iu[iu].IconPath[1]) )
                                         {
                                              tmpImg->Picture->Bitmap->Dormant();
                                              tmpImg->Picture->Bitmap->FreeImage();
                                              tmpImg->Picture->LoadFromFile(SsoiSys->Kanal[kan].Bl[bl].Iu[iu].IconPath[1]);
                                         }
                                         else ImageList1->GetBitmap(SsoiSys->Kanal[kan].Bl[bl].Iu[iu].IconNum[1],tmpImg->Picture->Bitmap);

                                         tmpImg->Tag = 0;
                                      }
                                      else if( status == 2 ) 
                                      {
                                         if( FileExists(SsoiSys->Kanal[kan].Bl[bl].Iu[iu].IconPath[2]) )
                                         {
                                              tmpImg->Picture->Bitmap->Dormant();
                                              tmpImg->Picture->Bitmap->FreeImage();
                                              tmpImg->Picture->LoadFromFile(SsoiSys->Kanal[kan].Bl[bl].Iu[iu].IconPath[2]);
                                         }
                                         else ImageList1->GetBitmap(SsoiSys->Kanal[kan].Bl[bl].Iu[iu].IconNum[2],tmpImg->Picture->Bitmap);

                                         tmpImg->Tag = 0;
                                      }
                                      tmpImg->Refresh();

                                      SsoiSys->Kanal[kan].Bl[bl].Iu[iu].Status = status;
                                  }
                               }
                            }

                            if( SsoiSys->Kanal[kan].Bl[bl].Vk[iu].Use )
                            {
                               int status = POprosOutObj(lpMapOpros)->GobiVk[kan*BlCnt*IuCnt+IuCnt*bl+iu];

                               if( SsoiSys->Kanal[kan].Bl[bl].Vk[iu].Status != status ||
                                  (AlarmResetFlag != SsoiSys->Kanal[kan].Bl[bl].Vk[iu].AlarmFlag && AlarmResetFlag) )
                               {
                                  if( SsoiVersion == 1 )  ImgName.sprintf("img_%d_%d_%d_%d", 4, kan+1, bl+1, iu+1);
                                  else ImgName.sprintf("img_%d_%d_%d_%d", 44, kan+1, bl+1, iu+1);

                                  tmpImg = (TImage*)FindComponent(ImgName);
                                  if( tmpImg != NULL )
                                  {
                                      SsoiSys->Kanal[kan].Bl[bl].Vk[iu].AlarmFlag = false;

                                      if( AlarmResetFlag ) 
                                      {
                                         tmpImg->Tag = 0;
                                         SsoiSys->Kanal[kan].Bl[bl].Vk[iu].AlarmFlag = true;
                                      }

                                      if( status == 10 )  
                                      {
                                         if( FileExists(SsoiSys->Kanal[kan].Bl[bl].Vk[iu].IconPath[3]) )
                                         {
                                            tmpImg->Picture->Bitmap->Dormant();
                                            tmpImg->Picture->Bitmap->FreeImage();
                                            tmpImg->Picture->LoadFromFile(SsoiSys->Kanal[kan].Bl[bl].Vk[iu].IconPath[3]);
                                         }
                                         else ImageList1->GetBitmap(SsoiSys->Kanal[kan].Bl[bl].Vk[iu].IconNum[3],tmpImg->Picture->Bitmap);

                                         if( !SsoiSys->Kanal[kan].Bl[bl].Vk[iu].AlarmFlag ) tmpImg->Tag = 1;
                                         else tmpImg->Tag = 0;
                                      }
                                      else if( status == 1 ) 
                                      {
                                         if( FileExists(SsoiSys->Kanal[kan].Bl[bl].Vk[iu].IconPath[1]) )
                                         {
                                              tmpImg->Picture->Bitmap->Dormant();
                                              tmpImg->Picture->Bitmap->FreeImage();
                                              tmpImg->Picture->LoadFromFile(SsoiSys->Kanal[kan].Bl[bl].Vk[iu].IconPath[1]);
                                         }
                                         else ImageList1->GetBitmap(SsoiSys->Kanal[kan].Bl[bl].Vk[iu].IconNum[1],tmpImg->Picture->Bitmap);

                                         tmpImg->Tag = 0;
                                      }
                                      else if( status == 2 )
                                      {
                                         if( FileExists(SsoiSys->Kanal[kan].Bl[bl].Vk[iu].IconPath[2]) )
                                         {
                                              tmpImg->Picture->Bitmap->Dormant();
                                              tmpImg->Picture->Bitmap->FreeImage();
                                              tmpImg->Picture->LoadFromFile(SsoiSys->Kanal[kan].Bl[bl].Vk[iu].IconPath[2]);
                                         }
                                         else ImageList1->GetBitmap(SsoiSys->Kanal[kan].Bl[bl].Vk[iu].IconNum[2],tmpImg->Picture->Bitmap);

                                         tmpImg->Tag = 0;
                                      }
                                      tmpImg->Refresh();

                                      SsoiSys->Kanal[kan].Bl[bl].Vk[iu].Status = status;
                                  }
                               }
                            }
                        }
                     }
                  }
               }
            }
         }

      if( RifSys != NULL )
         if( RifSys->Use )
         {
            for( int kan = 0; kan < RifKanCnt; kan++ )
            for( int dev = 0; dev < RifDevCnt; dev++ )
            {
               if( RifSys->Rk[kan][dev].Use )
               {
                  for( int in = 0; in < MaxInCnt; in++ )
                  {
                     if( RifSys->Rk[kan][dev].In[in].Use )
                     {
                        int status = POprosOutObj(lpMapOpros)->RifRk[kan][dev*MaxInCnt+in];
                        if( (RifSys->Rk[kan][dev].Type == 26 || RifSys->Rk[kan][dev].Type == 29) && in > 0 ) status = POprosOutObj(lpMapOpros)->TochkaM[kan][in-1];

                        if( RifSys->Rk[kan][dev].In[in].Status != status )
                        {
                           if( RifSys->Rk[kan][dev].Type == 11 )
                           {
                              if( in < 8 ) ImgName.sprintf("img_%d_%d_%d_%d", RifSys->Rk[kan][dev].Type, 255, in+1, kan+1);
                              else ImgName.sprintf("img_%d_%d_%d_%d", RifSys->Rk[kan][dev].Type+1, 255, in+1-8, kan+1);
                           }
                           else if( RifSys->Rk[kan][dev].Type == 1 || RifSys->Rk[kan][dev].Type == 111 ) ImgName.sprintf("img_%d_%d_%d_%d", RifSys->Rk[kan][dev].Type, dev+1, in, kan+1);
                           else if( RifSys->Rk[kan][dev].Type == 10 ) ImgName.sprintf("img_%d_%d_%d_%d", RifSys->Rk[kan][dev].Type, dev+1, in+1, kan+1);
                           else if( RifSys->Rk[kan][dev].Type == 26 )
                           {
                              if( in == 0 ) ImgName.sprintf("img_%d_%d_%d_%d", RifSys->Rk[kan][dev].Type, dev+1, in, kan+1);
                              else ImgName.sprintf("img_%d_%d_%d_%d", RifSys->Rk[kan][dev].Type+1, dev+1, in*100, kan+1);
                           }
                           else if( RifSys->Rk[kan][dev].Type == 29 )
                           {
                              if( in == 0 ) ImgName.sprintf("img_%d_%d_%d_%d", RifSys->Rk[kan][dev].Type, dev+1, in, kan+1);
                              else ImgName.sprintf("img_%d_%d_%d_%d", RifSys->Rk[kan][dev].Type+1, dev+1, in*100, kan+1);
                           }
                           else ImgName.sprintf("img_%d_%d_%d_%d", RifSys->Rk[kan][dev].Type, dev+1, in, kan+1);

                           tmpImg = (TImage*)FindComponent(ImgName);
                           if( tmpImg != NULL )
                           {
                              if( AlarmResetFlag )  
                                    tmpImg->Tag = 0;

                              if( status == 1 && tmpImg->Tag == 0 )
                              {
                                 if( !RifSys->Rk[kan][dev].In[in].Bazalt )
                                 {
                                    if( FileExists(RifSys->Rk[kan][dev].In[in].IconPath[1]) )
                                       tmpImg->Picture->LoadFromFile(RifSys->Rk[kan][dev].In[in].IconPath[1]);
                                    else ImageList1->GetBitmap(RifSys->Rk[kan][dev].In[in].IconNum[1],tmpImg->Picture->Bitmap);
                                 }
                                 else
                                 {
                                    int statusIu = POprosOutObj(lpMapOpros)->RifRk[kan][dev*MaxInCnt+in+8];
                                    if( statusIu == 100 )
                                    {
                                       if( FileExists(RifSys->Rk[kan][dev].In[in].IconPath[3]) )
                                          tmpImg->Picture->LoadFromFile(RifSys->Rk[kan][dev].In[in].IconPath[3]);
                                       else ImageList1->GetBitmap(RifSys->Rk[kan][dev].In[in].IconNum[3],tmpImg->Picture->Bitmap);
                                    }
                                    else if( statusIu == 101 )
                                    {
                                       if( FileExists(RifSys->Rk[kan][dev].In[in].IconPath[1]) )
                                          tmpImg->Picture->LoadFromFile(RifSys->Rk[kan][dev].In[in].IconPath[1]);
                                       else ImageList1->GetBitmap(RifSys->Rk[kan][dev].In[in].IconNum[1],tmpImg->Picture->Bitmap);
                                    }
                                 }

                                 RifSys->Rk[kan][dev].In[in].Status = status;
                              }
                              else if( status == 10 )  
                              {
                                 if( !RifSys->Rk[kan][dev].In[in].Bazalt )
                                 {
                                    if( FileExists(RifSys->Rk[kan][dev].In[in].IconPath[3]) )
                                       tmpImg->Picture->LoadFromFile(RifSys->Rk[kan][dev].In[in].IconPath[3]);
                                    else ImageList1->GetBitmap(RifSys->Rk[kan][dev].In[in].IconNum[3],tmpImg->Picture->Bitmap);
                                 }
                                 else
                                 {
                                    if( FileExists(RifSys->Rk[kan][dev].In[in].IconPath[5]) )
                                       tmpImg->Picture->LoadFromFile(RifSys->Rk[kan][dev].In[in].IconPath[5]);
                                    else ImageList1->GetBitmap(RifSys->Rk[kan][dev].In[in].IconNum[5],tmpImg->Picture->Bitmap);
                                 }

                                 tmpImg->Tag = 1;

                                 RifSys->Rk[kan][dev].In[in].Status = status;
                              }
                              else if( status == 21 && tmpImg->Tag == 0 ) 
                              {
                                 if( !RifSys->Rk[kan][dev].In[in].Bazalt )
                                 {
                                    if( FileExists(RifSys->Rk[kan][dev].In[in].IconPath[2]) )
                                       tmpImg->Picture->LoadFromFile(RifSys->Rk[kan][dev].In[in].IconPath[2]);
                                    else ImageList1->GetBitmap(RifSys->Rk[kan][dev].In[in].IconNum[2],tmpImg->Picture->Bitmap);

                                    tmpImg->Tag = 1;
                                 }
                                 else
                                 {
                                    int statusIu = POprosOutObj(lpMapOpros)->RifRk[kan][dev*MaxInCnt+in+8];
                                    if( statusIu == 100 ) 
                                    {
                                       if( FileExists(RifSys->Rk[kan][dev].In[in].IconPath[2]) )
                                          tmpImg->Picture->LoadFromFile(RifSys->Rk[kan][dev].In[in].IconPath[2]);
                                       else ImageList1->GetBitmap(RifSys->Rk[kan][dev].In[in].IconNum[2],tmpImg->Picture->Bitmap);
                                    }
                                    else if( statusIu == 101 )
                                    {
                                       if( FileExists(RifSys->Rk[kan][dev].In[in].IconPath[4]) )
                                          tmpImg->Picture->LoadFromFile(RifSys->Rk[kan][dev].In[in].IconPath[4]);
                                       else ImageList1->GetBitmap(RifSys->Rk[kan][dev].In[in].IconNum[4],tmpImg->Picture->Bitmap);
                                    }
                                 }

                                 RifSys->Rk[kan][dev].In[in].Status = status;
                              }
                              else if( status == 20 && tmpImg->Tag == 0 ) 
                              {
                                 if( !RifSys->Rk[kan][dev].In[in].Bazalt )
                                 {
                                    if( FileExists(RifSys->Rk[kan][dev].In[in].IconPath[2]) )
                                       tmpImg->Picture->LoadFromFile(RifSys->Rk[kan][dev].In[in].IconPath[2]);
                                    else ImageList1->GetBitmap(RifSys->Rk[kan][dev].In[in].IconNum[2],tmpImg->Picture->Bitmap);

                                    tmpImg->Tag = 1;
                                 }
                                 else
                                 {
                                    int statusIu = POprosOutObj(lpMapOpros)->RifRk[kan][dev*MaxInCnt+in+8];
                                    if( statusIu == 100 ) 
                                    {
                                       if( FileExists(RifSys->Rk[kan][dev].In[in].IconPath[2]) )
                                          tmpImg->Picture->LoadFromFile(RifSys->Rk[kan][dev].In[in].IconPath[2]);
                                       else ImageList1->GetBitmap(RifSys->Rk[kan][dev].In[in].IconNum[2],tmpImg->Picture->Bitmap);
                                    }
                                    else if( statusIu == 101 ) 
                                    {
                                       if( FileExists(RifSys->Rk[kan][dev].In[in].IconPath[4]) )
                                          tmpImg->Picture->LoadFromFile(RifSys->Rk[kan][dev].In[in].IconPath[4]);
                                       else ImageList1->GetBitmap(RifSys->Rk[kan][dev].In[in].IconNum[4],tmpImg->Picture->Bitmap);
                                    }
                                 }

                                 RifSys->Rk[kan][dev].In[in].Status = status;
                              }
                              else if( status == 100 && tmpImg->Tag == 0 ) 
                              {
                                 if( in < 8 )
                                 {
                                    if( FileExists(RifSys->Rk[kan][dev].In[in].IconPath[0]) )
                                       tmpImg->Picture->LoadFromFile(RifSys->Rk[kan][dev].In[in].IconPath[0]);
                                    else ImageList1->GetBitmap(RifSys->Rk[kan][dev].In[in].IconNum[0],tmpImg->Picture->Bitmap);
                                 }
                                 else
                                 {
                                    if( FileExists(RifSys->Rk[kan][dev].In[in].IconPath[2]) )
                                       tmpImg->Picture->LoadFromFile(RifSys->Rk[kan][dev].In[in].IconPath[2]);
                                    else ImageList1->GetBitmap(RifSys->Rk[kan][dev].In[in].IconNum[2],tmpImg->Picture->Bitmap);
                                 }

                                 tmpImg->Tag = 0;

                                 RifSys->Rk[kan][dev].In[in].Status = status;
                              }
                              else if( status == 101 && tmpImg->Tag == 0 ) 
                              {
                                 if( FileExists(RifSys->Rk[kan][dev].In[in].IconPath[1]) )
                                    tmpImg->Picture->LoadFromFile(RifSys->Rk[kan][dev].In[in].IconPath[1]);
                                 else ImageList1->GetBitmap(RifSys->Rk[kan][dev].In[in].IconNum[1],tmpImg->Picture->Bitmap);

                                 tmpImg->Tag = 0;

                                 RifSys->Rk[kan][dev].In[in].Status = status;
                              }
                              else if( (status == 12 || status == 18 || status == 11) && tmpImg->Tag == 0 )  /* ������������� */
                              {
                                 if( FileExists(RifSys->Rk[kan][dev].In[in].IconPath[4]) )
                                    tmpImg->Picture->LoadFromFile(RifSys->Rk[kan][dev].In[in].IconPath[4]);
                                 else ImageList1->GetBitmap(RifSys->Rk[kan][dev].In[in].IconNum[4],tmpImg->Picture->Bitmap);

                                 tmpImg->Tag = 1;

                                 RifSys->Rk[kan][dev].In[in].Status = status;
                              }
                              else if( status == 136 ) 
                              {
                                 if( FileExists(RifSys->Rk[kan][dev].In[in].IconPath[0]) )
                                    tmpImg->Picture->LoadFromFile(RifSys->Rk[kan][dev].In[in].IconPath[0]);
                                 else ImageList1->GetBitmap(RifSys->Rk[kan][dev].In[in].IconNum[0],tmpImg->Picture->Bitmap);

                                 tmpImg->Tag = 0;

                                 RifSys->Rk[kan][dev].In[in].Status = status;
                              }

                              tmpImg->Refresh();

                           }
                        }
                     }
                  }
               }
            }
         }

         if( POutObj(lpMapCfg)->ImgOperationId != POutObj(lpMapPlan)->ImgOperationId &&
             POutObj(lpMapPlan)->ImgOperationId != 4 &&
             POutObj(lpMapPlan)->ImgOperationId != 5 )
         {
              if( POutObj(lpMapCfg)->ImgOperationId == 1 )        
              {
                 if( POutObj(lpMapCfg)->IconVisible )
                 {
                    TImage *tmpImg = (TImage*)FindComponent(POutObj(lpMapCfg)->ImgName);
                    if( tmpImg != NULL ) 
                    {
                       tmpImg->BringToFront();

                       Shape1->Left = tmpImg->Left-3;
                       Shape1->Top = tmpImg->Top-3;
                       Shape1->Visible = true;
                    }
                    else Shape1->Visible = false;
                 }
                 else Shape1->Visible = false;
              }

              if( POutObj(lpMapCfg)->ObjName != NULL )
                 StatusBar1->Panels->Items[0]->Text = (AnsiString)POutObj(lpMapCfg)->ObjName;

              POutObj(lpMapPlan)->ImgOperationId = POutObj(lpMapCfg)->ImgOperationId;
         }
         else if( POutObj(lpMapCfg)->ImgOperationId == 6 &&
               (POutObj(lpMapPlan)->ImgOperationId == 4 || POutObj(lpMapPlan)->ImgOperationId == 5) )
         {
              POutObj(lpMapPlan)->ImgOperationId = POutObj(lpMapCfg)->ImgOperationId;
         }

         POutObj(lpMapPlan)->AlarmResetFlag = AlarmResetFlag;

      Count = (Count+1)%5;
      if( Count == 4 )
      {
          TImage* tmpimg;
          for( int i = 0; i < MainForm->ComponentCount; i++ )
          {
             if( MainForm->Components[i] != NULL )
             {
                tmpimg = dynamic_cast<TImage*>(MainForm->Components[i]);
                if( tmpimg != NULL )
                {
                   if(tmpimg->Name.Pos("img_") != 0 )
                   {
                      if(tmpimg->Tag == 1)
                         tmpimg->Visible = IconsVisible;
                      else
                         tmpimg->Visible = true;
                   }
                }
             }
          }
          IconsVisible = !IconsVisible;
      }
   }
   else Close();
}
//---------------------------------------------------------------------------
bool TMainForm::LoadGlobalConfig( AnsiString fp )
{
   TMemIniFile *ini;
   ini = new TMemIniFile( fp );

   SsoiVersion = ini->ReadInteger( "SSOI", "Version", 2 );

   int Cnt = ini->ReadInteger( "TREE", "Count", 0 );
   if( Cnt > 0 )
   {
      AnsiString str, str2;
      for( int i = 1; i <= Cnt; i++ )
      {
         str.sprintf("Obj_%d", i);

         int type = ini->ReadInteger( str.c_str(), "Type", 0 );
         int num1 = ini->ReadInteger( str.c_str(), "Num1", 0 );
         int num2 = ini->ReadInteger( str.c_str(), "Num2", 0 );
         int num3 = ini->ReadInteger( str.c_str(), "Num3", 0 );
         int IconVisible = ini->ReadBool( str.c_str(), "IconVisible", false );
         if( type == 32 ) IconVisible = false;
         else if( type == 24 ) IconVisible = false;
         else if( type == 25 ) IconVisible = false;

         bool Bazalt = ini->ReadBool( str.c_str(), "Bazalt", false );
         bool ConnectBlock = ini->ReadBool( str.c_str(), "ConnectBlock", false );
         AnsiString IconPath[8];
         IconPath[0] = ini->ReadString( str.c_str(), "Icon1Path", "" );
         IconPath[1] = ini->ReadString( str.c_str(), "Icon2Path", "" );
         IconPath[2] = ini->ReadString( str.c_str(), "Icon3Path", "" );
         IconPath[3] = ini->ReadString( str.c_str(), "Icon4Path", "" );
         IconPath[4] = ini->ReadString( str.c_str(), "Icon5Path", "" );
         IconPath[5] = ini->ReadString( str.c_str(), "Icon6Path", "" );
         IconPath[6] = ini->ReadString( str.c_str(), "Icon7Path", "" );
         IconPath[7] = ini->ReadString( str.c_str(), "Icon8Path", "" );
         int Left = ini->ReadInteger( str.c_str(), "X", 10 );
         int Top = ini->ReadInteger( str.c_str(), "Y", 10 );

         AnsiString str2;

         if( IconVisible )
         {
            if( SsoiVersion == 2 )
            {
               if( type == 3 ) type = 33;
               else if( type == 4 ) type = 43;
            }

            str2.sprintf("img_%d_%d_%d_%d",type, num1, num2, num3);

            if( type == 43 && num3 > 3 )
            {
               type = 44;
               str2.sprintf("img_%d_%d_%d_%d",type, num1, num2, num3-3);
            }


            TImage *tmpImg = (TImage*)FindComponent(str2);
            if( tmpImg == NULL )
            {
               TImage *img;
               img = new TImage(MainForm);
               img->Parent = MainForm->Panel1;
               img->Name = str2;
               img->Left = Left;
               img->Top = Top;
               if( FileExists(IconPath[0]) ) img->Picture->LoadFromFile(IconPath[0]);
               else
               {
                  if( type == 1 ) ImageList1->GetBitmap(5,Image->Picture->Bitmap);
                  else if( type == 21 ) ImageList1->GetBitmap(5,Image->Picture->Bitmap);
                  else if( type == 8 ) ImageList1->GetBitmap(5,Image->Picture->Bitmap);
                  else if( type == 9 ) ImageList1->GetBitmap(5,Image->Picture->Bitmap);
                  else if( type == 91 ) ImageList1->GetBitmap(5,Image->Picture->Bitmap);
                  else if( type == 111 ) ImageList1->GetBitmap(5,Image->Picture->Bitmap);
                  else if( type == 2 ) ImageList1->GetBitmap(10,Image->Picture->Bitmap);
                  else if( type == 11 )
                  {
                      if( !Bazalt ) ImageList1->GetBitmap(10,Image->Picture->Bitmap);
                      else ImageList1->GetBitmap(49,Image->Picture->Bitmap);
                  }
                  else if( type == 10 ) ImageList1->GetBitmap(15,Image->Picture->Bitmap);
                  else if( type == 3 || type == 33 )
                  {
                      if( !Bazalt && !ConnectBlock ) ImageList1->GetBitmap(0,Image->Picture->Bitmap);
                      else if( Bazalt )ImageList1->GetBitmap(49,Image->Picture->Bitmap);
                      else if( ConnectBlock )ImageList1->GetBitmap(56,Image->Picture->Bitmap);
                  }
                  else if( type == 4 || type == 43 || type == 44 ) ImageList1->GetBitmap(28,Image->Picture->Bitmap);
                  else if( type == 12 ) ImageList1->GetBitmap(28,Image->Picture->Bitmap);
                  else if( type == 7 ) ImageList1->GetBitmap(28,Image->Picture->Bitmap);
                  else if( type == 24 ) ImageList1->GetBitmap(48,Image->Picture->Bitmap);
                  else if( type == 25 ) ImageList1->GetBitmap(48,Image->Picture->Bitmap);
                  else if( type == 41 ) ImageList1->GetBitmap(48,Image->Picture->Bitmap);
                  else if( type == 42 ) ImageList1->GetBitmap(48,Image->Picture->Bitmap);
                  else if( type == 51 ) ImageList1->GetBitmap(48,Image->Picture->Bitmap);
                  else if( type == 5 ) ImageList1->GetBitmap(48,Image->Picture->Bitmap);
                  else if( type == 6 ) ImageList1->GetBitmap(48,Image->Picture->Bitmap);
                  else if( type == 32 ) ImageList1->GetBitmap(48,Image->Picture->Bitmap);
                  else if( type == 14 ) ImageList1->GetBitmap(38,Image->Picture->Bitmap);
                  else if( type == 15 ) ImageList1->GetBitmap(38,Image->Picture->Bitmap);
                  else if( type == 16 ) ImageList1->GetBitmap(38,Image->Picture->Bitmap);
                  else if( type == 17 ) ImageList1->GetBitmap(38,Image->Picture->Bitmap);
                  else if( type == 29 ) ImageList1->GetBitmap(50,Image->Picture->Bitmap);
                  else if( type == 30 ) ImageList1->GetBitmap(38,Image->Picture->Bitmap);
                  else if( type == 31 ) ImageList1->GetBitmap(38,Image->Picture->Bitmap);
                  else if( type == 26 ) ImageList1->GetBitmap(50,Image->Picture->Bitmap);
                  else if( type == 27 ) ImageList1->GetBitmap(43,Image->Picture->Bitmap);
                  else if( type == 28 ) ImageList1->GetBitmap(43,Image->Picture->Bitmap);

                  img->Picture = Image->Picture;
               }
               img->AutoSize = true;
               img->Visible = true;
               img->OnMouseDown = ImageMouseDown;
               img->OnMouseMove = ImageMouseMove;
               img->OnMouseUp = ImageMouseUp;
            }
         }

         if( type == 1 || type == 10 || type == 26 || type == 29 || type == 111 )  
         {
            if( RifSys == NULL )
            {
               RifSys = new TRifSys();
               RifSys->Reset();
            }

            RifSys->Use = true;
            RifSys->Rk[num3-1][num1-1].Use = true;
            RifSys->Rk[num3-1][num1-1].Type = type;

            if( type == 10 ) num2 = num2 - 1;

            RifSys->Rk[num3-1][num1-1].In[num2].Use = true;

            if( FileExists(IconPath[0]) ) RifSys->Rk[num3-1][num1-1].In[num2].IconPath[0] = IconPath[0];
            if( FileExists(IconPath[1]) ) RifSys->Rk[num3-1][num1-1].In[num2].IconPath[1] = IconPath[1];
            if( FileExists(IconPath[2]) ) RifSys->Rk[num3-1][num1-1].In[num2].IconPath[2] = IconPath[2];
            if( FileExists(IconPath[3]) ) RifSys->Rk[num3-1][num1-1].In[num2].IconPath[3] = IconPath[3];
            if( FileExists(IconPath[4]) ) RifSys->Rk[num3-1][num1-1].In[num2].IconPath[4] = IconPath[4];
            if( FileExists(IconPath[5]) ) RifSys->Rk[num3-1][num1-1].In[num2].IconPath[5] = IconPath[5];
            if( FileExists(IconPath[6]) ) RifSys->Rk[num3-1][num1-1].In[num2].IconPath[6] = IconPath[6];
            if( FileExists(IconPath[7]) ) RifSys->Rk[num3-1][num1-1].In[num2].IconPath[7] = IconPath[7];

            if( type == 1 || type == 111 ) 
            {
               RifSys->Rk[num3-1][num1-1].In[num2].IconNum[0] = 5;
               RifSys->Rk[num3-1][num1-1].In[num2].IconNum[1] = 6;
               RifSys->Rk[num3-1][num1-1].In[num2].IconNum[2] = 7;
               RifSys->Rk[num3-1][num1-1].In[num2].IconNum[3] = 8;
               RifSys->Rk[num3-1][num1-1].In[num2].IconNum[4] = 9;
            }
            else if( type == 10 ) 
            {
               RifSys->Rk[num3-1][num1-1].In[num2].IconNum[0] = 15;
               RifSys->Rk[num3-1][num1-1].In[num2].IconNum[1] = 16;
               RifSys->Rk[num3-1][num1-1].In[num2].IconNum[2] = 17;
               RifSys->Rk[num3-1][num1-1].In[num2].IconNum[3] = 18;
               RifSys->Rk[num3-1][num1-1].In[num2].IconNum[4] = 19;
               RifSys->Rk[num3-1][num1-1].In[num2].IconNum[5] = 20;
               RifSys->Rk[num3-1][num1-1].In[num2].IconNum[6] = 21;
            }
            else if( type == 26 ) 
            {
               RifSys->Rk[num3-1][num1-1].In[num2].IconNum[0] = 50;
               RifSys->Rk[num3-1][num1-1].In[num2].IconNum[1] = 51;
               RifSys->Rk[num3-1][num1-1].In[num2].IconNum[2] = 52;
               RifSys->Rk[num3-1][num1-1].In[num2].IconNum[3] = 53;
               RifSys->Rk[num3-1][num1-1].In[num2].IconNum[4] = 54;
            }
            else if( type == 29 ) 
            {
               RifSys->Rk[num3-1][num1-1].In[num2].IconNum[0] = 50;
               RifSys->Rk[num3-1][num1-1].In[num2].IconNum[1] = 51;
               RifSys->Rk[num3-1][num1-1].In[num2].IconNum[2] = 52;
               RifSys->Rk[num3-1][num1-1].In[num2].IconNum[3] = 53;
               RifSys->Rk[num3-1][num1-1].In[num2].IconNum[4] = 54;
            }
         }
         else if( type == 3 || type == 33 ) 
         {
            if( SsoiSys == NULL )
            {
               SsoiSys = new TSsoiSys();
               SsoiSys->Reset();
            }

            SsoiSys->Use = true;
            SsoiSys->Kanal[num1-1].Use = true;
            SsoiSys->Kanal[num1-1].Bl[num2-1].Use = true;
            SsoiSys->Kanal[num1-1].Bl[num2-1].Sd[num3-1].Use = true;
            SsoiSys->Kanal[num1-1].Bl[num2-1].Sd[num3-1].Bazalt = Bazalt;
            SsoiSys->Kanal[num1-1].Bl[num2-1].Sd[num3-1].ConnectBlock = ConnectBlock;

            if( FileExists(IconPath[0]) ) SsoiSys->Kanal[num1-1].Bl[num2-1].Sd[num3-1].IconPath[0] = IconPath[0];
            if( FileExists(IconPath[1]) ) SsoiSys->Kanal[num1-1].Bl[num2-1].Sd[num3-1].IconPath[1] = IconPath[1];
            if( FileExists(IconPath[2]) ) SsoiSys->Kanal[num1-1].Bl[num2-1].Sd[num3-1].IconPath[2] = IconPath[2];
            if( FileExists(IconPath[3]) ) SsoiSys->Kanal[num1-1].Bl[num2-1].Sd[num3-1].IconPath[3] = IconPath[3];
            if( FileExists(IconPath[4]) ) SsoiSys->Kanal[num1-1].Bl[num2-1].Sd[num3-1].IconPath[4] = IconPath[4];
            if( FileExists(IconPath[5]) ) SsoiSys->Kanal[num1-1].Bl[num2-1].Sd[num3-1].IconPath[5] = IconPath[5];

            if( !SsoiSys->Kanal[num1-1].Bl[num2-1].Sd[num3-1].Bazalt && !SsoiSys->Kanal[num1-1].Bl[num2-1].Sd[num3-1].ConnectBlock )
            {
               SsoiSys->Kanal[num1-1].Bl[num2-1].Sd[num3-1].IconNum[0] = 0;
               SsoiSys->Kanal[num1-1].Bl[num2-1].Sd[num3-1].IconNum[1] = 1;
               SsoiSys->Kanal[num1-1].Bl[num2-1].Sd[num3-1].IconNum[2] = 2;
               SsoiSys->Kanal[num1-1].Bl[num2-1].Sd[num3-1].IconNum[3] = 3;
               SsoiSys->Kanal[num1-1].Bl[num2-1].Sd[num3-1].IconNum[4] = 4;
            }
            else if( SsoiSys->Kanal[num1-1].Bl[num2-1].Sd[num3-1].Bazalt )
            {
               SsoiSys->Kanal[num1-1].Bl[num2-1].Sd[num3-1].IconNum[0] = 32;
               SsoiSys->Kanal[num1-1].Bl[num2-1].Sd[num3-1].IconNum[1] = 33;
               SsoiSys->Kanal[num1-1].Bl[num2-1].Sd[num3-1].IconNum[2] = 34;
               SsoiSys->Kanal[num1-1].Bl[num2-1].Sd[num3-1].IconNum[3] = 35;
               SsoiSys->Kanal[num1-1].Bl[num2-1].Sd[num3-1].IconNum[4] = 36;
               SsoiSys->Kanal[num1-1].Bl[num2-1].Sd[num3-1].IconNum[5] = 55;
            }
            else if( SsoiSys->Kanal[num1-1].Bl[num2-1].Sd[num3-1].ConnectBlock )
            {
               SsoiSys->Kanal[num1-1].Bl[num2-1].Sd[num3-1].IconNum[0] = 56;
               SsoiSys->Kanal[num1-1].Bl[num2-1].Sd[num3-1].IconNum[1] = 57;
               SsoiSys->Kanal[num1-1].Bl[num2-1].Sd[num3-1].IconNum[2] = 58;
               SsoiSys->Kanal[num1-1].Bl[num2-1].Sd[num3-1].IconNum[3] = 59;
               SsoiSys->Kanal[num1-1].Bl[num2-1].Sd[num3-1].IconNum[4] = 60;
            }
         }
         else if( type == 4 || type == 43 || type == 44 ) 
         {
            if( SsoiSys == NULL )
            {
               SsoiSys = new TSsoiSys();
               SsoiSys->Reset();
            }

            SsoiSys->Use = true;
            SsoiSys->Kanal[num1-1].Use = true;
            SsoiSys->Kanal[num1-1].Bl[num2-1].Use = true;
            if( num3 < 4 ) SsoiSys->Kanal[num1-1].Bl[num2-1].Iu[num3-1].Use = true;
            else SsoiSys->Kanal[num1-1].Bl[num2-1].Vk[num3-4].Use = true;

            if( FileExists(IconPath[0]) ) SsoiSys->Kanal[num1-1].Bl[num2-1].Iu[num3-1].IconPath[0] = IconPath[0];
            if( FileExists(IconPath[1]) ) SsoiSys->Kanal[num1-1].Bl[num2-1].Iu[num3-1].IconPath[1] = IconPath[1];
            if( FileExists(IconPath[2]) ) SsoiSys->Kanal[num1-1].Bl[num2-1].Iu[num3-1].IconPath[2] = IconPath[2];
            if( FileExists(IconPath[3]) ) SsoiSys->Kanal[num1-1].Bl[num2-1].Iu[num3-1].IconPath[3] = IconPath[3];

            SsoiSys->Kanal[num1-1].Bl[num2-1].Iu[num3-1].IconNum[0] = 28;
            SsoiSys->Kanal[num1-1].Bl[num2-1].Iu[num3-1].IconNum[1] = 29;
            SsoiSys->Kanal[num1-1].Bl[num2-1].Iu[num3-1].IconNum[2] = 30;
            SsoiSys->Kanal[num1-1].Bl[num2-1].Iu[num3-1].IconNum[3] = 31;
         }
         else if( type == 11 )
         {
            if( RifSys == NULL )
            {
               RifSys = new TRifSys();
               RifSys->Reset();
            }

            RifSys->Use = true;
            RifSys->Rk[num3-1][100].Use = true;
            RifSys->Rk[num3-1][100].Type = 11;

            RifSys->Rk[num3-1][100].In[num2-1].Use = true;
            RifSys->Rk[num3-1][100].In[num2-1].Bazalt = Bazalt;

            if( FileExists(IconPath[0]) ) RifSys->Rk[num3-1][100].In[num2-1].IconPath[0] = IconPath[0];
            if( FileExists(IconPath[1]) ) RifSys->Rk[num3-1][100].In[num2-1].IconPath[1] = IconPath[1];
            if( FileExists(IconPath[2]) ) RifSys->Rk[num3-1][100].In[num2-1].IconPath[2] = IconPath[2];
            if( FileExists(IconPath[3]) ) RifSys->Rk[num3-1][100].In[num2-1].IconPath[3] = IconPath[3];
            if( FileExists(IconPath[4]) ) RifSys->Rk[num3-1][100].In[num2-1].IconPath[4] = IconPath[4];
            if( FileExists(IconPath[5]) ) RifSys->Rk[num3-1][100].In[num2-1].IconPath[5] = IconPath[5];
            if( FileExists(IconPath[6]) ) RifSys->Rk[num3-1][100].In[num2-1].IconPath[6] = IconPath[6];
            if( FileExists(IconPath[7]) ) RifSys->Rk[num3-1][100].In[num2-1].IconPath[7] = IconPath[7];

            if( !RifSys->Rk[num3-1][100].In[num2-1].Bazalt )
            {
                RifSys->Rk[num3-1][100].In[num2-1].IconNum[0] = 10;
                RifSys->Rk[num3-1][100].In[num2-1].IconNum[1] = 11;
                RifSys->Rk[num3-1][100].In[num2-1].IconNum[2] = 12;
                RifSys->Rk[num3-1][100].In[num2-1].IconNum[3] = 13;
                RifSys->Rk[num3-1][100].In[num2-1].IconNum[4] = 14;
            }
            else
            {
                RifSys->Rk[num3-1][100].In[num2-1].IconNum[0] = 49;
                RifSys->Rk[num3-1][100].In[num2-1].IconNum[1] = 32;
                RifSys->Rk[num3-1][100].In[num2-1].IconNum[2] = 33;
                RifSys->Rk[num3-1][100].In[num2-1].IconNum[3] = 34;
                RifSys->Rk[num3-1][100].In[num2-1].IconNum[4] = 35;
                RifSys->Rk[num3-1][100].In[num2-1].IconNum[5] = 36;
            }
         }
         else if( type == 12 ) 
         {
            if( RifSys == NULL )
            {
               RifSys = new TRifSys();
               RifSys->Reset();
            }

            RifSys->Use = true;
            RifSys->Rk[num3-1][100].Use = true;
            RifSys->Rk[num3-1][100].Type = 11;

            RifSys->Rk[num3-1][100].In[num2-1+8].Use = true;
            RifSys->Rk[num3-1][100].In[num2-1+8].Bazalt = Bazalt;

            if( FileExists(IconPath[0]) ) RifSys->Rk[num3-1][100].In[num2-1+8].IconPath[0] = IconPath[0];
            if( FileExists(IconPath[1]) ) RifSys->Rk[num3-1][100].In[num2-1+8].IconPath[1] = IconPath[1];
            if( FileExists(IconPath[2]) ) RifSys->Rk[num3-1][100].In[num2-1+8].IconPath[2] = IconPath[2];
            if( FileExists(IconPath[3]) ) RifSys->Rk[num3-1][100].In[num2-1+8].IconPath[3] = IconPath[3];
            if( FileExists(IconPath[4]) ) RifSys->Rk[num3-1][100].In[num2-1+8].IconPath[4] = IconPath[4];
            if( FileExists(IconPath[5]) ) RifSys->Rk[num3-1][100].In[num2-1+8].IconPath[5] = IconPath[5];
            if( FileExists(IconPath[6]) ) RifSys->Rk[num3-1][100].In[num2-1+8].IconPath[6] = IconPath[6];
            if( FileExists(IconPath[7]) ) RifSys->Rk[num3-1][100].In[num2-1+8].IconPath[7] = IconPath[7];

            RifSys->Rk[num3-1][100].In[num2-1+8].IconNum[0] = 28;
            RifSys->Rk[num3-1][100].In[num2-1+8].IconNum[1] = 29;
            RifSys->Rk[num3-1][100].In[num2-1+8].IconNum[2] = 30;
            RifSys->Rk[num3-1][100].In[num2-1+8].IconNum[3] = 31;
         }
         else if( type == 27 || type == 30 ) 
         {
            if( RifSys == NULL )
            {
               RifSys = new TRifSys();
               RifSys->Reset();
            }

            RifSys->Use = true;

            int uch = num2/100-1;
            RifSys->Rk[num3-1][num1-1].In[uch+1].Use = true;

            RifSys->Rk[num3-1][num1-1].In[uch+1].IconPath[0] = IconPath[0];
            RifSys->Rk[num3-1][num1-1].In[uch+1].IconPath[1] = IconPath[1];
            RifSys->Rk[num3-1][num1-1].In[uch+1].IconPath[2] = IconPath[2];
            RifSys->Rk[num3-1][num1-1].In[uch+1].IconPath[3] = IconPath[3];
            RifSys->Rk[num3-1][num1-1].In[uch+1].IconPath[4] = IconPath[4];

            if( type == 27 ) 
            {
               RifSys->Rk[num3-1][num1-1].In[uch+1].IconNum[0] = 43;
               RifSys->Rk[num3-1][num1-1].In[uch+1].IconNum[1] = 44;
               RifSys->Rk[num3-1][num1-1].In[uch+1].IconNum[2] = 45;
               RifSys->Rk[num3-1][num1-1].In[uch+1].IconNum[3] = 46;
               RifSys->Rk[num3-1][num1-1].In[uch+1].IconNum[4] = 47;
            }
            else 
            {
               RifSys->Rk[num3-1][num1-1].In[uch+1].IconNum[0] = 38;
               RifSys->Rk[num3-1][num1-1].In[uch+1].IconNum[1] = 39;
               RifSys->Rk[num3-1][num1-1].In[uch+1].IconNum[2] = 40;
               RifSys->Rk[num3-1][num1-1].In[uch+1].IconNum[3] = 41;
               RifSys->Rk[num3-1][num1-1].In[uch+1].IconNum[4] = 42;
            }
         }
      }
   }

   delete ini;

   return true;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::Panel1Resize(TObject *Sender)
{
   Resize = true;

   if( iW != 0) dX = double(Panel1->Width)/double(iW);
   else dX = 0.00;
   if( iH != 0) dY = double(Panel1->Height)/double(iH);
   else dY = 0.00;

   AnsiString str = "����: " + IntToStr(Panel1->Width) + "x" +  IntToStr(Panel1->Height);
   StatusBar1->Panels->Items[1]->Text = str;
}
//---------------------------------------------------------------------------




