//---------------------------------------------------------------------------
#ifndef TRifSysUnitH
#define TRifSysUnitH
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
class TDd
{
public:
   bool Use;      

   int Status;

   bool Bazalt;

   bool AlarmFlag;

   int IconNum[8];
   AnsiString IconPath[8];

   TDd();
   void Reset();
};
//---------------------------------------------------------------------------
#define MaxErrCnt 3
#define MaxInCnt (8+4)
#define MaxTochkaMUchCnt 4
//---------------------------------------------------------------------------
class TRif_KoncentratorDev
{
public:
   bool Use;
   int Type;
   
   TDd In[MaxInCnt];

   TRif_KoncentratorDev();
   void Reset();
};
//---------------------------------------------------------------------------
#define RifDevCnt 101
#define RifKanCnt 256
class TRifSys
{
public:
   bool Use;
   TRif_KoncentratorDev Rk[RifKanCnt][RifDevCnt];

   TRifSys();
   void Reset();
};
//---------------------------------------------------------------------------
#endif
