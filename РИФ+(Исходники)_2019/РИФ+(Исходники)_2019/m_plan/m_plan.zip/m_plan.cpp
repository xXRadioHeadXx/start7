//---------------------------------------------------------------------------
#include <vcl.h>
#include "MyApiUnit.h"
#pragma hdrstop
//---------------------------------------------------------------------------
USEFORM("MainUnit.cpp", MainForm);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
   if ( WeAreAlone ("RIFx_Mplan_by_Start7") )
   {
      try
      {
          Application->Initialize();
          Application->Title = "����";
          Application->CreateForm(__classid(TMainForm), &MainForm);
       Application->Run();
      }
      catch (Exception &exception)
      {
          Application->ShowException(&exception);
      }
      catch (...)
      {
          try
          {
             throw Exception("");
          }
          catch (Exception &exception)
          {
             Application->ShowException(&exception);
          }
      }
   }
   return 0;
}
//---------------------------------------------------------------------------
