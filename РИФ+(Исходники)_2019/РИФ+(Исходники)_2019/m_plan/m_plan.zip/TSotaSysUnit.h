//---------------------------------------------------------------------------
#ifndef TSotaSysUnitH
#define TSotaSysUnitH
//---------------------------------------------------------------------------
class TSotaDv
{
public:
   bool Use;
   int Status;
   int UchNum;

   AnsiString IconPath[8];

   bool IconVisible;
   int X, Y;
   bool ImgExists;
   TImage *Img;
   void CreateImg(AnsiString name);

   TSotaDv();
   void Reset();
};
//---------------------------------------------------------------------------
#define MaxSotaDvCnt 100
class TSotaUch
{
public:
   bool Use;
   int Status;

   AnsiString IconPath[8];

   bool IconVisible;
   int X, Y;
   bool ImgExists;
   TImage *Img;
   void CreateImg(AnsiString name);

   TSotaUch();
   void Reset();
};
//---------------------------------------------------------------------------
#define MaxSotaUchCnt 2
class TSotaFlang
{
public:
   bool Use;
   int Status;

   AnsiString IconPath[8];

   bool IconVisible;
   int X, Y;
   bool ImgExists;
   TImage *Img;
   void CreateImg(AnsiString name);

   TSotaUch Uch[MaxSotaUchCnt];

   TSotaDv Dv[MaxSotaDvCnt];

   TSotaFlang();
   void Reset();
};
//---------------------------------------------------------------------------
#define MaxSotaFlangCnt 2
class TSotaBos
{
public:
   bool Use;
   int Status;

   AnsiString IconPath[8];

   bool IconVisible;
   int X, Y;
   bool ImgExists;
   TImage *Img;
   void CreateImg(AnsiString name);

   TSotaFlang Flang[MaxSotaFlangCnt];

   TSotaBos();
   void Reset();
};
//---------------------------------------------------------------------------
#define MaxSotaBosCnt 100
class TSotaPort
{
public:
   bool Use;      

   TSotaBos Bos[MaxSotaBosCnt];

   TSotaPort();
   void Reset();
};
//---------------------------------------------------------------------------
#define MaxSotaPortCnt 100
class TSotaSys
{
public:
   bool Use;

   TSotaPort SotaPort[MaxSotaPortCnt];

   TSotaSys();
   void Reset();
};
//---------------------------------------------------------------------------
#endif
