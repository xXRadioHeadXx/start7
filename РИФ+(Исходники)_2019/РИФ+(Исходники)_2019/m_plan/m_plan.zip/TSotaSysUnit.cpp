//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "TSotaSysUnit.h"
#include "MainUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
TSotaDv::TSotaDv()
{
   ImgExists = false;
   Reset();
}
//---------------------------------------------------------------------------
void TSotaDv::Reset()
{
   Use = false;
   Status = 0;

   IconVisible = false;
   X = 20, Y = 20;

   if( ImgExists ) delete Img;

   ImgExists = false;
}
//---------------------------------------------------------------------------
void TSotaDv::CreateImg(AnsiString name)
{
   Img = new TImage(MainForm);
   Img->Parent = MainForm->Panel1;
   Img->Visible = true;
   Img->Center = true;
   Img->AutoSize = true;
   Img->Left = X;
   Img->Top = Y;
   Img->Transparent = true;
   Img->Name = "img_" + name;
   Img->OnMouseDown = MainForm->ImgMouseDown;
   Img->OnMouseMove = MainForm->ImgMouseMove;
   Img->OnMouseUp = MainForm->ImgMouseUp;
   ImgExists = true;
}
//---------------------------------------------------------------------------
TSotaUch::TSotaUch()
{
   ImgExists = false;
   Reset();
}
//---------------------------------------------------------------------------
void TSotaUch::Reset()
{
   Use = false;
   Status = 0;

   IconVisible = false;

   X = 20, Y = 20;

   if( ImgExists ) delete Img;

   ImgExists = false;
}
//---------------------------------------------------------------------------
void TSotaUch::CreateImg(AnsiString name)
{
   Img = new TImage(MainForm);
   Img->Parent = MainForm->Panel1;
   Img->Visible = true;
   Img->Center = true;
   Img->AutoSize = true;
   Img->Left = X;
   Img->Top = Y;
   Img->Transparent = true;
   Img->Name = "img_" + name;
   Img->OnMouseDown = MainForm->ImgMouseDown;
   Img->OnMouseMove = MainForm->ImgMouseMove;
   Img->OnMouseUp = MainForm->ImgMouseUp;
   ImgExists = true;
}
//---------------------------------------------------------------------------
TSotaFlang::TSotaFlang()
{
   ImgExists = false;
   Reset();
}
//---------------------------------------------------------------------------
void TSotaFlang::Reset()
{
   Use = false;
   Status = 0;

   IconVisible = false;

   X = 20, Y = 20;

   if( ImgExists ) delete Img;

   ImgExists = false;

   for( int uch = 0; uch < MaxSotaUchCnt; uch++ ) Uch[uch].Reset();

   for( int dv = 0; dv < MaxSotaDvCnt; dv++ ) Dv[dv].Reset();
}
//---------------------------------------------------------------------------
void TSotaFlang::CreateImg(AnsiString name)
{
   Img = new TImage(MainForm);
   Img->Parent = MainForm->Panel1;
   Img->Visible = true;
   Img->Center = true;
   Img->AutoSize = true;
   Img->Left = X;
   Img->Top = Y;
   Img->Transparent = true;
   Img->Name = "img_" + name;
   Img->OnMouseDown = MainForm->ImgMouseDown;
   Img->OnMouseMove = MainForm->ImgMouseMove;
   Img->OnMouseUp = MainForm->ImgMouseUp;
   ImgExists = true;
}
//---------------------------------------------------------------------------
TSotaBos::TSotaBos()
{
   ImgExists = false;
   Reset();
}
//---------------------------------------------------------------------------
void TSotaBos::Reset()
{
   Use = false;
   Status = 0;

   IconVisible = false;
   
   X = 20, Y = 20;

   if( ImgExists ) delete Img;

   ImgExists = false;

   for( int flang = 0; flang < MaxSotaFlangCnt; flang++ ) Flang[flang].Reset();
}
//---------------------------------------------------------------------------
void TSotaBos::CreateImg(AnsiString name)
{
   Img = new TImage(MainForm);
   Img->Parent = MainForm->Panel1;
   Img->Visible = true;
   Img->Center = true;
   Img->AutoSize = true;
   Img->Left = X;
   Img->Top = Y;
   Img->Transparent = true;
   Img->Name = "img_" + name;
   Img->OnMouseDown = MainForm->ImgMouseDown;
   Img->OnMouseMove = MainForm->ImgMouseMove;
   Img->OnMouseUp = MainForm->ImgMouseUp;
   ImgExists = true;
}
//---------------------------------------------------------------------------
TSotaPort::TSotaPort()
{
   Reset();
}
//---------------------------------------------------------------------------
void TSotaPort::Reset()
{
   Use = false;

   for( int bos = 0; bos < MaxSotaBosCnt; bos++ ) Bos[bos].Reset();
}
//---------------------------------------------------------------------------
TSotaSys::TSotaSys()
{
   Reset();
}
//---------------------------------------------------------------------------
void TSotaSys::Reset()
{
   for( int port = 0; port < MaxSotaPortCnt; port++ ) SotaPort[port].Reset();
}
//---------------------------------------------------------------------------

