#ifndef MainUnitH
#define MainUnitH
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ImgList.hpp>
#include <Menus.hpp>
#include <ComCtrls.hpp>
#include <ToolWin.hpp>
#include <ExtCtrls.hpp>
#include <Buttons.hpp>
#include <FileCtrl.hpp>
#include <Graphics.hpp>
#include "CSPIN.h"
#include <Dialogs.hpp>
#include <ExtDlgs.hpp>
#include "TOhrObjUnit.h"
#include <jpeg.hpp>
#include "RXSpin.hpp"
#include "AdvGrid.hpp"
#include "BaseGrid.hpp"
#include <Grids.hpp>
#include "OperatorListUnit.h"
#include <Mask.hpp>
#define MaxPortCnt 256
#define MaxSotaPortCnt 100
#define MaxRifDev 100
#define MaxRifSdDev 4
#define MaxKanalDev 4
#define MaxBlDev 99
#define MaxSdDev 8
#define MaxIuDev 3
#define MaxVkDev 3
#define MaxMonitorDev 4
#define MaxTvDev 56
#define MaxTvSolidDev 480
#define MaxAdam4068Dev 255
#define MaxSdIpBlDev 8
#define MaxIuIpBlDev 4

#define GroupIdx 0
#define SdIdx 1
#define IuIdx 2
#define RastrIdx 3
#define Stn485Idx 4
#define Stn1Idx 5
#define TabloIdx 6
#define RifIdx 7
#define SdConcIdx 8
#define TorosIdx 9
#define NastIdx 10
#define RadarIdx 11
#define RazrivBoIdx 12
#define TochkaIdx 13
#define Adam4068Idx 14
#define SolidIdx 15
#define SsoiIdx 16
#define SdIpBlIdx 17
#define IuIpBlIdx 18
#define SdSsoiM1Idx 19
#define IuSsoiM1Idx 20
#define RifRlmSIdx 19
#define StrazhIpIdx 20
#define OnvifTvIdx 21
#define TochkaMBoIdx 22
#define TochkaMUchIdx 23
#define TochkaMDdIdx 24
#define SotaMBoIdx 25
#define SotaMUchIdx 26
#define SotaMDdIdx 27
#define DevLineIdx 28
#define DevLineIdx 28
#define NetDeviceIdx 29
   
#define UnUsedComPort 0
#define RifComPort 1
#define SsoiComPort 2
#define RastrComPort 3
#define SolidComPort 4
#define AdamComPort 5
#define TabloComPort 6
#define RifxComplexType 0           #define SsoiComplexType 1           #define Rastr_M_SsoiComplexType 2   #define Rastr_M_TvComplexType 3     #define SsoiM1DevCnt 2
class TMainForm : public TForm
{
__published:	   TMainMenu *MainMenu1;
   TImageList *ImageList1;
   TMenuItem *FileItems;
   TMenuItem *FileNewItem;
   TMenuItem *FileOpenItem;
   TMenuItem *FileSaveItem;
   TMenuItem *N1;
   TMenuItem *ExitItem;
   TStatusBar *StatusBar1;
   TToolBar *ToolBar1;
   TPanel *Panel1;
   TPanel *Panel2;
   TGroupBox *TreeGroupBox;
   TGroupBox *ObjGroupBox;
   TTreeView *ObjTree;
   TToolButton *ToolButton1;
   TToolButton *ToolButton2;
   TToolButton *ToolButton3;
   TGroupBox *GroupBox2;
   TLabel *Label1;
   TComboBox *ComboBox1;
   TComboBox *ComboBox2;
   TComboBox *ComboBox3;
   TLabel *Label2;
   TLabel *Label3;
   TLabel *Label4;
   TEdit *Edit1;
   TBitBtn *BitBtn1;
   TBitBtn *BitBtn2;
   TBitBtn *BitBtn3;
   TBitBtn *BitBtn4;
   TBitBtn *BitBtn5;
   TScrollBox *ScrollBox1;
   TGroupBox *GroupBox5;
   TGroupBox *KeyGenGroupBox;
   TLabel *Label8;
   TLabel *Label9;
   TLabel *Label10;
   TBitBtn *BitBtn8;
   TBitBtn *BitBtn9;
   TEdit *Edit4;
   TEdit *Edit5;
   TGroupBox *GroupBox9;
   TGroupBox *GroupBox10;
   TLabel *Label18;
   TLabel *Label19;
   TLabel *Label20;
   TComboBox *ComboBox6;
   TRxSpinEdit *RxSpinEdit1;
   TRxSpinEdit *RxSpinEdit2;
   TOpenPictureDialog *OpenPictureDialog1;
   TSaveDialog *SaveDialog1;
   TBitBtn *BitBtn10;
   TOpenDialog *OpenDialog1;
   TStaticText *StaticText1;
   TComboBox *ComboBox9;
   TPopupMenu *PopupMenu1;
   TMenuItem *IconVisible_pdi;
   TGroupBox *PlanGroupBox;
   TOpenPictureDialog *OpenPictureDialog2;
   TEdit *Edit3;
   TLabel *Label27;
   TSpeedButton *SpeedButton7;
   TSpeedButton *SpeedButton8;
   TTimer *CfgTimer;
   TMenuItem *Dk_pdi;
   TGroupBox *GroupBox6;
   TLabel *Label14;
   TComboBox *ComboBox4;
   TLabel *Label17;
   TComboBox *ComboBox7;
   TGroupBox *GroupBox7;
   TLabel *Label29;
   TComboBox *ComboBox10;
   TGroupBox *GroupBox8;
   TLabel *Label30;
   TComboBox *ComboBox12;
   TGroupBox *GroupBox12;
   TComboBox *ComboBox13;
   TLabel *Label22;
   TLabel *Label23;
   TEdit *Edit6;
   TBitBtn *BitBtn7;
   TMenuItem *Bazalt_pdi;
   TGroupBox *GroupBox13;
   TComboBox *ComboBox15;
   TLabel *Label33;
   TEdit *Edit7;
   TCSpinEdit *CSpinEdit1;
   TLabel *Label34;
   TLabel *Label35;
   TBitBtn *BitBtn11;
   TMenuItem *Metka_pdi;
   TComboBox *ComboBox16;
   TLabel *Label36;
   TGroupBox *GroupBox1;
   TRadioButton *RadioButton1;
   TRadioButton *RadioButton2;
   TMenuItem *Razriv11_pdi;
   TMenuItem *Razriv21_pdi;
   TMenuItem *Razriv12_pdi;
   TMenuItem *Razriv22_pdi;
   TMenuItem *Adam4068AutoOff_pdi;
   TMenuItem *Adam4068AutoOff0_pdi;
   TMenuItem *Adam4068AutoOff1m_pdi;
   TMenuItem *Adam4068AutoOff5m_pdi;
   TMenuItem *Adam4068AutoOff10m_pdi;
   TMenuItem *Adam4068AutoOff20m_pdi;
   TMenuItem *Adam4068AutoOff30m_pdi;
   TMenuItem *Adam4068AutoOff59m_pdi;
   TMenuItem *Adam4068AutoOff5s_pdi;
   TMenuItem *Adam4068AutoOff10s_pdi;
   TMenuItem *Adam4068AutoOff30s_pdi;
   TGroupBox *GroupBox14;
   TLabel *Label21;
   TLabel *Label37;
   TLabel *Label38;
   TComboBox *ComboBox17;
   TEdit *Edit8;
   TCSpinEdit *CSpinEdit2;
   TLabel *Label40;
   TCSpinEdit *CSpinEdit5;
   TLabel *Label41;
   TComboBox *ComboBox18;
   TLabel *Label43;
   TCSpinEdit *CSpinEdit6;
   TLabel *Label47;
   TCSpinEdit *CSpinEdit9;
   TGroupBox *GroupBox15;
   TGroupBox *GroupBox17;
   TGroupBox *GroupBox18;
   TComboBox *ComboBox20;
   TLabel *Label46;
   TCSpinEdit *CSpinEdit11;
   TLabel *Label28;
   TButton *Button1;
   TLabel *Label51;
   TEdit *Edit10;
   TLabel *Label52;
   TEdit *Edit11;
   TGroupBox *GroupBox20;
   TLabel *Label49;
   TComboBox *ComboBox14;
   TLabel *Label53;
   TCSpinEdit *CSpinEdit12;
   TLabel *Label54;
   TCSpinEdit *CSpinEdit13;
   TGroupBox *GroupBox21;
   TLabel *Label16;
   TLabel *Label44;
   TLabel *Label45;
   TComboBox *ComboBox5;
   TCSpinEdit *CSpinEdit7;
   TCSpinEdit *CSpinEdit8;
   TGroupBox *GroupBox22;
   TLabel *Label55;
   TLabel *Label56;
   TLabel *Label57;
   TComboBox *ComboBox21;
   TCSpinEdit *CSpinEdit14;
   TCSpinEdit *CSpinEdit15;
   TGroupBox *GroupBox23;
   TLabel *Label58;
   TLabel *Label59;
   TLabel *Label60;
   TComboBox *ComboBox22;
   TCSpinEdit *CSpinEdit16;
   TCSpinEdit *CSpinEdit17;
   TCSpinEdit *CSpinEdit18;
   TLabel *Label50;
   TEdit *Edit9;
   TLabel *Label62;
   TLabel *Label15;
   TComboBox *ComboBox11;
   TGroupBox *GroupBox16;
   TLabel *Label61;
   TComboBox *ComboBox25;
   TLabel *Label64;
   TButton *Button2;
   TRxSpinEdit *RxSpinEdit3;
   TLabel *Label42;
   TComboBox *ComboBox19;
   TOpenDialog *OpenDialog2;
   TGroupBox *GroupBox4;
   TLabel *Label24;
   TEdit *Edit2;
   TButton *Button3;
   TLabel *Label25;
   TComboBox *ComboBox8;
   TGroupBox *GroupBox24;
   TAdvStringGrid *AdvStringGrid1;
   TButton *Button4;
   TButton *Button5;
   TButton *Button6;
   TComboBox *ComboBox26;
   TLabel *Label48;
   TLabel *Label65;
   TComboBox *ComboBox27;
   TCheckBox *CheckBox2;
   TCheckBox *CheckBox3;
   TMenuItem *KedrImportItem;
   TMenuItem *N3;
   TOpenDialog *OpenDialog3;
   TMenuItem *AlarmMsgOn_pdi;
   TLabel *Label26;
   TCSpinEdit *CSpinEdit3;
   TMenuItem *ConnectBlock_pdi;
   TGroupBox *GroupBox11;
   TLabel *Label66;
   TComboBox *ComboBox24;
   TCheckBox *CheckBox1;
   TComboBox *ComboBox28;
   TLabel *Label67;
   TLabel *Label68;
   TEdit *Edit12;
   TLabel *Label69;
   TLabel *Label70;
   TEdit *Edit13;
   TEdit *Edit14;
   TLabel *Label63;
   TComboBox *ComboBox23;
   TLabel *Label71;
   TComboBox *ComboBox29;
   TLabel *Label72;
   TComboBox *ComboBox30;
   TLabel *Label73;
   TComboBox *ComboBox31;
   TGroupBox *GroupBox19;
   TLabel *Label74;
   TLabel *Label75;
   TLabel *Label76;
   TLabel *Label77;
   TComboBox *ComboBox32;
   TEdit *Edit15;
   TCSpinEdit *CSpinEdit10;
   TBitBtn *BitBtn6;
   TCSpinEdit *CSpinEdit19;
   TLabel *Label39;
   TLabel *Label78;
   TRxSpinEdit *RxSpinEdit4;
   TRxSpinEdit *RxSpinEdit5;
   TLabel *Label79;
   TEdit *Edit16;
   TLabel *Label80;
   TComboBox *ComboBox33;
   TGroupBox *GroupBox25;
   TLabel *Label81;
   TEdit *Edit17;
   TLabel *Label82;
   TRxSpinEdit *RxSpinEdit6;
   TRxSpinEdit *RxSpinEdit7;
   TLabel *Label83;
   TButton *Button7;
   TCSpinEdit *CSpinEdit4;
   TGroupBox *GroupBox26;
   TLabel *Label86;
   TEdit *Edit18;
   TButton *Button8;
   TOpenDialog *OpenDialog4;
   TGroupBox *GroupBox27;
   TLabel *Label84;
   TLabel *Label85;
   TLabel *Label87;
   TLabel *Label88;
   TCSpinEdit *CSpinEdit20;
   TCSpinEdit *CSpinEdit21;
   TEdit *Edit19;
   TEdit *Edit20;
   TLabel *Label89;
   TLabel *Label90;
   TButton *Button9;
   TCSpinEdit *CSpinEdit22;
   TCSpinEdit *CSpinEdit23;
   TLabel *Label91;
   TComboBox *ComboBox34;
   TMenuItem *N2;
   TMenuItem *N4;
   TImageList *ImageList2;
   TImage *Image1;
   TCheckBox *CheckBox4;
   TCSpinEdit *CSpinEdit24;
   TCSpinEdit *CSpinEdit25;
   TLabel *Label5;
   TLabel *Label6;
   TMenuItem *N5;
   TMenuItem *N6;
   TComboBox *ComboBox35;
   TLabel *Label7;
   TLabel *Label11;
   TCSpinEdit *CSpinEdit26;
   void __fastcall FormCreate(TObject *Sender);
   void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
   void __fastcall ExitItemClick(TObject *Sender);
   void __fastcall BitBtn8Click(TObject *Sender);
   void __fastcall BitBtn9Click(TObject *Sender);
   void __fastcall BitBtn1Click(TObject *Sender);
   void __fastcall BitBtn2Click(TObject *Sender);
   void __fastcall BitBtn3Click(TObject *Sender);
   void __fastcall BitBtn4Click(TObject *Sender);
   void __fastcall BitBtn5Click(TObject *Sender);
   void __fastcall FileNewItemClick(TObject *Sender);
   void __fastcall FileSaveItemClick(TObject *Sender);
   void __fastcall BitBtn10Click(TObject *Sender);
   void __fastcall FileOpenItemClick(TObject *Sender);
   void __fastcall ObjTreeClick(TObject *Sender);
   void __fastcall ObjTreeKeyUp(TObject *Sender, WORD &Key,
          TShiftState Shift);
   void __fastcall PopupMenu1Popup(TObject *Sender);
   void __fastcall IconVisible_pdiClick(TObject *Sender);
   void __fastcall SpeedButton7Click(TObject *Sender);
   void __fastcall SpeedButton8Click(TObject *Sender);
   void __fastcall CfgTimerTimer(TObject *Sender);
   void __fastcall Dk_pdiClick(TObject *Sender);
   void __fastcall ComboBox7Change(TObject *Sender);
   void __fastcall ComboBox10Change(TObject *Sender);
   void __fastcall ComboBox12Change(TObject *Sender);
   void __fastcall BitBtn7Click(TObject *Sender);
   void __fastcall Bazalt_pdiClick(TObject *Sender);
   void __fastcall BitBtn11Click(TObject *Sender);
   void __fastcall ComboBox15Change(TObject *Sender);
   void __fastcall Metka_pdiClick(TObject *Sender);
   void __fastcall ComboBox16Click(TObject *Sender);
   void __fastcall Razriv11_pdiClick(TObject *Sender);
   void __fastcall Razriv12_pdiClick(TObject *Sender);
   void __fastcall Razriv21_pdiClick(TObject *Sender);
   void __fastcall Razriv22_pdiClick(TObject *Sender);
   void __fastcall Adam4068AutoOff0_pdiClick(TObject *Sender);
   void __fastcall Adam4068AutoOff1m_pdiClick(TObject *Sender);
   void __fastcall Adam4068AutoOff5m_pdiClick(TObject *Sender);
   void __fastcall Adam4068AutoOff10m_pdiClick(TObject *Sender);
   void __fastcall Adam4068AutoOff20m_pdiClick(TObject *Sender);
   void __fastcall Adam4068AutoOff30m_pdiClick(TObject *Sender);
   void __fastcall Adam4068AutoOff59m_pdiClick(TObject *Sender);
   void __fastcall Adam4068AutoOff5s_pdiClick(TObject *Sender);
   void __fastcall Adam4068AutoOff10s_pdiClick(TObject *Sender);
   void __fastcall Adam4068AutoOff30s_pdiClick(TObject *Sender);
   void __fastcall BitBtn12Click(TObject *Sender);
   void __fastcall ComboBox20Change(TObject *Sender);
   void __fastcall ComboBox14Change(TObject *Sender);
   void __fastcall ComboBox5Change(TObject *Sender);
   void __fastcall ComboBox21Change(TObject *Sender);
   void __fastcall ComboBox22Change(TObject *Sender);
   void __fastcall Button1Click(TObject *Sender);
   void __fastcall ComboBox1Click(TObject *Sender);
   void __fastcall ComboBox4Change(TObject *Sender);
   void __fastcall ComboBox18Change(TObject *Sender);
   void __fastcall CSpinEdit5Change(TObject *Sender);
   void __fastcall Button2Click(TObject *Sender);
   void __fastcall Button3Click(TObject *Sender);
   void __fastcall AdvStringGrid1GetAlignment(TObject *Sender, int ARow,
          int ACol, TAlignment &HAlign, TVAlignment &VAlign);
   void __fastcall Button4Click(TObject *Sender);
   void __fastcall Button5Click(TObject *Sender);
   void __fastcall Button6Click(TObject *Sender);
   void __fastcall AdvStringGrid1GetDisplText(TObject *Sender, int ACol,
          int ARow, AnsiString &Value);
   void __fastcall ComboBox26Change(TObject *Sender);
   void __fastcall Bazalt_pdiDrawItem(TObject *Sender, TCanvas *ACanvas,
          TRect &ARect, bool Selected);
   void __fastcall Dk_pdiDrawItem(TObject *Sender, TCanvas *ACanvas,
          TRect &ARect, bool Selected);
   void __fastcall Razriv11_pdiDrawItem(TObject *Sender, TCanvas *ACanvas,
          TRect &ARect, bool Selected);
   void __fastcall Razriv12_pdiDrawItem(TObject *Sender, TCanvas *ACanvas,
          TRect &ARect, bool Selected);
   void __fastcall Razriv21_pdiDrawItem(TObject *Sender, TCanvas *ACanvas,
          TRect &ARect, bool Selected);
   void __fastcall Razriv22_pdiDrawItem(TObject *Sender, TCanvas *ACanvas,
          TRect &ARect, bool Selected);
   void __fastcall Bazalt_pdiMeasureItem(TObject *Sender, TCanvas *ACanvas,
          int &Width, int &Height);
   void __fastcall Dk_pdiMeasureItem(TObject *Sender, TCanvas *ACanvas,
          int &Width, int &Height);
   void __fastcall Razriv11_pdiMeasureItem(TObject *Sender,
          TCanvas *ACanvas, int &Width, int &Height);
   void __fastcall Razriv12_pdiMeasureItem(TObject *Sender,
          TCanvas *ACanvas, int &Width, int &Height);
   void __fastcall Razriv21_pdiMeasureItem(TObject *Sender,
          TCanvas *ACanvas, int &Width, int &Height);
   void __fastcall Razriv22_pdiMeasureItem(TObject *Sender,
          TCanvas *ACanvas, int &Width, int &Height);
   void __fastcall KedrImportItemClick(TObject *Sender);
   void __fastcall Edit1KeyPress(TObject *Sender, char &Key);
   void __fastcall AlarmMsgOn_pdiClick(TObject *Sender);
   void __fastcall ConnectBlock_pdiClick(TObject *Sender);
   void __fastcall ComboBox24Change(TObject *Sender);
   void __fastcall ComboBox29Change(TObject *Sender);
   void __fastcall ComboBox17Change(TObject *Sender);
   void __fastcall Button7Click(TObject *Sender);
   void __fastcall Edit17KeyPress(TObject *Sender, char &Key);
   void __fastcall Button8Click(TObject *Sender);
   void __fastcall Button9Click(TObject *Sender);
   void __fastcall N2Click(TObject *Sender);
   void __fastcall N5Click(TObject *Sender);
   void __fastcall N6Click(TObject *Sender);
   void __fastcall ComboBox35Change(TObject *Sender);
private:	public:		   __fastcall TMainForm(TComponent* Owner);

   AnsiString VersionInfoStr;

   int ComplexVersion;

   Graphics::TBitmap *I1Img;

   void ShowObjGroupBox();
   void ShowKeyGenGroupBox();

   int UsePort[256]; 

   int RifPortSpeed[MaxPortCnt], RifPortInterval[MaxPortCnt],
       RastrPortNum, SolidPortNum, 
       Adam4068PortNum, GobiFixNewWarning, SsoiVersion, SsoiM_PortNum[MaxKanalDev],
       SsoiM_Interval[MaxKanalDev], SsoiM_MaxErrCnt[MaxKanalDev], TabloPortNum;

   AnsiString Icon1Path;
   AnsiString Icon2Path;
   AnsiString Icon3Path;
   AnsiString Icon4Path;
   AnsiString Icon5Path;
   AnsiString Icon6Path;
   AnsiString Icon7Path;
   AnsiString Icon8Path;
   int Mode;
   TDateTime DbUpdate;
   bool Server1Use;

   HANDLE hMapCfg, hMapPlan;
   LPVOID lpMapCfg, lpMapPlan;

   void __fastcall MoveUpTree(TTreeNode *item);

   AnsiString RastrmtvDevName[4], RastrmtvDevSn[4];

   int OpDlgMode;
   TSysOperatorList *OpList;

   AnsiString MsgStr6, MsgStr7, MsgStr25, MsgStr26, MsgStr27,  MsgStr28, MsgStr29, MsgStr30, MsgStr31, MsgStr33, MsgStr34,
              MsgStr35, MsgStr36, MsgStr37, MsgStr38,
              MCFGInfoStr26, MCFGInfoStr27, MCFGInfoStr28, MCFGInfoStr29,
              MCFGInfoStr55,
              MCFGInfoStr62, MCFGInfoStr63, MCFGInfoStr64, MCFGInfoStr65, MCFGInfoStr66,
              MCFGInfoStr67, MCFGInfoStr68, MCFGInfoStr69, MCFGInfoStr70, MCFGInfoStr71,
              MCFGInfoStr72, MCFGInfoStr73, MCFGInfoStr74, MCFGInfoStr75, MCFGInfoStr76,
              MCFGInfoStr77, MCFGInfoStr78, MCFGInfoStr79, MCFGInfoStr80, MCFGInfoStr81,
              MCFGInfoStr82, MCFGInfoStr83, MCFGInfoStr84, MCFGInfoStr85, MCFGInfoStr86,
              MCFGInfoStr87, MCFGInfoStr88, MCFGInfoStr89, MCFGInfoStr90, MCFGInfoStr91,
              MCFGInfoStr92, MCFGInfoStr93, MCFGInfoStr94, MCFGInfoStr95, MCFGInfoStr96,
              MCFGInfoStr97, MCFGInfoStr98, MCFGInfoStr99, MCFGInfoStr100, MCFGInfoStr101,
              MCFGInfoStr102,
              InfoStr2, InfoStr3, InfoStr4, InfoStr5,
              ErrorMsg, WarningMsg;

   bool LoadLangConfig( AnsiString fp );

   void DelChilds( int idx );
};
BOOL OpenFolder(LPSTR szFolder, HWND hwndOwner, int nFolder, bool NewFolderButton );
extern PACKAGE TMainForm *MainForm;
#endif
