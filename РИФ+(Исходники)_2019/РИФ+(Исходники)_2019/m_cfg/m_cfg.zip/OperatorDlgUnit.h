//----------------------------------------------------------------------------
#ifndef OperatorDlgUnitH
#define OperatorDlgUnitH
//----------------------------------------------------------------------------
#include <vcl\Buttons.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Controls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\Graphics.hpp>
#include <vcl\Classes.hpp>
#include <vcl\SysUtils.hpp>
#include <vcl\Windows.hpp>
#include <vcl\System.hpp>
//----------------------------------------------------------------------------
class TOperatorDlg : public TForm
{
__published:
	TLabel *Label1;
	TEdit *Password;
	TButton *OKBtn;
	TButton *CancelBtn;
   TLabel *Label2;
   TEdit *Edit1;
   TLabel *Label3;
   TEdit *Edit2;
   TLabel *Label4;
   TEdit *Edit3;
   void __fastcall FormCreate(TObject *Sender);
   void __fastcall OKBtnClick(TObject *Sender);
   void __fastcall Edit1KeyPress(TObject *Sender, char &Key);
   void __fastcall Edit2KeyPress(TObject *Sender, char &Key);
   void __fastcall Edit3KeyPress(TObject *Sender, char &Key);
   void __fastcall PasswordKeyPress(TObject *Sender, char &Key);
private:
public:
	virtual __fastcall TOperatorDlg(TComponent* AOwner);
};
//----------------------------------------------------------------------------
extern PACKAGE TOperatorDlg *OperatorDlg;
//----------------------------------------------------------------------------
#endif    
