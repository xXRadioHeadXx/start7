#define NO_WIN32_LEAN_AND_MEAN
#include <vcl.h>
#include <IniFiles.hpp>
#include <winsock.h>
#include <memory>
#include <stdio.h>
#pragma hdrstop

#include "MainUnit.h"
#include "TChooseVersionDlgUnit.h"
#include "TAdmAuditUnit.h"
#include "IconDlgUnit.h"
#include "MySQLDlgUnit.h"
#include "MyApiUnit.h"
#include "EseU485IOUnit.h"
#include "usb_uart.h"
#include "MyappErrcode.h"
#include "OperatorDlgUnit.h"
#include "WriteFormUnit.h"
#pragma package(smart_init)
#pragma link "CSPIN"
#pragma link "AdvGrid"
#pragma link "BaseGrid"
#pragma resource "*.dfm"
#pragma warn -aus -inl
TMainForm *MainForm;
__fastcall TMainForm::TMainForm(TComponent* Owner)
   : TForm(Owner)
{
}
void __fastcall TMainForm::FormCreate(TObject *Sender)
{
   VersionInfoStr = "r.12.11.2019";

   ComboBox35->Enabled = false;

   ComplexVersion = RifxComplexType;
   GobiFixNewWarning = 0;

   I1Img = new Graphics::TBitmap;
   I1Img->Transparent = true;

   ImageList1->GetBitmap(12,I1Img);

   
   AnsiString str = ExtractFileName(Application->ExeName);
   if( str.Pos("ssoi") != 0 ) ComplexVersion = SsoiComplexType;

   
   if( FileExists(ExtractFilePath(Application->ExeName)+"ssoi.ver") )
      ComplexVersion = SsoiComplexType;

   
   str = ExtractFileName(Application->ExeName);
   if( str.Pos("rastrmssoi") != 0 ) ComplexVersion = Rastr_M_SsoiComplexType;

   
   if( FileExists(ExtractFilePath(Application->ExeName)+"rastrmssoi.ver") )
      ComplexVersion = Rastr_M_SsoiComplexType;

   
   str = ExtractFileName(Application->ExeName);
   if( str.Pos("rastrmtv") != 0 ) ComplexVersion = Rastr_M_TvComplexType;

   
   if( FileExists(ExtractFilePath(Application->ExeName)+"rastrmtv.ver") )
      ComplexVersion = Rastr_M_TvComplexType;

   Screen->MenuFont->Name="Microsoft Sans Serif";
   Screen->MenuFont->Charset=DEFAULT_CHARSET;

   LoadLangConfig( ExtractFilePath(Application->ExeName) +"Lang1.ini" );

   HANDLE hFile = INVALID_HANDLE_VALUE;
   hMapCfg = CreateFileMapping(hFile, NULL, PAGE_READWRITE, 0, sizeof(TOutObj), "CfgMappingObject");
   if( hMapCfg != NULL )
   {
     lpMapCfg = MapViewOfFile(hMapCfg, FILE_MAP_WRITE, 0, 0, 0);
     if( lpMapCfg == NULL )
     {
        MessageBox (NULL,MsgStr6.c_str(),ErrorMsg.c_str(),MB_OK|MB_ICONERROR);
        Application->Terminate();
     }
   }
   else
   {
      MessageBox (NULL,MsgStr6.c_str(),ErrorMsg.c_str(),MB_OK|MB_ICONERROR);
      Application->Terminate();
   }

   hMapPlan = CreateFileMapping(hFile, NULL, PAGE_READWRITE, 0, sizeof(TOutObj), "PlanMappingObject");
   if( hMapPlan != NULL )
   {
     lpMapPlan = MapViewOfFile(hMapPlan, FILE_MAP_READ, 0, 0, 0);
     if( lpMapPlan == NULL )
     {
        MessageBox (NULL,MsgStr6.c_str(),ErrorMsg.c_str(),MB_OK|MB_ICONERROR);
        Application->Terminate();
     }
   }
   else
   {
      MessageBox (NULL,MsgStr6.c_str(),ErrorMsg.c_str(),MB_OK|MB_ICONERROR);
      Application->Terminate();
   }

   POutObj(lpMapCfg)->CfgMode = true;

   ShowObjGroupBox();

   ShowKeyGenGroupBox();

   OpList = new TSysOperatorList();

   FileNewItemClick(this);

   CfgTimer->Enabled = true;


   GroupBox16->Visible = false;
   GroupBox16->Enabled = false;

   CheckBox2->Visible = false;
   CheckBox2->Checked = false;
   CheckBox3->Visible = false;
   CheckBox3->Checked = false;

   Label15->Visible = false;
   ComboBox11->Visible = false;
   ComboBox11->ItemIndex = 0;

   KedrImportItem->Visible = false;

   GroupBox14->Visible = false;

   if( ComplexVersion == SsoiComplexType )
   {
      CheckBox2->Visible = true;
      CheckBox3->Visible = true;

      KeyGenGroupBox->Enabled = false;
      KeyGenGroupBox->Visible = false;

      GroupBox9->Enabled = false;
      GroupBox9->Visible = false;

      GroupBox8->Enabled = false;
      GroupBox8->Visible = false;

      GroupBox7->Enabled = false;
      GroupBox7->Visible = false;


      GroupBox14->Visible = true;

      Label91->Visible = false;
      ComboBox34->Visible = false;
   }
   else if( ComplexVersion == Rastr_M_SsoiComplexType )
   {
      CheckBox2->Visible = true;
      CheckBox3->Visible = true;

      ComboBox16->Items->Clear();
      ComboBox16->Items->Add("������");
      ComboBox16->Items->Add("��");
      ComboBox16->Items->Add("��");
      ComboBox16->Items->Add("��-������ \"�����-�-��\"");
      ComboBox16->ItemIndex = GroupIdx;

      KeyGenGroupBox->Enabled = false;
      KeyGenGroupBox->Visible = false;

      GroupBox9->Enabled = false;
      GroupBox9->Visible = false;

      GroupBox14->Enabled = false;
      GroupBox14->Visible = false;

      GroupBox17->Enabled = false;
      GroupBox17->Visible = false;

      GroupBox6->Enabled = false;
      GroupBox6->Visible = false;

      GroupBox7->Enabled = false;
      GroupBox7->Visible = false;

      GroupBox8->Enabled = false;
      GroupBox8->Visible = false;

      GroupBox1->Enabled = false;
      GroupBox1->Visible = false;

      GroupBox16->Visible = true;
      GroupBox16->Enabled = true;

      Label91->Visible = false;
      ComboBox34->Visible = false;
   }
   else if( ComplexVersion == Rastr_M_TvComplexType )
   {
      GroupBox24->Visible = false;
      GroupBox24->Enabled = false;

      PlanGroupBox->Enabled = false;
      PlanGroupBox->Visible = false;

      ComboBox16->Items->Clear();
      ComboBox16->Items->Add("��-������ \"�����-�-��\"");
      ComboBox16->ItemIndex = 0;

      KeyGenGroupBox->Enabled = true;
      KeyGenGroupBox->Visible = true;

      GroupBox9->Enabled = false;
      GroupBox9->Visible = false;

      GroupBox17->Enabled = false;
      GroupBox17->Visible = false;

      GroupBox6->Enabled = false;
      GroupBox6->Visible = false;

      GroupBox8->Enabled = false;
      GroupBox8->Visible = false;

      GroupBox7->Enabled = false;
      GroupBox7->Visible = false;

      GroupBox14->Enabled = false;
      GroupBox14->Visible = false;

      GroupBox12->Enabled = false;
      GroupBox12->Visible = false;

      GroupBox16->Enabled = false;
      GroupBox16->Visible = false;

      GroupBox4->Enabled = false;
      GroupBox4->Visible = false;

      ComboBox15->Items->Clear();
      ComboBox15->Items->Add("����");
      ComboBox15->Items->Add("������");
      ComboBox15->Items->Add("����");
      ComboBox15->Items->Add("����, ����");
      ComboBox15->ItemIndex = 0;

      KedrImportItem->Visible = true;

      Label91->Visible = false;
      ComboBox34->Visible = false;
   }
   else
   {

      CheckBox2->Visible = true;
      CheckBox3->Visible = true;
   }

   Caption = Caption + " - " + VersionInfoStr;
}
void __fastcall TMainForm::FormClose(TObject *Sender, TCloseAction &Action)
{
   
   POutObj(lpMapCfg)->CfgMode = false;
   CfgTimer->Enabled = false;

   if( lpMapCfg ) UnmapViewOfFile( lpMapCfg );
   lpMapCfg = 0;

   if( hMapCfg ) CloseHandle( hMapCfg );
   hMapCfg = 0;

   if( lpMapPlan ) UnmapViewOfFile( lpMapPlan );
   lpMapPlan = 0;

   if( hMapPlan ) CloseHandle( hMapPlan );
   hMapPlan = 0;

   delete OpList;
   delete I1Img;
}
void __fastcall TMainForm::ExitItemClick(TObject *Sender)
{
   Close();
}
void TMainForm::ShowObjGroupBox()
{
   Label1->Visible = true;
   Edit1->Text = "";
   Edit1->Enabled = true;
   Edit1->Visible = true;
   Edit1->MaxLength = 25;

   Label2->Visible = false;
   ComboBox1->Items->Clear();
   ComboBox1->Enabled = false;
   ComboBox1->Visible = false;
   ComboBox1->Width = 97;

   Label3->Visible = false;
   ComboBox2->Items->Clear();
   ComboBox2->Enabled = false;
   ComboBox2->Visible = false;

   Label4->Visible = false;
   Label4->Left = 224;
   ComboBox3->Items->Clear();
   ComboBox3->Enabled = false;
   ComboBox3->Visible = false;
   ComboBox3->Left = 224;

   Label67->Visible = false;
   ComboBox28->Visible = false;

   Label68->Visible = false;
   Edit14->Visible = false;
   Edit14->Text = "";
   Label69->Visible = false;
   Edit12->Visible = false;
   Edit12->Text = "";
   Label70->Visible = false;
   Edit13->Visible = false;
   Edit13->Text = "";

   Label39->Visible = false;
   RxSpinEdit4->Visible = false;
   Label78->Visible = false;
   Label78->Caption = "� ��������� ����";
   Label78->Left = 448;
   RxSpinEdit5->Visible = false;
   RxSpinEdit5->Left = 448;

   Label79->Visible = false;
   Label79->Left = 296;
   Label79->Caption = "IP-�����";
   Edit16->Visible = false;
   Edit16->Left = 296;

   GroupBox25->Visible = false;
   Edit17->Text = "";
   RxSpinEdit6->Value = 0.0;
   RxSpinEdit7->Value = 0.0;

   CSpinEdit4->Visible = false;

   Label7->Visible = false;
   ComboBox35->Visible = false;

   GroupBox27->Visible = false;

   Image1->Picture->Bitmap->Dormant();
   Image1->Picture->Bitmap->FreeImage();
   Image1->Visible = false;

   AnsiString str;
   if( ComplexVersion == Rastr_M_TvComplexType )
   {
      Label2->Caption = "����������";
      Label2->Visible = true;
      ComboBox1->Enabled = true;
      ComboBox1->Width = ComboBox1->Width*2;
      ComboBox1->Items->Clear();
      if( RastrmtvDevSn[0] == "" ) ComboBox1->Items->Add("�� ����������");
      else
      {
         AnsiString str;
         for( int i = 0; i < 4; i++ )
            if( RastrmtvDevSn[i] != "" )
            {
               str.sprintf("%d-%s(%s)", i+1, RastrmtvDevName[i], RastrmtvDevSn[i]);
               ComboBox1->Items->Add(str);
            }
      }
      ComboBox1->ItemIndex = 0;
      ComboBox1->Visible = true;

      Label4->Caption = "��-������";
      Label4->Visible = true;
      ComboBox3->Enabled = true;
      for( int i = 0; i < 128; i++ )
      {
         str.sprintf("%02d", i+1);
         ComboBox3->Items->Add(str);
      }
      ComboBox3->ItemIndex = 0;
      ComboBox3->Visible = true;
   }
   else
   {
       if( ComplexVersion != Rastr_M_SsoiComplexType )
       {
           if( ComboBox16->ItemIndex == RifIdx ||       
               ComboBox16->ItemIndex == SdConcIdx ||    
               ComboBox16->ItemIndex == TorosIdx ||     
               ComboBox16->ItemIndex == NastIdx ||      
               ComboBox16->ItemIndex == RadarIdx ||     
               ComboBox16->ItemIndex == RazrivBoIdx ||  
               ComboBox16->ItemIndex == TochkaIdx ||    
               ComboBox16->ItemIndex == SdIpBlIdx ||    
               ComboBox16->ItemIndex == IuIpBlIdx ||    
               ComboBox16->ItemIndex == RifRlmSIdx )    
           {
              Label4->Left = 448;
              ComboBox3->Left = 448;
              Label78->Caption = "����";
              Label7->Visible = true;
              ComboBox35->Visible = true;

              if( ComboBox16->ItemIndex == RifIdx ||
                  ComboBox16->ItemIndex == TorosIdx ||     
                  ComboBox16->ItemIndex == NastIdx ||      
                  ComboBox16->ItemIndex == RadarIdx ||     
                  ComboBox16->ItemIndex == RazrivBoIdx ||  
                  ComboBox16->ItemIndex == RifRlmSIdx )    
              {
                 ImageList2->GetBitmap(6,Image1->Picture->Bitmap);
              }
              else if( ComboBox16->ItemIndex == SdConcIdx ||
                       ComboBox16->ItemIndex == SdIpBlIdx )
              {
                 ImageList2->GetBitmap(11,Image1->Picture->Bitmap);
              }
              else if( ComboBox16->ItemIndex == TochkaIdx )
              {
                 ImageList2->GetBitmap(16,Image1->Picture->Bitmap);
              }
              else if( ComboBox16->ItemIndex == IuIpBlIdx )
              {
                 ImageList2->GetBitmap(29,Image1->Picture->Bitmap);
              }
              Image1->Visible = true;

              Label2->Caption = "�����";
              Label2->Visible = true;
              ComboBox1->Enabled = true;
              if( ComboBox16->ItemIndex == RazrivBoIdx )   
              {
                 for( int i = 0; i < 4; i++ )
                 {
                    str.sprintf("%03d", i+1);
                    ComboBox1->Items->Add(str);
                 }
              }
              else
              {
                 for( int i = 0; i < MaxRifDev-1; i++ )
                 {
                    str.sprintf("%03d", i+1);
                    ComboBox1->Items->Add(str);
                 }
              }
              ComboBox1->ItemIndex = 0;
              ComboBox1->Visible = true;

              if( ComboBox16->ItemIndex != IuIpBlIdx ) GroupBox25->Visible = true;

              if( ComboBox16->ItemIndex == RifIdx )
              {
                 Label3->Caption = "���";
                 Label3->Visible = true;
                 ComboBox2->Enabled = true;
                 ComboBox2->Items->Add("���-���");
                 ComboBox2->Items->Add("���-���24");
                 ComboBox2->Items->Add("���-���(�)");
                 ComboBox2->Items->Add("���-���");
                 ComboBox2->Items->Add("������");
                 ComboBox2->Items->Add("������-1�");
                 ComboBox2->ItemIndex = 0;
                 ComboBox2->Visible = true;
              }

              Label4->Caption = "COM-����";
              Label4->Visible = true;
              ComboBox3->Enabled = true;
              for( int i = 0; i < MaxPortCnt; i++ )
              {
                 str.sprintf("%03d", i+1);
                 ComboBox3->Items->Add(str);
              }
              ComboBox3->ItemIndex = 0;
              ComboBox3->Visible = true;

              ComboBox35Change(this);

              if( ComboBox16->ItemIndex == SdConcIdx ||
                  ComboBox16->ItemIndex == RazrivBoIdx )
              {
                 Label3->Caption = "��";
                 Label3->Visible = true;
                 ComboBox2->Enabled = true;

                 for( int i = 0; i < MaxRifSdDev; i++ )
                 {
                    str.sprintf("%d", i+1);
                    ComboBox2->Items->Add(str);
                 }
                 ComboBox2->ItemIndex = 0;
                 ComboBox2->Visible = true;
              }
              else if( ComboBox16->ItemIndex == TochkaIdx ) 
              {
                 Label3->Caption = "�������/��";
                 Label3->Visible = true;
                 ComboBox2->Enabled = true;
                 for( int i = 0; i < 4; i++ )
                 {
                    str.sprintf("%d", i+1);
                    ComboBox2->Items->Add(str);
                 }
                 ComboBox2->ItemIndex = 0;
                 ComboBox2->Visible = true;

              }
              else if( ComboBox16->ItemIndex == SdIpBlIdx || ComboBox16->ItemIndex == IuIpBlIdx )
              {
                 Label2->Caption = "��";
                 Label2->Visible = false;
                 ComboBox1->Items->Clear();
                 str = "255";
                 ComboBox1->Items->Add(str);
                 ComboBox1->ItemIndex = 0;
                 ComboBox1->Visible = false;

                 ComboBox3->Items->Clear();
                 for( int i = 0; i < MaxPortCnt; i++ )
                 {
                    str.sprintf("%03d", i+1);
                    ComboBox3->Items->Add(str);
                 }
                 ComboBox3->ItemIndex = 0;

                 if( ComboBox16->ItemIndex == SdIpBlIdx )
                 {
                    Label3->Caption = "��";
                    Label3->Visible = true;
                    ComboBox2->Enabled = true;

                    for( int i = 0; i < MaxSdIpBlDev; i++ )
                    {
                       str.sprintf("%d", i+1);
                       ComboBox2->Items->Add(str);
                    }
                    ComboBox2->ItemIndex = 0;
                    ComboBox2->Visible = true;
                 }
                 else if( ComboBox16->ItemIndex == IuIpBlIdx )
                 {
                    Label3->Caption = "��";
                    Label3->Visible = true;
                    ComboBox2->Enabled = true;

                    for( int i = 0; i < MaxIuIpBlDev; i++ )
                    {
                       str.sprintf("%d", i+1);
                       ComboBox2->Items->Add(str);
                    }
                    ComboBox2->ItemIndex = 0;
                    ComboBox2->Visible = true;
                 }
              }
           }
           else if( ComboBox16->ItemIndex == SdIdx || 
                    ComboBox16->ItemIndex == IuIdx || 
                    ComboBox16->ItemIndex == SsoiIdx ) 
           {

              if( ComboBox16->ItemIndex == SdIdx ) 
              {
                 ImageList2->GetBitmap(1,Image1->Picture->Bitmap);
              }
              else if( ComboBox16->ItemIndex == IuIdx ) 
              {
                 ImageList2->GetBitmap(29,Image1->Picture->Bitmap);
              }
              else if( ComboBox16->ItemIndex == SsoiIdx ) 
              {
                 ImageList2->GetBitmap(37,Image1->Picture->Bitmap);
              }
              Image1->Visible = true;

              Label2->Caption = MsgStr27;               Label2->Visible = true;
              ComboBox1->Enabled = true;
              for( int i = 0; i < MaxKanalDev; i++ )
              {
                 str.sprintf("%d", i+1);
                 ComboBox1->Items->Add(str);
              }
              ComboBox1->ItemIndex = 0;
              ComboBox1->Visible = true;

              Label3->Caption = MsgStr28;               Label3->Visible = true;
              ComboBox2->Enabled = true;
              if( SsoiVersion == 2 )
              {
                  for( int i = 0; i < MaxBlDev; i++ )
                  {
                     str.sprintf("%02d", i+1);
                     ComboBox2->Items->Add(str);
                  }
              }
              else
              {
                  for( int i = 0; i < 15; i++ )
                  {
                     str.sprintf("%02d", i+1);
                     ComboBox2->Items->Add(str);
                  }
              }
              ComboBox2->ItemIndex = 0;
              ComboBox2->Visible = true;

              if( ComboBox16->ItemIndex == SdIdx ) 
              {
                 Label67->Visible = true;
                 ComboBox28->Visible = true;

                 GroupBox25->Visible = true;

                 Label4->Caption = MsgStr29;                  Label4->Visible = true;
                 ComboBox3->Enabled = true;
                 for( int i = 0; i < MaxSdDev; i++ )
                 {
                    str.sprintf("%d", i+1);
                    ComboBox3->Items->Add(str);
                 }
                 if( SsoiVersion == 1 || SsoiVersion == 2  ) ComboBox3->Items->Add(MCFGInfoStr27);

                 ComboBox3->ItemIndex = 0;
                 ComboBox3->Visible = true;

                 RxSpinEdit4->Value = 0;
                 RxSpinEdit5->Value = 0;
                 Label39->Visible = ComboBox17->ItemIndex;
                 RxSpinEdit4->Visible = ComboBox17->ItemIndex;
                 Label78->Visible = ComboBox17->ItemIndex;
                 RxSpinEdit5->Visible = ComboBox17->ItemIndex;
              }
              else if( ComboBox16->ItemIndex == IuIdx ) 
              {
                 Label4->Caption = MsgStr30;                  Label4->Visible = true;
                 ComboBox3->Enabled = true;
                 for( int i = 0; i < MaxIuDev; i++ )
                 {
                    str.sprintf("%s%d",MsgStr30, i+1);
                    ComboBox3->Items->Add(str);
                 }
                 if( SsoiVersion == 2 )
                 {
                    for( int i = 0; i < MaxVkDev; i++ )
                    {
                       str.sprintf("%s%d", MsgStr31,i+1);
                       ComboBox3->Items->Add(str);
                    }
                 }
                 ComboBox3->ItemIndex = 0;
                 ComboBox3->Visible = true;
              }
              else if( ComboBox16->ItemIndex == SsoiIdx ) 
              {
                 Label1->Visible = false;
                 Edit1->Enabled = false;
                 Edit1->Visible = false;
                 Label4->Caption = MsgStr33;                  Label4->Visible = true;
                 ComboBox3->Enabled = true;
                 for( int i = 0; i < MaxIuDev; i++ )
                 {
                    str.sprintf("%d", i+1);
                    ComboBox3->Items->Add(str);
                 }
                 ComboBox3->ItemIndex = 0;
                 ComboBox3->Visible = true;
              }
           }
           else if( ComboBox16->ItemIndex == RastrIdx ||    
                    ComboBox16->ItemIndex == Stn1Idx  )   
           {
              ImageList2->GetBitmap(37,Image1->Picture->Bitmap);
              Image1->Visible = true;

              Label1->Visible = false;

              Edit1->Enabled = false;
              Edit1->Visible = false;

              Label2->Caption = MsgStr34;               Label2->Visible = true;
              ComboBox1->Enabled = true;
              int MonitorCnt =  MaxMonitorDev;
              if( ComboBox16->ItemIndex == RastrIdx  ) MonitorCnt = 2;  
              for( int i = 0; i < MonitorCnt; i++ )
              {
                 str.sprintf("%d", i+1);
                 ComboBox1->Items->Add(str);
              }
              ComboBox1->ItemIndex = 0;
              ComboBox1->Visible = true;

              Label3->Caption = MsgStr33;               Label3->Visible = true;
              ComboBox2->Enabled = true;
              for( int i = 0; i < MaxTvDev; i++ )
              {
                 str.sprintf("%02d", i);
                 ComboBox2->Items->Add(str);
              }
              ComboBox2->ItemIndex = 0;
              ComboBox2->Visible = true;
           }
           else if( ComboBox16->ItemIndex == SolidIdx  )  
           {
              ImageList2->GetBitmap(37,Image1->Picture->Bitmap);
              Image1->Visible = true;

              Label1->Visible = false;

              Edit1->Enabled = false;
              Edit1->Visible = false;

              Label2->Caption = "��C-������";
              Label2->Visible = true;
              ComboBox1->Enabled = true;
              for( int i = 0; i < MaxTvSolidDev; i++ )
              {
                 str.sprintf("%d", i+1);
                 ComboBox1->Items->Add(str);
              }
              ComboBox1->ItemIndex = 0;
              ComboBox1->Visible = true;
           }
           else if( ComboBox16->ItemIndex == Adam4068Idx ) 
           {
              ImageList2->GetBitmap(29,Image1->Picture->Bitmap);
              Image1->Visible = true;

              Label1->Visible = true;

              Edit1->Enabled = true;
              Edit1->Visible = true;

              Label2->Caption = "�����";
              Label2->Visible = true;
              ComboBox1->Enabled = true;
              for( int i = 0; i < MaxAdam4068Dev; i++ )
              {
                 str.sprintf("%03d", i+1);
                 ComboBox1->Items->Add(str);
              }
              ComboBox1->ItemIndex = 0;
              ComboBox1->Visible = true;

              Label3->Caption = "��";
              Label3->Visible = true;
              ComboBox2->Enabled = true;
              for( int i = 0; i < 8; i++ )
              {
                 str.sprintf("%d", i);
                 ComboBox2->Items->Add(str);
              }
              ComboBox2->ItemIndex = 0;
              ComboBox2->Visible = true;
           }
           else if( ComboBox16->ItemIndex == TabloIdx ) 
           {

              Label1->Visible = false;

              Edit1->Visible = false;


              Label3->Caption = "� �������";
              Label3->Visible = true;
              ComboBox2->Enabled = true;
              for( int i = 1; i < 1000; i++ )
              {
                 str.sprintf("%03d", i);
                 ComboBox2->Items->Add(str);
              }
              ComboBox2->ItemIndex = 0;
              ComboBox2->Visible = true;
           }
           else if( ComboBox16->ItemIndex == Stn485Idx ) 
           {
              ImageList2->GetBitmap(37,Image1->Picture->Bitmap);
              Image1->Visible = true;

              Label2->Caption = MCFGInfoStr100;               Label2->Visible = true;
              ComboBox1->Width = ComboBox1->Width*2;
              ComboBox1->Enabled = true;
              ComboBox1->Items->Clear();
              if( RastrmtvDevSn[0] == "" ) ComboBox1->Items->Add(MCFGInfoStr101);
              else
              {
                 AnsiString str;
                 for( int i = 0; i < 4; i++ )
                   if( RastrmtvDevSn[i] != "" )
                   {
                      str.sprintf("%d-%s(%s)", i+1, RastrmtvDevName[i], RastrmtvDevSn[i]);
                      ComboBox1->Items->Add(str);
                   }
              }
              ComboBox1->ItemIndex = 0;
              ComboBox1->Visible = true;

              Label4->Caption = MsgStr33;               Label4->Visible = true;
              ComboBox3->Enabled = true;
              for( int i = 0; i < 128; i++ )
              {
                 str.sprintf("%02d", i+1);
                 ComboBox3->Items->Add(str);
              }
              ComboBox3->ItemIndex = 0;
              ComboBox3->Visible = true;
           }
           else if( ComboBox16->ItemIndex == TochkaMBoIdx ||
                    ComboBox16->ItemIndex == SotaMBoIdx )
           {
              Label4->Left = 448;
              ComboBox3->Left = 448;
              Label78->Caption = "����";
              Label7->Visible = true;
              ComboBox35->Visible = true;

              if( ComboBox16->ItemIndex == TochkaMBoIdx )
              {
                 ImageList2->GetBitmap(51,Image1->Picture->Bitmap);
              }
              else if( ComboBox16->ItemIndex == SotaMBoIdx )
              {
                 ImageList2->GetBitmap(51,Image1->Picture->Bitmap);
              }
              Image1->Visible = true;

              Label2->Caption = "�����";
              Label2->Visible = true;
              ComboBox1->Enabled = true;
              for( int i = 0; i < MaxRifDev-1; i++ )
              {
                 str.sprintf("%03d", i+1);
                 ComboBox1->Items->Add(str);
              }
              ComboBox1->ItemIndex = 0;
              ComboBox1->Visible = true;

              GroupBox25->Visible = true;

              Label4->Caption = "COM-����";
              Label4->Visible = true;
              ComboBox3->Enabled = true;
              for( int i = 0; i < MaxPortCnt; i++ )
              {
                 str.sprintf("%03d", i+1);
                 ComboBox3->Items->Add(str);
              }
              ComboBox3->ItemIndex = 0;
              ComboBox3->Visible = true;
           }
           else if( ComboBox16->ItemIndex == TochkaMUchIdx ||
                    ComboBox16->ItemIndex == SotaMUchIdx )
           {
              if( ComboBox16->ItemIndex == TochkaMUchIdx )
              {
                 ImageList2->GetBitmap(44,Image1->Picture->Bitmap);
              }
              else if( ComboBox16->ItemIndex == SotaMUchIdx )
              {
                 ImageList2->GetBitmap(39,Image1->Picture->Bitmap);
              }
              Image1->Visible = true;

              Label1->Visible = true;
              Edit1->Visible = true;
              Label2->Caption = "�������";
              Label2->Visible = true;
              ComboBox1->Enabled = true;
              for( int i = 0; i < 4; i++ )
              {
                 str.sprintf("%d", i+1);
                 ComboBox1->Items->Add(str);
              }
              ComboBox1->ItemIndex = 0;
              ComboBox1->Visible = true;
           }
           else if( ComboBox16->ItemIndex == TochkaMDdIdx ||
                    ComboBox16->ItemIndex == SotaMDdIdx )
           {
              if( ComboBox16->ItemIndex == TochkaMDdIdx )
              {
                 ImageList2->GetBitmap(44,Image1->Picture->Bitmap);
                 Image1->Visible = true;
              }

              Label1->Visible = true;
              Edit1->Visible = true;
              Label2->Caption = "��";
              Label2->Visible = true;
              ComboBox1->Enabled = true;
              if( ComboBox16->ItemIndex == TochkaMDdIdx )
              {
                 for( int i = 0; i < 26; i++ )
                 {
                    str.sprintf("%d", i+1);
                    ComboBox1->Items->Add(str);
                 }
              }
              else if( ComboBox16->ItemIndex == SotaMDdIdx )
              {
                 for( int i = 0; i < 100; i++ )
                 {
                    str.sprintf("%d", i+1);
                    ComboBox1->Items->Add(str);
                 }
              }

              ComboBox1->ItemIndex = 0;
              ComboBox1->Visible = true;
              GroupBox25->Visible = true;
           }
           else if( ComboBox16->ItemIndex == StrazhIpIdx ) 
           {
              ImageList2->GetBitmap(37,Image1->Picture->Bitmap);
              Image1->Visible = false;

              Label1->Visible = true;
              Edit1->Visible = true;

              Label68->Visible = true;
              Label68->Caption = "IP-����� ������";
              Edit14->Visible = true;

              Label69->Visible = true;
              Edit12->Visible = true;

              Label70->Visible = true;
              Edit13->Visible = true;

              Label79->Visible = true;
              Label79->Caption = "IP-����� ���������� ���������";
              Edit16->Visible = true;
           }
           else if( ComboBox16->ItemIndex == OnvifTvIdx ) 
           {
              ImageList2->GetBitmap(37,Image1->Picture->Bitmap);
              Image1->Visible = false;

              Label1->Visible = true;
              Edit1->Visible = true;

              Label68->Visible = true;
              Label68->Caption = "IP-�����";
              Edit14->Visible = true;

              Label69->Visible = true;
              Edit12->Visible = true;

              Label70->Visible = true;
              Edit13->Visible = true;
           }
           else if( ComboBox16->ItemIndex == DevLineIdx ) 
           {
              ImageList2->GetBitmap(37,Image1->Picture->Bitmap);
              Image1->Visible = false;

              Label1->Visible = false;
              Edit1->Visible = false;

              Label2->Caption = "�����";
              Label2->Visible = true;
              CSpinEdit4->Visible = true;

              Label3->Caption = "�����";
              Label3->Visible = true;
              ComboBox2->Enabled = true;
              ComboBox2->Items->Clear();
              ComboBox2->Items->Add("0");
              ComboBox2->Items->Add("1");
              ComboBox2->ItemIndex = 0;
              ComboBox2->Visible = true;

              GroupBox27->Visible = true;
           }
           else if( ComboBox16->ItemIndex == NetDeviceIdx )
           {
              Label1->Visible = true;
              Edit1->Visible = true;

              Label68->Visible = true;
              Label68->Caption = "IP-����� ��� ������� ���";
              Edit14->Visible = true;

              ImageList2->GetBitmap(55,Image1->Picture->Bitmap);
              Image1->Visible = true;
          }
       }
       else
       {
          if( ComboBox16->ItemIndex == 1 ) 
          {
              Label2->Caption = "�����";
              Label2->Visible = true;

              GroupBox25->Visible = true;

              ComboBox1->Enabled = true;
              for( int i = 0; i < 4; i++ )
              {
                 str.sprintf("%d", i+1);
                 ComboBox1->Items->Add(str);
              }
              ComboBox1->ItemIndex = 0;
              ComboBox1->Visible = true;

              Label3->Caption = "��";
              Label3->Visible = true;
              ComboBox2->Enabled = true;
              for( int i = 0; i < 127; i++ )
              {
                 str.sprintf("%02d", i+1);
                 ComboBox2->Items->Add(str);
              }
              ComboBox2->ItemIndex = 0;
              ComboBox2->Visible = true;

              Label1->Visible = true;
              Label4->Caption = "��";
              Label4->Visible = true;
              ComboBox3->Enabled = true;
              for( int i = 0; i < 4; i++ )
              {
                 str.sprintf("%d", i+1);
                 ComboBox3->Items->Add(str);
              }
              str = "��������";
              ComboBox3->Items->Add(str);

              ComboBox3->ItemIndex = 0;
              ComboBox3->Visible = true;
          }
          else if( ComboBox16->ItemIndex == 2 ) 
          {
              Label2->Caption = "�����";
              Label2->Visible = true;
              ComboBox1->Enabled = true;
              for( int i = 0; i < 4; i++ )
              {
                 str.sprintf("%d", i+1);
                 ComboBox1->Items->Add(str);
              }
              ComboBox1->ItemIndex = 0;
              ComboBox1->Visible = true;

              Label3->Caption = "��";
              Label3->Visible = true;
              ComboBox2->Enabled = true;
              for( int i = 0; i < 127; i++ )
              {
                 str.sprintf("%02d", i+1);
                 ComboBox2->Items->Add(str);
              }
              ComboBox2->ItemIndex = 0;
              ComboBox2->Visible = true;

              Label1->Visible = true;
              Label4->Caption = "��";
              Label4->Visible = true;
              ComboBox3->Enabled = true;
              str.sprintf("%d", 1);
              ComboBox3->Items->Add(str);
              ComboBox3->ItemIndex = 0;
              ComboBox3->Visible = true;
          }
          else if( ComboBox16->ItemIndex == 3 )   
          {
              Label2->Caption = MCFGInfoStr100;               Label2->Visible = true;
              ComboBox1->Enabled = true;
              ComboBox1->Items->Clear();
              if( RastrmtvDevSn[0] == "" ) ComboBox1->Items->Add(MCFGInfoStr101);
              else
              {
                 AnsiString str;
                 for( int i = 0; i < 4; i++ )
                   if( RastrmtvDevSn[i] != "" )
                   {
                      str.sprintf("%d-%s(%s)", i+1, RastrmtvDevName[i], RastrmtvDevSn[i]);
                      ComboBox1->Items->Add(str);
                   }
              }
              ComboBox1->ItemIndex = 0;
              ComboBox1->Visible = true;

              Label3->Caption = "�����";
              Label3->Visible = true;
              ComboBox2->Enabled = true;
              for( int i = 0; i < 4; i++ )
              {
                 str.sprintf("%2d", i+1);
                 ComboBox2->Items->Add(str);
              }
              ComboBox2->ItemIndex = 0;
              ComboBox2->Visible = true;

              Label4->Caption = "��-������";
              Label4->Visible = true;
              ComboBox3->Enabled = true;
              for( int i = 0; i < 128; i++ )
              {
                 str.sprintf("%02d", i+1);
                 ComboBox3->Items->Add(str);
              }
              ComboBox3->ItemIndex = 0;
              ComboBox3->Visible = true;
          }
       }
   }
}
void __fastcall TMainForm::BitBtn1Click(TObject *Sender)
{


   
   ObjTree->Items->BeginUpdate();

   TTreeNode* tempNode;

   AnsiString Name = Edit1->Text;
   int Type = 0;
   int Num1 = 0;
   int Num2 = 0;
   int Num3 = 0;
   AnsiString DevSn;
   AnsiString DevName;
   AnsiString IpStr = Edit14->Text;
   AnsiString LoginStr = Edit12->Text;
   AnsiString PasswordStr = Edit13->Text;
   AnsiString Ip2Str = Edit16->Text;
   int AdamOff = 0;
   bool Udp = ComboBox35->ItemIndex;
   AnsiString UdpAdress = Edit16->Text;
   int UdpPort = RxSpinEdit5->Value;

   if( ComplexVersion == Rastr_M_TvComplexType )
   {
      if( RastrmtvDevSn[ComboBox1->ItemIndex] != "" )
      {
         Type = 42;
         Num1 = ComboBox1->ItemIndex+1;
         Num2 = ComboBox2->ItemIndex+1;
         Num3 = ComboBox3->ItemIndex+1;
         DevSn = RastrmtvDevSn[ComboBox1->ItemIndex];
         DevName = RastrmtvDevName[ComboBox1->ItemIndex];

         if( Name.IsEmpty() ) MessageBox( NULL, MCFGInfoStr90.c_str(), ErrorMsg.c_str(), MB_OK|MB_ICONERROR );
         else
         {

               {
                  if( PCfgObj(ObjTree->Selected->Data)->Type == 0 || PCfgObj(ObjTree->Selected->Data)->Type == 100 )
                  {
                     PCfgObj  CfgObj;
                     CfgObj = new TCfgObj;

                     CfgObj->Type = Type;
                     CfgObj->Num1 = Num1;
                     CfgObj->Num2 = Num2;
                     CfgObj->Num3 = Num3;
                     CfgObj->Name = Name;
                     CfgObj->Icon1Path = DevSn;
                     CfgObj->Icon2Path = DevName;

                     tempNode = ObjTree->Selected;

                     if( PCfgObj(ObjTree->Selected->Data)->Type == 0 )
                     {
                        tempNode->SelectedIndex = 5;
                        tempNode->ImageIndex = 5;
                     }

                     tempNode = ObjTree->Items->AddChildObject( ObjTree->Selected, CfgObj->Name, CfgObj );
                     tempNode->SelectedIndex = 11;
                     tempNode->ImageIndex = 11;

                  }
               }
         }
      }
      else
      {
         MessageBox( NULL, MCFGInfoStr92.c_str(), ErrorMsg.c_str(), MB_OK|MB_ICONERROR );
         goto mmm1;
      }
   }
   else
   {
       if( ComplexVersion != Rastr_M_SsoiComplexType )
       {
           if( Name.IsEmpty() &&
               ComboBox16->ItemIndex != RastrIdx &&
               ComboBox16->ItemIndex != Stn485Idx &&
               ComboBox16->ItemIndex != Stn1Idx &&
               ComboBox16->ItemIndex != SolidIdx &&
               ComboBox16->ItemIndex != 42 &&
               ComboBox16->ItemIndex != TabloIdx &&
               ComboBox16->ItemIndex != DevLineIdx )
           {
              MessageBox( NULL, MCFGInfoStr94.c_str(), ErrorMsg.c_str(), MB_OK|MB_ICONERROR );
           }
           else
           {
              bool IconVisible = false;
              int ImgNum = 0;

              if( ComboBox16->ItemIndex == StrazhIpIdx )
              {
                  if( IpStr.IsEmpty() )
                  {
                     MessageBox( NULL, "�� ����� IP-����� ��� �����-IP!", ErrorMsg.c_str(), MB_OK|MB_ICONERROR );
                     goto mmm1;
                  }

                  if( LoginStr.IsEmpty() )
                  {
                     MessageBox( NULL, "�� ����� ����� ��� �����-IP!", ErrorMsg.c_str(), MB_OK|MB_ICONERROR );
                     goto mmm1;
                  }

                  if( PasswordStr.IsEmpty() )
                  {
                     MessageBox( NULL, "�� ����� ������ ��� �����-IP!", ErrorMsg.c_str(), MB_OK|MB_ICONERROR );
                     goto mmm1;
                  }

                  if( Ip2Str.IsEmpty() )
                  {
                     MessageBox( NULL, "�� ����� IP-����� ���������� ���������!", ErrorMsg.c_str(), MB_OK|MB_ICONERROR );
                     goto mmm1;
                  }

                  Type = 24;
                  ImgNum = 48;
                  IconVisible = false;
              }

              if( ComboBox16->ItemIndex == OnvifTvIdx )
              {
                  if( IpStr.IsEmpty() )
                  {
                     MessageBox( NULL, "�� ����� IP-����� ��� ONVIF-������!", ErrorMsg.c_str(), MB_OK|MB_ICONERROR );
                     goto mmm1;
                  }

                  if( LoginStr.IsEmpty() )
                  {
                     MessageBox( NULL, "�� ����� ����� ��� ONVIF-������!", ErrorMsg.c_str(), MB_OK|MB_ICONERROR );
                     goto mmm1;
                  }

                  if( PasswordStr.IsEmpty() )
                  {
                     MessageBox( NULL, "�� ����� ������ ��� ONVIF-������!", ErrorMsg.c_str(), MB_OK|MB_ICONERROR );
                     goto mmm1;
                  }

                  Type = 25;
                  ImgNum = 48;
                  IconVisible = false;
              }

              if( ComboBox16->ItemIndex == NetDeviceIdx )
              {
                  if( IpStr.IsEmpty() )
                  {
                     MessageBox( NULL, "�� ����� IP-����� ��� �������� ����������!", ErrorMsg.c_str(), MB_OK|MB_ICONERROR );
                     goto mmm1;
                  }

                  Type = 200;
                  IconVisible = false;

                  if( PCfgObj(ObjTree->Selected->Data)->Type != 0 )
                  {
                     ObjTree->Items->EndUpdate();
                     MessageBox( NULL, "������� ���������� ����� ���� ��������� ������ � ������!", "������", MB_OK|MB_ICONERROR );
                     return;
                  }
              }

              if( (ComboBox16->ItemIndex  == RifIdx ||
                  ComboBox16->ItemIndex  == SdConcIdx ||
                  ComboBox16->ItemIndex  == TorosIdx ||
                  ComboBox16->ItemIndex  == NastIdx ||
                  ComboBox16->ItemIndex  == RadarIdx ||
                  ComboBox16->ItemIndex  == RazrivBoIdx ||
                  ComboBox16->ItemIndex  == TochkaIdx ||
                  ComboBox16->ItemIndex  == SdIpBlIdx ||
                  ComboBox16->ItemIndex  == IuIpBlIdx ||
                  ComboBox16->ItemIndex  == RifRlmSIdx ||
                  ComboBox16->ItemIndex  == TochkaMBoIdx ||
                  ComboBox16->ItemIndex  == SotaMBoIdx ) &&
                  ( Edit16->Text == "" || RxSpinEdit5->Value == 0 ) &&
                  ComboBox35->ItemIndex == 1 )
              {
                 ObjTree->Items->EndUpdate();
                 MessageBox( NULL, "�� ������ ��������� UPD-��������� (IP-����� ��� ����)!", "������", MB_OK|MB_ICONERROR );
                 return;
              }

              if( ComboBox16->ItemIndex == RifIdx || ComboBox16->ItemIndex == RifRlmSIdx )
              {
                 if( ComboBox16->ItemIndex == RifIdx )
                 {
                     Type = 1;
                     AdamOff = ComboBox2->ItemIndex;
                 }
                 else if( ComboBox16->ItemIndex == RifRlmSIdx ) Type = 111;
                 Num1 = ComboBox1->ItemIndex+1;
                 Num3 = ComboBox3->ItemIndex+1;
                 IconVisible = true;
                 ImgNum = 5;
              }
              else if( ComboBox16->ItemIndex == SdConcIdx )
              {
                 Type = 2;
                 Num1 = ComboBox1->ItemIndex+1;
                 Num2 = ComboBox2->ItemIndex+1;
                 Num3 = ComboBox3->ItemIndex+1;
                 IconVisible = true;
                 ImgNum = 10;
              }
              else if( ComboBox16->ItemIndex == RazrivBoIdx )
              {
                 Type = 21;
                 Num1 = ComboBox1->ItemIndex+1;
                 Num2 = ComboBox2->ItemIndex+1;
                 Num3 = ComboBox3->ItemIndex+1;
                 IconVisible = true;
                 ImgNum = 5;
              }
              else if( ComboBox16->ItemIndex == SdIdx  )
              {
                 Type = 3;
                 Num1 = ComboBox1->ItemIndex+1;
                 Num2 = ComboBox2->ItemIndex+1;
                 Num3 = ComboBox3->ItemIndex+1;
                 IconVisible = true;
                 ImgNum = 0;
              }
              else if( ComboBox16->ItemIndex == IuIdx )
              {
                 Type = 4;
                 Num1 = ComboBox1->ItemIndex+1;
                 Num2 = ComboBox2->ItemIndex+1;
                 Num3 = ComboBox3->ItemIndex+1;
                 ImgNum = 28;
                 IconVisible = true;
              }
              else if( ComboBox16->ItemIndex == SsoiIdx )
              {
                 Type = 41;
                 Num1 = ComboBox1->ItemIndex+1;
                 Num2 = ComboBox2->ItemIndex+1;
                 Num3 = ComboBox3->ItemIndex+1;
                 Name.sprintf("%s:%d-%02d-%d", MCFGInfoStr98, Num1, Num2, Num3);
                 ImgNum = 48;
                 IconVisible = true;
              }
              else if( ComboBox16->ItemIndex == Stn485Idx )
              {
                 if( RastrmtvDevSn[ComboBox1->ItemIndex] != "" )
                 {
                    Type = 42;
                    Num1 = ComboBox1->ItemIndex+1;
                    Num2 = ComboBox2->ItemIndex+1;
                    Num3 = ComboBox3->ItemIndex+1;
                    DevSn = RastrmtvDevSn[ComboBox1->ItemIndex];
                    DevName = RastrmtvDevName[ComboBox1->ItemIndex];
                    ImgNum = 48;
                    IconVisible = true;
                 }
                 else
                 {
                    MessageBox( NULL, MCFGInfoStr92.c_str(), ErrorMsg.c_str(), MB_OK|MB_ICONERROR );
                    goto mmm1;
                 }
              }
              else if( ComboBox16->ItemIndex == RastrIdx )
              {
                 Type = 51;
                 Num1 = ComboBox1->ItemIndex+1;
                 Num2 = ComboBox2->ItemIndex;
                 Name.sprintf("%s:%d-%02d", MCFGInfoStr98, Num1, Num2);
                 ImgNum = 48;
                 IconVisible = true;
              }
              else if( ComboBox16->ItemIndex == Stn1Idx )
              {
                 Type = 5;
                 Num1 = ComboBox1->ItemIndex+1;
                 Num2 = ComboBox2->ItemIndex+1;
                 Name.sprintf("%s:%d-%02d", MCFGInfoStr98, Num1, (Num2-1));
                 ImgNum = 48;
                 IconVisible = true;
              }
              else if( ComboBox16->ItemIndex == SolidIdx )
              {
                 Type = 6;
                 Num1 = ComboBox1->ItemIndex+1;
                 Name.sprintf("��C-%03d", Num1);
                 ImgNum = 48;
                 IconVisible = true;
              }
              else if( ComboBox16->ItemIndex == Adam4068Idx )
              {
                 Type = 7;
                 Num1 = ComboBox1->ItemIndex+1;
                 Num2 = ComboBox2->ItemIndex;
                 ImgNum = 28;
                 IconVisible = true;
              }
              else if( ComboBox16->ItemIndex == TabloIdx )
              {
                 Type = 71;
                 Num2 = ComboBox2->ItemIndex+1;
                 Name.sprintf("������� �:%02d", Num2);
                 ImgNum = 0;
              }
              else if( ComboBox16->ItemIndex == TorosIdx )
              {
                 Type = 8;
                 Num1 = ComboBox1->ItemIndex+1;
                 Num3 = ComboBox3->ItemIndex+1;
                 IconVisible = true;
                 ImgNum = 5;
              }
              else if( ComboBox16->ItemIndex == NastIdx )
              {
                 Type = 9;
                 Num1 = ComboBox1->ItemIndex+1;
                 Num3 = ComboBox3->ItemIndex+1;
                 IconVisible = true;
                 ImgNum = 5;
              }
              else if( ComboBox16->ItemIndex == RadarIdx )
              {
                 Type = 91;
                 Num1 = ComboBox1->ItemIndex+1;
                 Num3 = ComboBox3->ItemIndex+1;
                 IconVisible = true;
                 ImgNum = 5;
              }
              else if( ComboBox16->ItemIndex == TochkaIdx )
              {
                 Type = 10;
                 Num1 = ComboBox1->ItemIndex+1;
                 Num2 = ComboBox2->ItemIndex+1;
                 Num3 = ComboBox3->ItemIndex+1;
                 IconVisible = true;
                 ImgNum = 15;
              }
              else if( ComboBox16->ItemIndex == SdIpBlIdx )
              {
                 Type = 11;
                 if( ComboBox1->ItemIndex == 0) Num1 = 255;
                 else Num1 = ComboBox1->ItemIndex;

                 Num2 = ComboBox2->ItemIndex+1;
                 Num3 = ComboBox3->ItemIndex+1;
                 IconVisible = true;
                 ImgNum = 10;
              }
              else if( ComboBox16->ItemIndex == IuIpBlIdx )
              {
                 Type = 12;
                 if( ComboBox1->ItemIndex == 0) Num1 = 255;
                 else Num1 = ComboBox1->ItemIndex;

                 Num2 = ComboBox2->ItemIndex+1;
                 Num3 = ComboBox3->ItemIndex+1;
                 IconVisible = true;
                 ImgNum = 28;
              }
              else if( ComboBox16->ItemIndex == TochkaMBoIdx )
              {
                 Type = 26;
                 Num1 = ComboBox1->ItemIndex+1;
                 Num2 = 0;
                 Num3 = ComboBox3->ItemIndex+1;
                 IconVisible = true;
                 ImgNum = 50;
              }
              else if( ComboBox16->ItemIndex == SotaMBoIdx )
              {
                 Type = 29;
                 Num1 = ComboBox1->ItemIndex+1;
                 Num2 = 0;
                 Num3 = ComboBox3->ItemIndex+1;
                 IconVisible = true;
                 ImgNum = 50;
              }
              else if( ComboBox16->ItemIndex == TochkaMUchIdx )
              {
                 if( PCfgObj(ObjTree->Selected->Data)->Type == 26  )
                 {
                    Type = 27;
                    Num1 = PCfgObj(ObjTree->Selected->Data)->Num1;
                    Num3 = PCfgObj(ObjTree->Selected->Data)->Num3;
                    Num2 = (ComboBox1->ItemIndex+1)*100;
                    IconVisible = true;
                    Udp = PCfgObj(ObjTree->Selected->Data)->UdpUse;
                    UdpAdress = PCfgObj(ObjTree->Selected->Data)->UdpAdress;
                    UdpPort = PCfgObj(ObjTree->Selected->Data)->UpdPort;
                    ImgNum = 43;
                 }
                 else
                 {
                    MessageBox( NULL, "������� ����� ���� �������� ������ � \"��� �����-�/�����-�\"!", "������", MB_OK|MB_ICONERROR );
                    ObjTree->Items->EndUpdate();
                    return;
                 }
              }
              else if( ComboBox16->ItemIndex == SotaMUchIdx )
              {
                 if( PCfgObj(ObjTree->Selected->Data)->Type == 29  )
                 {
                    Type = 30;
                    Num1 = PCfgObj(ObjTree->Selected->Data)->Num1;
                    Num3 = PCfgObj(ObjTree->Selected->Data)->Num3;
                    Num2 = (ComboBox1->ItemIndex+1)*100;
                    IconVisible = true;
                    Udp = PCfgObj(ObjTree->Selected->Data)->UdpUse;
                    UdpAdress = PCfgObj(ObjTree->Selected->Data)->UdpAdress;
                    UdpPort = PCfgObj(ObjTree->Selected->Data)->UpdPort;
                    ImgNum = 38;
                 }
                 else
                 {
                    MessageBox( NULL, "������� ����� ���� �������� ������ � \"��� ����/����-�\"!", "������", MB_OK|MB_ICONERROR );
                    ObjTree->Items->EndUpdate();
                    return;
                 }
              }
              else if( ComboBox16->ItemIndex == TochkaMDdIdx )
              {
                 if( PCfgObj(ObjTree->Selected->Data)->Type == 27  )
                 {
                    Type = 28 ;
                    Num1 = PCfgObj(ObjTree->Selected->Data)->Num1;
                    Num3 = PCfgObj(ObjTree->Selected->Data)->Num3;
                    Num2 = PCfgObj(ObjTree->Selected->Data)->Num2 + ComboBox1->ItemIndex;
                    IconVisible = false;
                    Udp = PCfgObj(ObjTree->Selected->Data)->UdpUse;
                    UdpAdress = PCfgObj(ObjTree->Selected->Data)->UdpAdress;
                    UdpPort = PCfgObj(ObjTree->Selected->Data)->UpdPort;
                    ImgNum = 43;
                 }
                 else
                 {
                    MessageBox( NULL, "�� ����� ���� �������� ������ � \"������� �����-�/�����-�\"!", "������", MB_OK|MB_ICONERROR );
                    ObjTree->Items->EndUpdate();
                    return;
                 }
              }
              else if( ComboBox16->ItemIndex == SotaMDdIdx )
              {
                 if( PCfgObj(ObjTree->Selected->Data)->Type == 30  )
                 {
                    Type = 31 ;
                    Num1 = PCfgObj(ObjTree->Selected->Data)->Num1;
                    Num3 = PCfgObj(ObjTree->Selected->Data)->Num3;
                    Num2 = PCfgObj(ObjTree->Selected->Data)->Num2 + ComboBox1->ItemIndex;
                    IconVisible = false;
                    Udp = PCfgObj(ObjTree->Selected->Data)->UdpUse;
                    UdpAdress = PCfgObj(ObjTree->Selected->Data)->UdpAdress;
                    UdpPort = PCfgObj(ObjTree->Selected->Data)->UpdPort;
                    ImgNum = 38;
                 }
                 else
                 {
                    MessageBox( NULL, "�� ����� ���� �������� ������ � \"������� ����/����-�\"!", "������", MB_OK|MB_ICONERROR );
                    ObjTree->Items->EndUpdate();
                    return;
                 }
              }
              else if( ComboBox16->ItemIndex == DevLineIdx )
              {
                 Type = 32 ;
                 Num1 = CSpinEdit4->Value;
                 Name.sprintf("��-������ %d (����� %d)", Num1, ComboBox2->ItemIndex );
                 IconVisible = false;
                 ImgNum = 48;
                 IconVisible = false;
              }

              int idx = -1;
              for( int i = 0; i < ObjTree->Items->Count; i++ )
              {
                 if( Name == PCfgObj(ObjTree->Items->Item[i]->Data)->Name &&
                     Type == 0 )
                 {
                    idx = i;
                    break;
                 }
              }

              int flag_SotaMDd_Uch24 = 0;
              if( idx == -1 )
              {
                 for( int i = 0; i < ObjTree->Items->Count; i++ )
                 {
                    if( ComboBox16->ItemIndex == RifIdx || ComboBox16->ItemIndex == RifRlmSIdx )
                    {
                       if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 1 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 2 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 8 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 9 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 21 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 91 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 10 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 11 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 12 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 111 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 26 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 29 )
                       {
                          if( !Udp )
                          {
                             if( Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
                                 Num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 )
                             {
                                idx = i;
                                break;
                             }
                          }
                          else
                          {
                             if( Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
                                 UdpAdress == PCfgObj(ObjTree->Items->Item[i]->Data)->UdpAdress )
                             {
                                idx = i;
                                break;
                             }
                          }
                       }
                    }
                    else if( ComboBox16->ItemIndex == SdConcIdx )
                    {
                       if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 1 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 8 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 9 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 91 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 11 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 12 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 111 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 26 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 29 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 21 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 10 )
                       {
                          if( !Udp )
                          {
                              if( Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
                                  Num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 )
                              {
                                 idx = i;
                                 break;
                              }
                          }
                          else
                          {
                             if( Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
                                 UdpAdress == PCfgObj(ObjTree->Items->Item[i]->Data)->UdpAdress )
                             {
                                idx = i;
                                break;
                             }
                          }
                       }

                       if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 2 )
                       {
                          if( !Udp )
                          {
                              if( Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
                                  Num2 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num2 &&
                                  Num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 )
                              {
                                 idx = i;
                                 break;
                              }
                          }
                          else
                          {
                             if( Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
                                 Num2 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num2 &&
                                 UdpAdress == PCfgObj(ObjTree->Items->Item[i]->Data)->UdpAdress )
                             {
                                idx = i;
                                break;
                             }
                          }
                       }
                    }
                    else if( ComboBox16->ItemIndex == RazrivBoIdx )
                    {
                       if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 1 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 8 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 9 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 91 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 11 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 12 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 111 )
                       {
                          if( Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
                              Num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 )
                          {
                             idx = i;
                             break;
                          }
                       }

                       if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 2 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 21 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 10 )
                       {
                          if( Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
                              Num2 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num2 &&
                              Num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 )
                          {
                             idx = i;
                             break;
                          }
                       }
                    }
                    else if( ComboBox16->ItemIndex == SdIdx )
                    {
                       if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 3 )
                       {
                          if( Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
                              Num2 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num2 &&
                              Num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 )
                          {
                             idx = i;
                             break;
                          }
                       }
                    }
                    else if( ComboBox16->ItemIndex == TorosIdx )
                    {
                       if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 1 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 2 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 8 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 9 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 21 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 91 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 10 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 11 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 12 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 111  )
                       {
                          if( Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
                              Num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 )
                          {
                             idx = i;
                             break;
                          }
                       }
                    }
                    else if( ComboBox16->ItemIndex == NastIdx )
                    {
                       if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 1 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 2 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 8 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 9 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 21 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 91 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 10 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 11 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 12 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 111 )
                       {
                          if( Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
                              Num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 )
                          {
                             idx = i;
                             break;
                          }
                       }
                    }
                    else if( ComboBox16->ItemIndex == RadarIdx )
                    {
                       if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 1 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 2 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 8 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 9 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 21 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 91 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 10 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 11 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 12 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 111 )
                       {
                          if( Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
                              Num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 )
                          {
                             idx = i;
                             break;
                          }
                       }
                    }
                    else if( ComboBox16->ItemIndex == TochkaIdx )
                    {
                       if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 1 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 8 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 9 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 91 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 11 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 12 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 111 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 26 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 29 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 2 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 21 )
                       {
                          if( !Udp )
                          {
                             if( Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
                                 Num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 )
                             {
                                idx = i;
                                break;
                             }
                          }
                          else
                          {
                             if( Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
                                 UdpAdress == PCfgObj(ObjTree->Items->Item[i]->Data)->UdpAdress )
                             {
                                idx = i;
                                break;
                             }
                          }
                       }

                       if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 10 )
                       {
                          if( !Udp )
                          {
                            if( Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
                                Num2 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num2 &&
                                Num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 )
                            {
                               idx = i;
                               break;
                            }
                          }
                          else
                          {
                             if( Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
                                 Num2 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num2 &&
                                 UdpAdress == PCfgObj(ObjTree->Items->Item[i]->Data)->UdpAdress )
                             {
                                idx = i;
                                break;
                             }
                          }
                       }
                    }
                    else if( ComboBox16->ItemIndex == SdIpBlIdx )
                    {
                       if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 1 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 8 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 9 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 91 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 2 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 21 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 10 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 111 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 26 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 29 )
                       {
                          if( !Udp )
                          {
                            if( Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
                                Num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 )
                            {
                               idx = i;
                               break;
                            }
                          }
                          else
                          {
                             if( Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
                                 UdpAdress == PCfgObj(ObjTree->Items->Item[i]->Data)->UdpAdress )
                             {
                                idx = i;
                                break;
                             }
                          }
                       }

                       if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 11 )
                       {
                          if( !Udp )
                          {
                            if( Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
                                Num2 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num2 &&
                                Num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 )
                            {
                               idx = i;
                               break;
                            }
                          }
                          else
                          {
                             if( Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
                                 Num2 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num2 &&
                                 UdpAdress == PCfgObj(ObjTree->Items->Item[i]->Data)->UdpAdress )
                             {
                                idx = i;
                                break;
                             }
                          }
                       }
                    }
                    else if( ComboBox16->ItemIndex == TochkaMBoIdx ||
                             ComboBox16->ItemIndex == SotaMBoIdx )
                    {
                       if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 1 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 8 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 9 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 91 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 2 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 21 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 10 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 111 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 11 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 29 )
                       {
                          if( !Udp )
                          {
                            if( Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
                                Num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 )
                            {
                               idx = i;
                               break;
                            }
                          }
                          else
                          {
                             if( Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
                                 UdpAdress == PCfgObj(ObjTree->Items->Item[i]->Data)->UdpAdress )
                             {
                                idx = i;
                                break;
                             }
                          }
                       }

                       if( Type == PCfgObj(ObjTree->Items->Item[i]->Data)->Type )
                       {
                          if( !Udp )
                          {
                            if( Num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 )
                            {
                               idx = i;
                               break;
                            }
                          }
                          else
                          {
                             if( Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
                                 UdpAdress == PCfgObj(ObjTree->Items->Item[i]->Data)->UdpAdress )
                             {
                                idx = i;
                                break;
                             }
                          }
                       }
                    }
                    else if( ComboBox16->ItemIndex == TochkaMUchIdx ||
                             ComboBox16->ItemIndex == SotaMUchIdx )
                    {
                       if( !Udp )
                       {
                         if( Type == PCfgObj(ObjTree->Items->Item[i]->Data)->Type &&
                             Num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 &&
                             Num2 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num2 )
                         {
                            idx = i;
                            break;
                         }
                       }
                       else
                       {
                         if( Type == PCfgObj(ObjTree->Items->Item[i]->Data)->Type &&
                             Num2 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num2 &&
                             UdpAdress == PCfgObj(ObjTree->Items->Item[i]->Data)->UdpAdress )
                         {
                            idx = i;
                            break;
                         }
                       }
                    }
                    else if( ComboBox16->ItemIndex == NetDeviceIdx )
                    {
                       if( Type == PCfgObj(ObjTree->Items->Item[i]->Data)->Type &&
                           Edit14->Text == PCfgObj(ObjTree->Items->Item[i]->Data)->Icon1Path )
                       {
                          idx = i;
                          break;
                       }
                    }
                    else if( ComboBox16->ItemIndex ==  TochkaMDdIdx || ComboBox16->ItemIndex == SotaMDdIdx )
                    {
                       if( Type == PCfgObj(ObjTree->Items->Item[i]->Data)->Type &&
                           Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 )
                       {
                           if( !Udp )
                           {
                              if( Num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 )
                              {
                                 if( Num2%100 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num2%100 )
                                 {
                                    if( (Num2/100 == 1 || Num2/100 == 2)&&(PCfgObj(ObjTree->Items->Item[i]->Data)->Num2/100 == 1 || PCfgObj(ObjTree->Items->Item[i]->Data)->Num2/100 == 2) ||
                                        (Num2/100 == 3 || Num2/100 == 4)&&(PCfgObj(ObjTree->Items->Item[i]->Data)->Num2/100 == 3 || PCfgObj(ObjTree->Items->Item[i]->Data)->Num2/100 == 4) )
                                    {
                                       idx = i;
                                       break;
                                    }
                                 }
                              }
                           }
                           else
                           {
                              if( UdpAdress == PCfgObj(ObjTree->Items->Item[i]->Data)->UdpAdress )
                              {
                                 if( Num2%100 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num2%100 )
                                 {
                                    if( (Num2/100 == 1 || Num2/100 == 2)&&(PCfgObj(ObjTree->Items->Item[i]->Data)->Num2/100 == 1 || PCfgObj(ObjTree->Items->Item[i]->Data)->Num2/100 == 2) ||
                                        (Num2/100 == 3 || Num2/100 == 4)&&(PCfgObj(ObjTree->Items->Item[i]->Data)->Num2/100 == 3 || PCfgObj(ObjTree->Items->Item[i]->Data)->Num2/100 == 4) )
                                    {
                                       idx = i;
                                       break;
                                    }
                                 }
                              }
                           }

                           int flangNew = Num2/100;
                           int flangOld = PCfgObj(ObjTree->Items->Item[i]->Data)->Num2/100;

                           int adrNew = Num2%100;
                           int adrOld = PCfgObj(ObjTree->Items->Item[i]->Data)->Num2%100;

                           if( flangNew == 1 && flangOld == 2 && adrNew > adrOld )
                           {
                              flag_SotaMDd_Uch24 = 1;
                              idx = i;
                              break;
                           }

                           if( flangNew == 2 && flangOld == 1 && adrNew < adrOld )
                           {
                              flag_SotaMDd_Uch24 = 2;
                              idx = i;
                              break;
                           }

                           if( flangNew == 3 && flangOld == 4 && adrNew > adrOld )
                           {
                              flag_SotaMDd_Uch24 = 3;
                              idx = i;
                              break;
                           }

                           if( flangNew == 4 && flangOld == 3 && adrNew < adrOld )
                           {
                              flag_SotaMDd_Uch24 = 4;
                              idx = i;
                              break;
                           }
                       }
                    }
                 }
              }

              if( idx != -1 )
              {
                 ObjTree->SetFocus();
                 tempNode = ObjTree->Items->Item[idx];
                 tempNode->Selected = true;
                 ObjTreeClick(this);
                 if( flag_SotaMDd_Uch24 == 1 ) MessageBox( NULL, "����� �� ������� 1 ������ ���� ������, ���  ����� �� ������� 2!", ErrorMsg.c_str(), MB_OK|MB_ICONERROR );
                 else if( flag_SotaMDd_Uch24 == 2 ) MessageBox( NULL, "����� �� ������� 2 ������ ���� ������, ���  ����� �� ������� 1!", ErrorMsg.c_str(), MB_OK|MB_ICONERROR );
                 else if( flag_SotaMDd_Uch24 == 3 ) MessageBox( NULL, "����� �� ������� 3 ������ ���� ������, ��� ����� �� ������� 4!", ErrorMsg.c_str(), MB_OK|MB_ICONERROR );
                 else if( flag_SotaMDd_Uch24 == 4 ) MessageBox( NULL, "����� �� ������� 4 ������ ���� ������, ��� ����� �� ������� 3!", ErrorMsg.c_str(), MB_OK|MB_ICONERROR );
                 else MessageBox( NULL, MCFGInfoStr91.c_str(), ErrorMsg.c_str(), MB_OK|MB_ICONERROR );
              }
              else
              {
                  if( Num3 > 0 &&
                      UsePort[Num3] != UnUsedComPort &&
                      UsePort[Num3] != RifComPort &&
                      ( Type == 1 ||
                        Type == 2 ||
                        Type == 21 ||
                        Type == 8 ||
                        Type == 9 ||
                        Type == 91 ||
                        Type == 10 ||
                        Type == 11 ||
                        Type == 12 ||
                        Type == 111 ) )
                  {
                     MessageBox (NULL,MCFGInfoStr93.c_str(),ErrorMsg.c_str(),MB_OK|MB_ICONERROR);
                     ObjTree->Items->EndUpdate();
                     return;
                  }
                  else
                  {
                     if(  Type != 17 && Type != 16 && Type != 15 && Type != 14 && Type != 3 && Type != 4 && Type != 33 && Type != 34 ) UsePort[Num3] = RifComPort;
                  }

                 if( PCfgObj(ObjTree->Selected->Data)->Type == 0 ||
                     PCfgObj(ObjTree->Selected->Data)->Type == 1 && (Type == 5 || Type == 6 || Type == 7 || Type == 71 || Type == 51 || Type == 41 || Type == 42 || Type == 12 || Type == 24 || Type == 25 || Type == 32) ||
                     PCfgObj(ObjTree->Selected->Data)->Type == 111 && (Type == 5 || Type == 6 || Type == 7 || Type == 71 || Type == 51 || Type == 41 || Type == 42 || Type == 12 || Type == 24 || Type == 25 || Type == 32) ||
                     PCfgObj(ObjTree->Selected->Data)->Type == 2 && (Type == 5 || Type == 6 || Type == 7 || Type == 71 || Type == 51 || Type == 41 || Type == 42 || Type == 12 || Type == 24 || Type == 25 || Type == 32) ||
                     PCfgObj(ObjTree->Selected->Data)->Type == 21 && (Type == 5 || Type == 6 || Type == 7 || Type == 71 || Type == 51 || Type == 41 || Type == 42 || Type == 12 || Type == 24 || Type == 25 || Type == 32) ||
                     PCfgObj(ObjTree->Selected->Data)->Type == 3 && (Type == 4 ||Type == 5 || Type == 6 || Type == 7 || Type == 71 || Type == 51 || Type == 41 || Type == 42 || Type == 12 || Type == 24 || Type == 25 || Type == 32) ||
                     PCfgObj(ObjTree->Selected->Data)->Type == 33 && (Type == 43 ||Type == 5 || Type == 6 || Type == 7 || Type == 71 || Type == 51 || Type == 41 || Type == 42 || Type == 12 || Type == 24 || Type == 25 || Type == 32) ||
                     PCfgObj(ObjTree->Selected->Data)->Type == 8 && (Type == 5 || Type == 6 || Type == 7 || Type == 71 || Type == 51 || Type == 41 || Type == 42 || Type == 12 || Type == 24 || Type == 25 || Type == 32) ||
                     PCfgObj(ObjTree->Selected->Data)->Type == 9 && (Type == 5 || Type == 6 || Type == 7 || Type == 71 || Type == 51 || Type == 41 || Type == 42 || Type == 12 || Type == 24 || Type == 25 || Type == 32) ||
                     PCfgObj(ObjTree->Selected->Data)->Type == 91 && (Type == 5 || Type == 6 || Type == 7 || Type == 71 || Type == 51 || Type == 41 || Type == 42 || Type == 12 || Type == 24 || Type == 25 || Type == 32) ||
                     PCfgObj(ObjTree->Selected->Data)->Type == 10 && (Type == 5 || Type == 6 || Type == 7 || Type == 71 || Type == 51 || Type == 41 || Type == 42 || Type == 12 || Type == 24 || Type == 25 || Type == 32) ||
                     PCfgObj(ObjTree->Selected->Data)->Type == 11 && (Type == 5 || Type == 6 || Type == 7 || Type == 71 || Type == 51 || Type == 41 || Type == 42 || Type == 12 || Type == 24 || Type == 25 || Type == 32) ||
                     PCfgObj(ObjTree->Selected->Data)->Type == 14 && (Type == 5 || Type == 6 || Type == 7 || Type == 71 || Type == 51 || Type == 41 || Type == 42 || Type == 15 || Type == 12 || Type == 24 || Type == 25 || Type == 32) ||
                     PCfgObj(ObjTree->Selected->Data)->Type == 15 && (Type == 5 || Type == 6 || Type == 7 || Type == 71 || Type == 51 || Type == 41 || Type == 42 || Type == 16 || Type == 12 || Type == 24 || Type == 25 || Type == 32) ||
                     PCfgObj(ObjTree->Selected->Data)->Type == 16 && (Type == 5 || Type == 6 || Type == 7 || Type == 71 || Type == 51 || Type == 41 || Type == 42 || Type == 17 || Type == 12 || Type == 24 || Type == 25 || Type == 32) ||
                     PCfgObj(ObjTree->Selected->Data)->Type == 17 && (Type == 5 || Type == 6 || Type == 7 || Type == 71 || Type == 51 || Type == 41 || Type == 42 || Type == 12 || Type == 24 || Type == 25 || Type == 32) ||
                     PCfgObj(ObjTree->Selected->Data)->Type == 26 && (Type == 5 || Type == 6 || Type == 7 || Type == 71 || Type == 51 || Type == 41 || Type == 42 || Type == 27 || Type == 12 || Type == 24 || Type == 25 || Type == 32) ||
                     PCfgObj(ObjTree->Selected->Data)->Type == 27 && (Type == 5 || Type == 6 || Type == 7 || Type == 71 || Type == 51 || Type == 41 || Type == 42 || Type == 28 || Type == 12 || Type == 24 || Type == 25 || Type == 32) ||
                     PCfgObj(ObjTree->Selected->Data)->Type == 29 && (Type == 5 || Type == 6 || Type == 7 || Type == 71 || Type == 51 || Type == 41 || Type == 42 || Type == 30 || Type == 12 || Type == 24 || Type == 25 || Type == 32) ||
                     PCfgObj(ObjTree->Selected->Data)->Type == 30 && (Type == 5 || Type == 6 || Type == 7 || Type == 71 || Type == 51 || Type == 41 || Type == 42 || Type == 31 || Type == 12 || Type == 24 || Type == 25 || Type == 32) )
                 {
                    PCfgObj  CfgObj;
                    CfgObj = new TCfgObj;

                    CfgObj->Type = Type;
                    CfgObj->Num1 = Num1;
                    CfgObj->Num2 = Num2;
                    CfgObj->Num3 = Num3;
                    CfgObj->Name = Name;
                    CfgObj->IconVisible = IconVisible;
                    CfgObj->Dk = true;
                    CfgObj->OutType = ComboBox28->ItemIndex;
                    CfgObj->asoosd_kk = RxSpinEdit4->Value;
                    CfgObj->asoosd_nn = RxSpinEdit5->Value;
                    CfgObj->ImgNum = ImgNum;
                    CfgObj->UdpUse = Udp;
                    CfgObj->UdpAdress = UdpAdress;
                    CfgObj->UpdPort = UdpPort;

                    if( CfgObj->Type == 1 ) CfgObj->AdamOff = AdamOff;

                    CfgObj->description = Edit17->Text;
                    CfgObj->lan = RxSpinEdit6->Value;
                    CfgObj->lon = RxSpinEdit7->Value;

                    if( Type == 42 )
                    {
                       CfgObj->Icon1Path = DevSn;
                       CfgObj->Icon2Path = DevName;
                    }

                    if( Type ==  24 )
                    {
                       CfgObj->Icon1Path = IpStr;
                       CfgObj->Icon2Path = LoginStr;
                       CfgObj->Icon3Path = PasswordStr;
                       CfgObj->Icon4Path = Ip2Str;
                    }

                    if( Type ==  25 )
                    {
                       CfgObj->Icon1Path = IpStr;
                       CfgObj->Icon2Path = LoginStr;
                       CfgObj->Icon3Path = PasswordStr;
                    }

                    if( Type == 32  )
                    {
                       CfgObj->Num2 = CSpinEdit20->Value;
                       CfgObj->Num3 = CSpinEdit21->Value;
                       CfgObj->X = CSpinEdit22->Value;
                       CfgObj->Y = CSpinEdit23->Value;
                       CfgObj->OutType = ComboBox2->ItemIndex;
                    }

                    if( Type == 200 )
                    {
                       CfgObj->Icon1Path = Edit14->Text;
                    }

                    tempNode = ObjTree->Selected;
                    tempNode = ObjTree->Items->AddChildObject( ObjTree->Selected, CfgObj->Name, CfgObj );

                    if( CfgObj->Type != SotaMDdIdx && CfgObj->Type != 71 )
                    {
                        CfgTimer->Enabled = false;

                        AnsiString str;

                        int type = CfgObj->Type;
                        int num3 =  CfgObj->Num3;
                        if( type == 4 && CfgObj->Num3 >= 4 && ComboBox20->ItemIndex == 0 ) { type = 44; num3 -= 3; }
                        if( type == 3 && ComboBox20->ItemIndex == 0 ) type = 33;
                        if( type == 4 && ComboBox20->ItemIndex == 0 ) type = 43;

                        str.sprintf("img_%d_%d_%d_%d", type,
                                                       CfgObj->Num1, CfgObj->Num2,
                                                       num3);

                        StrCopy(POutObj(lpMapCfg)->ImgName, str.c_str());
                        StrCopy(POutObj(lpMapCfg)->ObjName, CfgObj->Name.c_str());
                        POutObj(lpMapCfg)->ImgNum = CfgObj->ImgNum;
                        StrCopy(POutObj(lpMapCfg)->ImgPath, CfgObj->Icon1Path.c_str());
                        POutObj(lpMapCfg)->IconVisible = CfgObj->IconVisible;
                        POutObj(lpMapCfg)->ImgOperationId = 2;
                        CfgTimer->Enabled = true;
                    }

                    if( ComboBox16->ItemIndex == GroupIdx )
                    {
                       tempNode->SelectedIndex = 4;
                       tempNode->ImageIndex = 4;
                    }
                    else if( ComboBox16->ItemIndex == NetDeviceIdx )
                    {
                       tempNode->SelectedIndex = 16;
                       tempNode->ImageIndex = 16;
                    }
                    else
                    {
                       if( ComboBox16->ItemIndex == RifIdx || ComboBox16->ItemIndex == SdConcIdx ||
                           ComboBox16->ItemIndex == TorosIdx || ComboBox16->ItemIndex == NastIdx ||
                           ComboBox16->ItemIndex == RadarIdx || ComboBox16->ItemIndex == RazrivBoIdx ||
                           ComboBox16->ItemIndex == TochkaIdx || ComboBox16->ItemIndex == RifRlmSIdx )
                       {
                           tempNode->SelectedIndex = 7;
                           tempNode->ImageIndex = 7;
                       }
                       else if( ComboBox16->ItemIndex == SdIpBlIdx || ComboBox16->ItemIndex == IuIpBlIdx )
                       {
                          if( PCfgObj(tempNode->Data)->Num1 != 255 )
                          {
                              if( PCfgObj(tempNode->Data)->Num3 == 1 )
                              {
                                 if( ComboBox4->ItemIndex == 0 )
                                 {
                                    tempNode->SelectedIndex = 6;
                                    tempNode->ImageIndex = 6;
                                 }
                                 else
                                 {
                                    tempNode->SelectedIndex = 7;
                                    tempNode->ImageIndex = 7;
                                 }
                              }
                              else if( PCfgObj(tempNode->Data)->Num3 == 2 )
                              {
                                 tempNode->SelectedIndex = 7;
                                 tempNode->ImageIndex = 7;
                              }
                          }
                          else
                          {
                             tempNode->SelectedIndex = 7;
                             tempNode->ImageIndex = 7;
                          }
                       }
                       else if( ComboBox16->ItemIndex == SdIdx || ComboBox16->ItemIndex == IuIdx )
                       {
                          if( ComboBox5->ItemIndex == 0 )
                          {
                             tempNode->SelectedIndex = 6;
                             tempNode->ImageIndex = 6;
                          }
                          else
                          {
                             tempNode->SelectedIndex = 7;
                             tempNode->ImageIndex = 7;
                          }
                       }
                       else if( ComboBox16->ItemIndex == SsoiIdx )
                       {
                          if( ComboBox5->ItemIndex == 0 )
                          {
                             tempNode->SelectedIndex = 8;
                             tempNode->ImageIndex = 8;
                          }
                          else
                          {
                             tempNode->SelectedIndex = 9;
                             tempNode->ImageIndex = 9;
                          }
                       }
                       else if( ComboBox16->ItemIndex == Stn485Idx )
                       {
                             tempNode->SelectedIndex = 11;
                             tempNode->ImageIndex = 11;
                       }
                       else if( ComboBox16->ItemIndex == RastrIdx )
                       {
                          if( ComboBox7->ItemIndex == 0 )
                          {
                             tempNode->SelectedIndex = 8;
                             tempNode->ImageIndex = 8;
                          }
                          else
                          {
                             tempNode->SelectedIndex = 9;
                             tempNode->ImageIndex = 9;
                          }
                       }
                       else if( ComboBox16->ItemIndex == Stn1Idx )
                       {
                          if( ComboBox15->ItemIndex == 0 )
                          {
                             tempNode->SelectedIndex = 8;
                             tempNode->ImageIndex = 8;
                          }
                          else
                          {
                             tempNode->SelectedIndex = 9;
                             tempNode->ImageIndex = 9;
                          }
                       }
                       else if( ComboBox16->ItemIndex == SolidIdx )
                       {
                          if( ComboBox10->ItemIndex == 0 )
                          {
                             tempNode->SelectedIndex = 8;
                             tempNode->ImageIndex = 8;
                          }
                          else
                          {
                             tempNode->SelectedIndex = 9;
                             tempNode->ImageIndex = 9;
                          }
                       }
                       else if( ComboBox16->ItemIndex == Adam4068Idx )
                       {
                          if( ComboBox12->ItemIndex == 0 )
                          {
                             tempNode->SelectedIndex = 6;
                             tempNode->ImageIndex = 6;
                          }
                          else
                          {
                             tempNode->SelectedIndex = 7;
                             tempNode->ImageIndex = 7;
                          }
                       }
                       else if( ComboBox16->ItemIndex == TabloIdx )
                       {
                          if( ComboBox24->ItemIndex > 0 )
                          {
                             tempNode->SelectedIndex = 15;
                             tempNode->ImageIndex = 15;
                          }
                          else
                          {
                             tempNode->SelectedIndex = 6;
                             tempNode->ImageIndex = 6;
                          }
                       }
                       else if( ComboBox16->ItemIndex == TochkaMBoIdx ||
                                ComboBox16->ItemIndex == TochkaMUchIdx ||
                                ComboBox16->ItemIndex == TochkaMDdIdx )
                       {
                          tempNode->SelectedIndex = 7;
                          tempNode->ImageIndex = 7;
                       }
                       else if( ComboBox16->ItemIndex == SotaMBoIdx ||
                                ComboBox16->ItemIndex == SotaMUchIdx ||
                                ComboBox16->ItemIndex == SotaMDdIdx )
                       {
                          tempNode->SelectedIndex = 7;
                          tempNode->ImageIndex = 7;
                       }
                       else if( Type ==  24 )
                       {
                          tempNode->SelectedIndex = 11;
                          tempNode->ImageIndex = 11;
                       }
                       else if( Type ==  25 )
                       {
                          tempNode->SelectedIndex = 11;
                          tempNode->ImageIndex = 11;
                       }
                       else if( Type == 32  )
                       {
                          tempNode->SelectedIndex = 11;
                          tempNode->ImageIndex = 11;
                       }
                    }
                 }
              }
           }
       }
       else
       {
           if( Name.IsEmpty() )
              MessageBox( NULL, MCFGInfoStr94.c_str(), ErrorMsg.c_str(), MB_OK|MB_ICONERROR );
           else
           {
              int Type = 0;
              int Num1 = 0;
              int Num2 = 0;
              int Num3 = 0;
              bool IconVisible = false;

              if( ComboBox16->ItemIndex == 1  )
              {
                 Type = 3;
                 Num1 = ComboBox1->ItemIndex+1;
                 Num2 = ComboBox2->ItemIndex+1;
                 Num3 = ComboBox3->ItemIndex+1;
                 IconVisible = true;
              }
              else if( ComboBox16->ItemIndex == 2 )
              {
                 Type = 4;
                 Num1 = ComboBox1->ItemIndex+1;
                 Num2 = ComboBox2->ItemIndex+1;
                 Num3 = ComboBox3->ItemIndex+1;
              }
              else if( ComboBox16->ItemIndex == 3 )
              {
                 if( RastrmtvDevSn[ComboBox1->ItemIndex] != "" )
                 {
                    Type = 42;
                    Num1 = ComboBox1->ItemIndex+1;
                    Num2 = ComboBox2->ItemIndex+1;
                    Num3 = ComboBox3->ItemIndex+1;
                    DevSn = RastrmtvDevSn[ComboBox1->ItemIndex];
                    DevName = RastrmtvDevName[ComboBox1->ItemIndex];
                 }
                 else
                 {
                    MessageBox( NULL, MCFGInfoStr92.c_str(), ErrorMsg.c_str(), MB_OK|MB_ICONERROR );
                    goto mmm1;
                 }
              }

              int idx = -1;
              for( int i = 0; i < ObjTree->Items->Count; i++ )
              {
                 if( Name == PCfgObj(ObjTree->Items->Item[i]->Data)->Name &&
                     Type == 0 )
                 {
                    idx = i;
                    break;
                 }
              }

              if( idx == -1 )
              {
                 for( int i = 0; i < ObjTree->Items->Count; i++ )
                 {
                    if( ComboBox16->ItemIndex == 1 )
                    {
                       if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 3 ||
                           PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 42 )
                       {
                          if( Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
                              Num2 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num2 &&
                              Num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 &&
                              DevSn == PCfgObj(ObjTree->Items->Item[i]->Data)->Icon1Path )
                          {
                             idx = i;
                             break;
                          }
                       }
                    }
                 }
              }

              if( idx != -1 )
              {
                 ObjTree->SetFocus();
                 tempNode = ObjTree->Items->Item[idx];
                 tempNode->Selected = true;
                 ObjTreeClick(this);
                 MessageBox( NULL, MCFGInfoStr91.c_str(), ErrorMsg.c_str(), MB_OK|MB_ICONERROR );
              }
              else
              {
                 if( PCfgObj(ObjTree->Selected->Data)->Type == 0 ||
                     PCfgObj(ObjTree->Selected->Data)->Type == 3 && (Type == 4 || Type == 42 ) )
                 {
                    PCfgObj  CfgObj;
                    CfgObj = new TCfgObj;

                    CfgObj->Type = Type;
                    CfgObj->Num1 = Num1;
                    CfgObj->Num2 = Num2;
                    CfgObj->Num3 = Num3;
                    CfgObj->Name = Name;
                    CfgObj->IconVisible = IconVisible;
                    CfgObj->Dk = true;

                    if( Type == 42 )
                    {
                       CfgObj->Icon1Path = DevSn;
                       CfgObj->Icon2Path = DevName;
                    }

                    tempNode = ObjTree->Selected;
                    if( PCfgObj(ObjTree->Selected->Data)->Type == 0 )
                    {
                       tempNode->SelectedIndex = 5;
                       tempNode->ImageIndex = 5;
                    }

                    tempNode = ObjTree->Items->AddChildObject( ObjTree->Selected, CfgObj->Name, CfgObj );

                    if( ComboBox16->ItemIndex == GroupIdx )
                    {
                       tempNode->SelectedIndex = 4;
                       tempNode->ImageIndex = 4;
                    }
                    else
                    {
                       if( ComboBox16->ItemIndex == 1 || ComboBox16->ItemIndex == 2 )
                       {
                          tempNode->SelectedIndex = 6;
                          tempNode->ImageIndex = 6;
                       }
                       else if( ComboBox16->ItemIndex == 3 )
                       {
                          tempNode->SelectedIndex = 11;
                          tempNode->ImageIndex = 11;
                       }
                    }
                 }
              }
           }
       }
   }
mmm1:
   ObjTree->Items->EndUpdate();
}
void __fastcall TMainForm::BitBtn2Click(TObject *Sender)
{
   
   if( ObjTree->Selected->AbsoluteIndex != 0 )
   {

      if( PCfgObj(ObjTree->Selected->Data)->Type == 1 ||
          PCfgObj(ObjTree->Selected->Data)->Type == 2 ||
          PCfgObj(ObjTree->Selected->Data)->Type == 21 ||
          PCfgObj(ObjTree->Selected->Data)->Type == 8 ||
          PCfgObj(ObjTree->Selected->Data)->Type == 9 ||
          PCfgObj(ObjTree->Selected->Data)->Type == 91 ||
          PCfgObj(ObjTree->Selected->Data)->Type == 10 ||
          PCfgObj(ObjTree->Selected->Data)->Type == 11 ||
          PCfgObj(ObjTree->Selected->Data)->Type == 12 )
      {
         ObjTree->Items->BeginUpdate();

         int Num1 = PCfgObj(ObjTree->Selected->Data)->Num1;
         int Num2 = PCfgObj(ObjTree->Selected->Data)->Num2;
         int Num3 = PCfgObj(ObjTree->Selected->Data)->Num3;

         int idx = 0;
         for( int i = 0; i < ObjTree->Items->Count; i++ )
         {
            if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 1 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 2 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 8 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 9 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 21 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 91 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 10 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 11 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 12 )
            {
               if( Num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 &&
                   (Num1 != PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 ||
                    Num2 != PCfgObj(ObjTree->Items->Item[i]->Data)->Num2) )
               {
                  idx = idx + 1;
               }
            }
         }

         if( idx == 0 ) UsePort[Num3] = UnUsedComPort;

         ObjTree->Items->EndUpdate();
      }

      if( ObjTree->Selected->HasChildren )
      {
         std::auto_ptr<TReadForm> pfrm(new TReadForm(this));
         pfrm->Update();

         ObjTree->Items->BeginUpdate();

         DelChilds(ObjTree->Selected->AbsoluteIndex);

         ObjTree->Items->EndUpdate();

         pfrm->Visible = false;
      }

      AnsiString str;

      int type = PCfgObj(ObjTree->Selected->Data)->Type;
      int num3 = PCfgObj(ObjTree->Selected->Data)->Num3;
      if( type == 4 && POprosObj(ObjTree->Selected->Data)->Num3 >= 4 && ComboBox20->ItemIndex == 0 ) { type = 44; num3 -= 3; }
      if( type == 3 && ComboBox20->ItemIndex == 0 ) type = 33;
      if( type == 4 && ComboBox20->ItemIndex == 0 ) type = 43;

      str.sprintf("img_%d_%d_%d_%d", type,
                                     POprosObj(ObjTree->Selected->Data)->Num1, POprosObj(ObjTree->Selected->Data)->Num2,
                                     num3);

      StrCopy(POutObj(lpMapCfg)->ImgName, str.c_str());
      POutObj(lpMapCfg)->ImgOperationId = 3;

      ObjTree->Items->Delete(ObjTree->Selected);
   }
}
void TMainForm::DelChilds( int idx )
{
   AnsiString str;

   while( ObjTree->Items->Item[idx]->HasChildren )
   {
      TTreeNode* node = ObjTree->Items->Item[idx]->getFirstChild();

      str = PCfgObj(node->Data)->Name;

      if( node->HasChildren ) DelChilds(node->AbsoluteIndex);

      str.sprintf("img_%d_%d_%d_%d", PCfgObj(node->Data)->Type,
                                     PCfgObj(node->Data)->Num1,
                                     PCfgObj(node->Data)->Num2,
                                     PCfgObj(node->Data)->Num3);
      StrCopy(POutObj(lpMapCfg)->ImgName, str.c_str());
      POutObj(lpMapCfg)->ImgOperationId = 7;

      if( ComboBox29->ItemIndex == 0 ) MyDelay(500);

      node->Delete();
   }
}
void __fastcall TMainForm::BitBtn3Click(TObject *Sender)
{
   
   ObjTree->Items->BeginUpdate();

   TTreeNode* tempNode;

   AnsiString Name = Edit1->Text;
   if( Name.IsEmpty() && ComboBox16->ItemIndex == GroupIdx && ComplexVersion != Rastr_M_TvComplexType ) MessageBox( NULL, MCFGInfoStr94.c_str(), ErrorMsg.c_str(), MB_OK|MB_ICONERROR );
   else
   {
      int Num1 = 0;
      int Num2 = 0;
      int Num3 = 0;
      if( ComboBox16->ItemIndex == RifIdx || ComboBox16->ItemIndex == RifRlmSIdx )
      {
         Num1 = ComboBox1->ItemIndex+1;
         Num3 = ComboBox3->ItemIndex+1;
      }
      else if( ComboBox16->ItemIndex == SdConcIdx )
      {
         Num1 = ComboBox1->ItemIndex+1;
         Num2 = ComboBox2->ItemIndex+1;
         Num3 = ComboBox3->ItemIndex+1;
      }
      else if( ComboBox16->ItemIndex == SdIdx )
      {
         Num1 = ComboBox1->ItemIndex+1;
         Num2 = ComboBox2->ItemIndex+1;
         Num3 = ComboBox3->ItemIndex+1;
      }
      else if( ComboBox16->ItemIndex == IuIdx )
      {
         Num1 = ComboBox1->ItemIndex+1;
         Num2 = ComboBox2->ItemIndex+1;
         Num3 = ComboBox3->ItemIndex+1;
      }
      else if( ComboBox16->ItemIndex == RastrIdx )
      {
         Num1 = ComboBox1->ItemIndex+1;
         Num2 = ComboBox2->ItemIndex+1;
      }
      else if( ComboBox16->ItemIndex == Stn1Idx )
      {
         Num1 = ComboBox1->ItemIndex+1;
         Num2 = ComboBox2->ItemIndex+1;
      }
      else if( ComboBox16->ItemIndex == SolidIdx )
      {
         Num1 = ComboBox1->ItemIndex+1;
      }
      else if( ComboBox16->ItemIndex == Adam4068Idx )
      {
         Num1 = ComboBox1->ItemIndex+1;
         Num2 = ComboBox2->ItemIndex;
      }
      else if( ComboBox16->ItemIndex == TorosIdx )
      {
         Num1 = ComboBox1->ItemIndex+1;
         Num3 = ComboBox3->ItemIndex+1;
      }
      else if( ComboBox16->ItemIndex == NastIdx )
      {
         Num1 = ComboBox1->ItemIndex+1;
         Num3 = ComboBox3->ItemIndex+1;
      }
      else if( ComboBox16->ItemIndex == TochkaIdx )
      {
         Num1 = ComboBox1->ItemIndex+1;
         Num2 = ComboBox2->ItemIndex+1;
         Num3 = ComboBox3->ItemIndex+1;
      }
      else if( ComboBox16->ItemIndex == Stn485Idx || ComplexVersion == Rastr_M_TvComplexType )
      {
         Num1 = ComboBox1->ItemIndex+1;
         Num2 = ComboBox2->ItemIndex+1;
         Num3 = ComboBox3->ItemIndex+1;
      }

      int idx = -1;
      for( int i = 0; i < ObjTree->Items->Count; i++ )
      {
         if( ComboBox16->ItemIndex == GroupIdx && Name == PCfgObj(ObjTree->Items->Item[i]->Data)->Name )
         {
            idx = i;
            break;
         }
         else if( ComboBox16->ItemIndex == RifIdx || ComboBox16->ItemIndex == RifRlmSIdx )
         {
            if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 1 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 2 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 8 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 9 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 21 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 91 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 10 )
            {
               if( Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
                   Num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 )
               {
                  idx = i;
                  break;
               }
            }
         }
         else if( ComboBox16->ItemIndex == SdConcIdx )
         {
            if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 1 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 8 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 9 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 21 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 91 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 10 )
            {
               if( Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
                   Num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3)
               {
                  idx = i;
                  break;
               }
            }

            if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 2 )
            {
               if( Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
                   Num2 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num2 &&
                   Num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 )
               {
                  idx = i;
                  break;
               }
            }
         }
         else if( ComboBox16->ItemIndex == RazrivBoIdx )
         {
            if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 1 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 8 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 9 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 2 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 91 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 10 )
            {
               if( Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
                   Num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3)
               {
                  idx = i;
                  break;
               }
            }

            if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 21 )
            {
               if( Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
                   Num2 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num2 &&
                   Num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 )
               {
                  idx = i;
                  break;
               }
            }
         }
         else if( ComboBox16->ItemIndex == TochkaIdx )
         {
            if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 1 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 8 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 9 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 2 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 91 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 21 )
            {
               if( Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
                   Num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3)
               {
                  idx = i;
                  break;
               }
            }

            if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 10 )
            {
               if( Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
                   Num2 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num2 &&
                   Num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 )
               {
                  idx = i;
                  break;
               }
            }
         }
         else if( ComboBox16->ItemIndex == SdIdx )
         {
            if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 3 &&
                Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
                Num2 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num2 &&
                Num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 )
            {
               idx = i;
               break;
            }
         }
         else if( ComboBox16->ItemIndex == IuIdx )
         {
            if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 4 &&
                Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
                Num2 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num2 &&
                Num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 )
            {
               idx = i;
               break;
            }
         }
         else if( ComboBox16->ItemIndex == RastrIdx )
         {
            if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 5 &&
                Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
                Num2 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num2 )
            {
               idx = i;
               break;
            }
         }
         else if( ComboBox16->ItemIndex == Stn1Idx )
         {
            if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 51 &&
                Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
                Num2 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num2 )
            {
               idx = i;
               break;
            }
         }
         else if( ComboBox16->ItemIndex == SolidIdx )
         {
            if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 6 &&
                Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 )
            {
               idx = i;
               break;
            }
         }
         else if( ComboBox16->ItemIndex == Adam4068Idx )
         {
            if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 7 &&
                Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
                Num2 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num2 )
            {
               idx = i;
               break;
            }
         }
         else if( ComboBox16->ItemIndex == TorosIdx )
         {
            if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 1 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 2 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 8 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 9 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 91 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 21 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 10 )
            {
               if( Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
                   Num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 )
               {
                  idx = i;
                  break;
               }
            }
         }
         else if( ComboBox16->ItemIndex == NastIdx )
         {
            if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 1 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 2 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 8 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 9 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 91 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 21 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 10 )
            {
               if( Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
                   Num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 )
               {
                  idx = i;
                  break;
               }
            }
         }
         else if( ComboBox16->ItemIndex == RadarIdx )
         {
            if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 1 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 2 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 8 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 9 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 91 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 21 ||
                PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 10 )
            {
               if( Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
                   Num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 )
               {
                  idx = i;
                  break;
               }
            }
         }
         else if( ComboBox16->ItemIndex == Stn485Idx || ComplexVersion == Rastr_M_TvComplexType )
         {
            if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 42 &&
                Num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
                Num2 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num2 &&
                Num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 )
            {
               idx = i;
               break;
            }
         }
      }

      if( idx != -1 )
      {
         ObjTree->SetFocus();
         tempNode = ObjTree->Items->Item[idx];
         tempNode->Selected = true;
         ObjTreeClick(this);
      }
      else
      {
         MessageBox( NULL, MCFGInfoStr95.c_str(), WarningMsg.c_str(), MB_OK|MB_ICONINFORMATION );
      }
   }
   ObjTree->Items->EndUpdate();
}
void __fastcall TMainForm::BitBtn10Click(TObject *Sender)
{
   
   if( ComboBox16->ItemIndex != RastrIdx && ComboBox16->ItemIndex != Stn1Idx && ComboBox16->ItemIndex != SsoiIdx )
   {
      TTreeNode* tempNode;

      AnsiString Name = Edit1->Text;
      if( Name.IsEmpty() ) MessageBox( NULL, MCFGInfoStr94.c_str(), ErrorMsg.c_str(), MB_OK|MB_ICONERROR );
      else
      {
         int idx = -1;
         for( int i = 0; i < ObjTree->Items->Count; i++ )
         {
            if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 0 &&
                Name == PCfgObj(ObjTree->Items->Item[i]->Data)->Name )
            {
               idx = i;
               break;
            }
         }
         if( idx != -1 )
         {
            tempNode = ObjTree->Items->Item[idx];
            tempNode->Selected = true;
            MessageBox( NULL, MCFGInfoStr91.c_str(), ErrorMsg.c_str(), MB_OK|MB_ICONERROR );
         }
         else
         {
            ObjTree->Selected->Text = Name;
            PCfgObj(ObjTree->Selected->Data)->Name = Name;
         }
      }
   }
}
void __fastcall TMainForm::BitBtn4Click(TObject *Sender)
{
   
   MoveUpTree(ObjTree->Selected);
}
void __fastcall TMainForm::BitBtn5Click(TObject *Sender)
{
   
   if (!ObjTree->Selected)
   {
      MessageBeep(MB_OK);
      return;
   }

   TTreeNode *pItem = ObjTree->Selected->getNextSibling();
   if (pItem != NULL) MoveUpTree(pItem);
   else MessageBeep(MB_OK);
}
void __fastcall TMainForm::MoveUpTree(TTreeNode *item)
{
   if (item == NULL)
   {
      MessageBeep(MB_OK);
      return;
   }
   TNodeAttachMode AttachMode = naInsert;

   TTreeNode *ppItem = item->getPrevSibling();

   int level = item->Level;
   if (ppItem == NULL)
   {
      MessageBeep(MB_OK);
      return;
   }
   if (ppItem->Level != level)
   {
      MessageBeep(MB_OK);
      return;
   }
   item->MoveTo(ppItem, AttachMode);
}
void TMainForm::ShowKeyGenGroupBox()
{
   AnsiString str;

   char pwchar[255];
   for( int i = 0; i < 255; i++ ) pwchar[i] = 0;
   char dr[10];

   GetLogicalDriveStrings(255,pwchar);
   for( int i = 0; i < 255; i++ )
   {
      if( pwchar[i] == ':' )
      dr[0] = pwchar[i-1];
      dr[1] = pwchar[i];
      dr[2] = pwchar[i+1];
      dr[3] = pwchar[i+2];

      AnsiString str = dr;

      if( GetDriveType(dr) == DRIVE_REMOVABLE ) ComboBox9->Items->Add(str);
   }

   ComboBox9->ItemIndex = 0;
}
void __fastcall TMainForm::BitBtn8Click(TObject *Sender)
{
   
   Edit4->Text = "";
   Edit5->Text = "";

   TAdmAudit *AdmAud;
   AdmAud = new TAdmAudit;
   AdmAud->Version = 2.00;
   AdmAud->CreateDt = Now();
   AdmAud->Crc = AdmAud->Version + AdmAud->CreateDt;

   AnsiString str = ComboBox9->Text;

   unsigned int errmode = SetErrorMode ( SEM_FAILCRITICALERRORS );

   if( DirectoryExists(str) )
   {
      str = str + "auidit.adm";

      if( AdmAud->Save(str) )MessageBox (NULL,"���� ������ ������","����������",MB_OK|MB_ICONINFORMATION);
      else MessageBox (NULL,"������ �������� ����� ������!","������",MB_OK|MB_ICONERROR);
   }
   else MessageBox (NULL,"���� �� ������!","������",MB_OK|MB_ICONERROR);

   SetErrorMode ( errmode );

   delete AdmAud;
}
void __fastcall TMainForm::BitBtn9Click(TObject *Sender)
{
   
   Edit4->Text = "";
   Edit5->Text = "";

   TAdmAudit *AdmAud;
   AdmAud = new TAdmAudit;

   AnsiString str = ComboBox9->Text;

   unsigned int errmode = SetErrorMode ( SEM_FAILCRITICALERRORS );

   if( DirectoryExists(str) )
   {
      str = str + "auidit.adm";

      if( AdmAud->Load(str) )
      {
         double crc = AdmAud->Version + AdmAud->CreateDt;
         if( crc == AdmAud->Crc )
         {
            AnsiString str1;
            str1.sprintf("%4.2f", AdmAud->Version);
            Edit4->Text = str1;
            str1 = DateTimeToStr( AdmAud->CreateDt );
            Edit5->Text = str1;
         }
         else MessageBox (NULL,"������ ����������� �����!","������",MB_OK|MB_ICONERROR);
      }
      else MessageBox (NULL,"������ ������ ����� ������!","������",MB_OK|MB_ICONERROR);
   }
   else MessageBox (NULL,"���� �� ������!","������",MB_OK|MB_ICONERROR);

   SetErrorMode ( errmode );

   delete AdmAud;
}
void __fastcall TMainForm::FileNewItemClick(TObject *Sender)
{
   
   StatusBar1->Panels->Items[0]->Text = "";

   ObjTree->Items->Clear();
   PCfgObj  CfgObj;
   CfgObj = new TCfgObj;
   CfgObj->Name = MsgStr25;

   TTreeNode* tempNode;
   ObjTree->Items->BeginUpdate();
   tempNode = ObjTree->Items->AddObject( ObjTree->Selected, CfgObj->Name, CfgObj );
   tempNode->SelectedIndex = 4;
   tempNode->ImageIndex = 4;
   tempNode->Selected = true;
   ObjTreeClick(this);

   ObjTree->Items->EndUpdate();

   ComboBox29->ItemIndex = 2;
   ComboBox29Change(this);

   Edit3->Text = "";
   StrCopy(POutObj(lpMapCfg)->PlanPath, Edit3->Text.c_str() );
   POutObj(lpMapCfg)->FileOperationId = 1;

   ComboBox27->ItemIndex = 0;

   ComboBox16Click(this);

   for( int i = 0; i < MaxPortCnt; i++) UsePort[i] = UnUsedComPort;

   ComboBox4->ItemIndex = 0;
   ComboBox18->ItemIndex = 0;
   CSpinEdit5->Value = 50;
   for( int i = 0; i < MaxPortCnt; i++)
   {
      RifPortSpeed[i] = 4800;
      RifPortInterval[i] = 50;
   }
   ComboBox5->ItemIndex = 0;
   CSpinEdit18->Value = 20;

   ComboBox20->ItemIndex = 0;
   for( int kan = 0; kan < MaxKanalDev; kan++ )
   {
      SsoiM_PortNum[kan] = 0;
      SsoiM_Interval[kan] = 1500;
      SsoiM_MaxErrCnt[kan] = 2;
   }
   ComboBox20Change(this);

   RastrPortNum = ComboBox7->ItemIndex;
   ComboBox10->ItemIndex = 0;
   SolidPortNum = ComboBox10->ItemIndex;
   ComboBox12->ItemIndex = 0;
   Adam4068PortNum = ComboBox12->ItemIndex;
   CSpinEdit6->Value = 100;
   ComboBox24->ItemIndex = 0;
   TabloPortNum = ComboBox24->ItemIndex;
   CheckBox1->Checked = false;

   ComboBox6->ItemIndex = 0;
   RxSpinEdit1->Value = 0.0;
   RxSpinEdit2->Value = 5.0;
   switch( RifPortSpeed[ComboBox4->ItemIndex] )
   {
      case   4800: ComboBox18->ItemIndex = 0; break;
      case   9600: ComboBox18->ItemIndex = 1; break;
      case  19200: ComboBox18->ItemIndex = 2; break;
      case  38400: ComboBox18->ItemIndex = 3; break;
      case  57600: ComboBox18->ItemIndex = 4; break;
      case 115200: ComboBox18->ItemIndex = 5; break;
      case 250000: ComboBox18->ItemIndex = 6; break;
      default:     ComboBox18->ItemIndex = 0; break;
   }

   ComboBox15->ItemIndex = 0;
   Edit7->Text = "localhost";
   CSpinEdit1->Value = 1972;
   CSpinEdit9->Value = 20;
   CSpinEdit3->Value = 1974;
   ComboBox23->ItemIndex = 0;
   ComboBox30->ItemIndex = 0;
   ComboBox31->ItemIndex = 1;

   ComboBox32->ItemIndex = 0;
   Edit15->Text = "localhost";
   CSpinEdit10->Value = 1973;
   CSpinEdit19->Value = 10;
   CSpinEdit26->Value = 1976;

   ComboBox13->ItemIndex = 0;
   Edit6->Text = "localhost";
   Edit10->Text = "";
   Edit11->Text = "";
   CSpinEdit11->Value = 3306;
   Edit9->Text = "";
   ComboBox11->ItemIndex = 0;
   CheckBox2->Checked = false;
   CheckBox3->Checked = false;

   RadioButton1->Checked = true;
   RadioButton2->Checked = false;
   GobiFixNewWarning = 0;

   ComboBox17->ItemIndex = 0;
   Edit8->Text = "localhost";
   CSpinEdit2->Value = 1975;

   Icon1Path = "";
   Icon2Path = "";
   Icon3Path = "";
   Icon4Path = "";
   Icon5Path = "";
   Icon6Path = "";

   ComboBox25->ItemIndex = 0;
   RxSpinEdit3->Value = 50;

   Edit2->Text = ExtractFilePath(Application->ExeName) + "\Backup";
   ComboBox8->ItemIndex = 0;

   ComboBox15Change(this);

   ComboBox26->ItemIndex = 1;
   ComboBox26Change(this);
   OpList->Reset();
   AdvStringGrid1->RowCount = 2;
   AdvStringGrid1->ClearRows(1,1);

   RxSpinEdit4->Value = 0;
   RxSpinEdit5->Value = 0;

   ComboBox33->ItemIndex = 0;

   Edit18->Text = "c:\\Program Files\\DevLine\\Line\\observer.exe";

   ComboBox34->ItemIndex = 0;

   CheckBox4->Checked = false;
   CSpinEdit24->Value = 0;
   CSpinEdit25->Value = 0;
}
void __fastcall TMainForm::FileSaveItemClick(TObject *Sender)
{
   
   SaveDialog1->HistoryList->Clear();
   SaveDialog1->InitialDir = ExtractFilePath(Application->ExeName);
   SaveDialog1->FileName = ExtractFilePath(Application->ExeName) + "rifx.ini";

   if( SaveDialog1->Execute() )
   {
      if( FileExists(SaveDialog1->FileName) ) DeleteFile( SaveDialog1->FileName );

      TMemIniFile *ini;
      ini = new TMemIniFile( SaveDialog1->FileName );
      ini->Clear();

      ini->WriteInteger( "PARAMS", "PlanType", ComboBox29->ItemIndex );

      ini->WriteString( "PARAMS", "PlanPath", Edit3->Text );

      ini->WriteInteger( "PARAMS", "SoundType", ComboBox27->ItemIndex );

      ini->WriteInteger( "PARAMS", "AutoStart", ComboBox34->ItemIndex );

      AnsiString str;
      for( int kan = 0; kan < MaxPortCnt; kan++ )
      {
         if( RifPortSpeed[kan] != 4800 )
         {
            str.sprintf("RifPortSpeed%d", kan+1);
            ini->WriteInteger( "RIF", str, RifPortSpeed[kan]);
         }
         if( RifPortInterval[kan] != 50 )
         {
            str.sprintf("RifPortInterval%d", kan+1);
            ini->WriteInteger( "RIF", str, RifPortInterval[kan]);
         }
      }
      ini->WriteInteger("RIF", "AutoDK", ComboBox6->ItemIndex);
      ini->WriteFloat("RIF", "Ul", RxSpinEdit1->Value);
      ini->WriteFloat("RIF", "Uh", RxSpinEdit2->Value);
      ini->WriteInteger("RIF", "TochkaDirectionInterval", CSpinEdit18->Value);

      ini->WriteInteger("SSOI", "Version", SsoiVersion);
      ini->WriteInteger( "SSOI", "SsoiM_PortNum1", SsoiM_PortNum[0] );
      ini->WriteInteger( "SSOI", "SsoiM_Interval1", CSpinEdit12->Value );
      ini->WriteInteger( "SSOI", "SsoiM_MaxErrCnt1", CSpinEdit13->Value );
      ini->WriteInteger( "SSOI", "SsoiM_PortNum2", SsoiM_PortNum[1] );
      ini->WriteInteger( "SSOI", "SsoiM_Interval2", CSpinEdit7->Value );
      ini->WriteInteger( "SSOI", "SsoiM_MaxErrCnt2", CSpinEdit8->Value );
      ini->WriteInteger( "SSOI", "SsoiM_PortNum3", SsoiM_PortNum[2] );
      ini->WriteInteger( "SSOI", "SsoiM_Interval3", CSpinEdit14->Value );
      ini->WriteInteger( "SSOI", "SsoiM_MaxErrCnt3", CSpinEdit15->Value );
      ini->WriteInteger( "SSOI", "SsoiM_PortNum4", SsoiM_PortNum[3] );
      ini->WriteInteger( "SSOI", "SsoiM_Interval4", CSpinEdit16->Value );
      ini->WriteInteger( "SSOI", "SsoiM_MaxErrCnt4", CSpinEdit17->Value );
      ini->WriteBool( "SSOI", "SsoiAutoDkUse", ComboBox33->ItemIndex );

      if( RadioButton1->Checked) GobiFixNewWarning = 0;
      else if( RadioButton2->Checked ) GobiFixNewWarning = 1;
      ini->WriteInteger( "SSOI", "SsoiFixNewWarning", GobiFixNewWarning );
      ini->WriteInteger( "SSOI", "SsoiM_PortSpeed", 4800 );

      if( ComplexVersion == Rastr_M_TvComplexType )
         if( ComboBox15->ItemIndex == 2 ) ComboBox15->ItemIndex = 0;
      ini->WriteInteger("RASTRMTV", "Use", ComboBox15->ItemIndex);
      ini->WriteString( "RASTRMTV", "Name", Edit7->Text );
      ini->WriteInteger("RASTRMTV", "Port", CSpinEdit1->Value);
      ini->WriteInteger("RASTRMTV", "Port2", CSpinEdit3->Value);
      ini->WriteInteger("RASTRMTV", "KeepAliveInterval", CSpinEdit9->Value);
      ini->WriteInteger("RASTRMTV", "ThermostatUse", ComboBox23->ItemIndex);
      ini->WriteInteger("RASTRMTV", "dtInfoToJpg", ComboBox30->ItemIndex);
      ini->WriteInteger("RASTRMTV", "AutoDkPeriod", ComboBox31->ItemIndex*10);

      ini->WriteInteger("INTEGRATION", "Use", ComboBox32->ItemIndex);
      ini->WriteString( "INTEGRATION", "Host", Edit15->Text );
      ini->WriteInteger("INTEGRATION", "Port", CSpinEdit10->Value);
      ini->WriteInteger("INTEGRATION", "Port2", CSpinEdit26->Value);
      ini->WriteInteger("INTEGRATION", "KeepAliveInterval", CSpinEdit19->Value);

      ini->WriteInteger("MYSQL", "Use", ComboBox13->ItemIndex);
      ini->WriteString( "MYSQL", "Host", Edit6->Text );
      ini->WriteInteger("MYSQL", "Port", CSpinEdit11->Value);
      ini->WriteString( "MYSQL", "Login", Edit10->Text );
      ini->WriteString( "MYSQL", "Password", XOR_Crypt(Edit11->Text,"start7") );
      ini->WriteString( "MYSQL", "DbName", Edit9->Text );
      ini->WriteInteger("MYSQL", "Mode", ComboBox11->ItemIndex);
      ini->WriteBool("MYSQL", "P1", CheckBox2->Checked);
      ini->WriteBool("MYSQL", "P2", CheckBox3->Checked);
      ini->WriteBool("MYSQL", "AutoDbStart", CheckBox4->Checked);
      ini->WriteInteger("MYSQL", "AutoDbStartHour", CSpinEdit24->Value);
      ini->WriteInteger("MYSQL", "AutoDbStartMinute", CSpinEdit25->Value);

      ini->WriteInteger("RASTR", "Port", ComboBox7->ItemIndex);

      ini->WriteInteger("SOLID", "Port", ComboBox10->ItemIndex);

      ini->WriteInteger("ADAM4068", "Port", ComboBox12->ItemIndex);
      ini->WriteInteger("ADAM4068", "Interval", CSpinEdit6->Value);

      ini->WriteInteger("TABLO", "Port", ComboBox24->ItemIndex);
      ini->WriteInteger( "TABLO", "Blinking", CheckBox1->Checked );

      ini->WriteString(  "RASTRMSSOI", "SerNum", ComboBox19->Items->Strings[ComboBox19->ItemIndex] );
      ini->WriteInteger( "RASTRMSSOI", "Speed", ComboBox25->ItemIndex );
      ini->WriteInteger( "RASTRMSSOI", "Timeout", RxSpinEdit3->Value );

      ini->WriteString( "BACKUP", "BackupPath", Edit2->Text );
      ini->WriteInteger( "BACKUP", "MaxBdStringCnt", ComboBox8->ItemIndex );

      if( ComplexVersion == Rastr_M_TvComplexType && ComboBox15->ItemIndex == 3 ) ini->WriteInteger("PORT", "Use", 1);
      else ini->WriteInteger("PORT", "Use", 0);

      if( ComboBox26->ItemIndex == 0 ) ini->WriteInteger("OPERATORS", "Use", 1);
      else ini->WriteInteger("OPERATORS", "Use", 0);
      ini->WriteInteger("OPERATORS", "Count", OpList->OpCnt );
      for( int i = 0; i < OpList->OpCnt; i++ )
      {
         str.sprintf("Operator_%d", i);
         ini->WriteString( str.c_str(), "FN", OpList->Op[i].FamilyName );
         ini->WriteString( str.c_str(), "N1", OpList->Op[i].FirstName );
         ini->WriteString( str.c_str(), "N2", OpList->Op[i].SecondName );
         ini->WriteString( str.c_str(), "PW", XOR_Crypt(OpList->Op[i].Password,"start7") );
      }

      ini->WriteInteger("ASOOSD", "Use", ComboBox17->ItemIndex);
      ini->WriteString( "ASOOSD", "Host", Edit8->Text );
      ini->WriteInteger("ASOOSD", "Port", CSpinEdit2->Value);

      ini->WriteString( "INTEGRATION", "DevLine", Edit18->Text );

      ini->WriteInteger("TREE", "Count", ObjTree->Items->Count-1 );

      for( int i = 1; i < ObjTree->Items->Count; i++ )
      {
         str.sprintf("Obj_%d", i);
         ini->WriteInteger(str.c_str(), "Type", PCfgObj(ObjTree->Items->Item[i]->Data)->Type);
         ini->WriteInteger(str.c_str(), "Num1", PCfgObj(ObjTree->Items->Item[i]->Data)->Num1);
         ini->WriteInteger(str.c_str(), "Num2", PCfgObj(ObjTree->Items->Item[i]->Data)->Num2);
         ini->WriteInteger(str.c_str(), "Num3", PCfgObj(ObjTree->Items->Item[i]->Data)->Num3);
         ini->WriteInteger(str.c_str(), "Level", ObjTree->Items->Item[i]->Level);
         ini->WriteString(str.c_str(), "Name", PCfgObj(ObjTree->Items->Item[i]->Data)->Name);
         ini->WriteBool(str.c_str(), "IconVisible", PCfgObj(ObjTree->Items->Item[i]->Data)->IconVisible);
         ini->WriteInteger(str.c_str(), "X", PCfgObj(ObjTree->Items->Item[i]->Data)->X);
         ini->WriteInteger(str.c_str(), "Y", PCfgObj(ObjTree->Items->Item[i]->Data)->Y);
         if( PCfgObj(ObjTree->Items->Item[i]->Data)->Icon1Path != "")
            ini->WriteString(str.c_str(), "Icon1Path", PCfgObj(ObjTree->Items->Item[i]->Data)->Icon1Path);
         if( PCfgObj(ObjTree->Items->Item[i]->Data)->Icon2Path != "")
            ini->WriteString(str.c_str(), "Icon2Path", PCfgObj(ObjTree->Items->Item[i]->Data)->Icon2Path);
         if( PCfgObj(ObjTree->Items->Item[i]->Data)->Icon3Path != "")
            ini->WriteString(str.c_str(), "Icon3Path", PCfgObj(ObjTree->Items->Item[i]->Data)->Icon3Path);
         if( PCfgObj(ObjTree->Items->Item[i]->Data)->Icon4Path != "")
            ini->WriteString(str.c_str(), "Icon4Path", PCfgObj(ObjTree->Items->Item[i]->Data)->Icon4Path);
         if( PCfgObj(ObjTree->Items->Item[i]->Data)->Icon5Path != "")
            ini->WriteString(str.c_str(), "Icon5Path", PCfgObj(ObjTree->Items->Item[i]->Data)->Icon5Path);
         if( PCfgObj(ObjTree->Items->Item[i]->Data)->Icon6Path != "")
            ini->WriteString(str.c_str(), "Icon6Path", PCfgObj(ObjTree->Items->Item[i]->Data)->Icon6Path);
         if( PCfgObj(ObjTree->Items->Item[i]->Data)->Icon7Path != "")
            ini->WriteString(str.c_str(), "Icon7Path", PCfgObj(ObjTree->Items->Item[i]->Data)->Icon7Path);
         if( PCfgObj(ObjTree->Items->Item[i]->Data)->Icon8Path != "")
            ini->WriteString(str.c_str(), "Icon8Path", PCfgObj(ObjTree->Items->Item[i]->Data)->Icon8Path);
         ini->WriteBool(str.c_str(), "DK", PCfgObj(ObjTree->Items->Item[i]->Data)->Dk);
         ini->WriteBool(str.c_str(), "Bazalt", PCfgObj(ObjTree->Items->Item[i]->Data)->Bazalt);
         ini->WriteBool(str.c_str(), "Metka", PCfgObj(ObjTree->Items->Item[i]->Data)->Metka);
         ini->WriteBool(str.c_str(), "Razriv", PCfgObj(ObjTree->Items->Item[i]->Data)->Razriv);
         ini->WriteInteger(str.c_str(), "AdamOff", PCfgObj(ObjTree->Items->Item[i]->Data)->AdamOff);
         ini->WriteBool(str.c_str(), "AlarmMsgOn", PCfgObj(ObjTree->Items->Item[i]->Data)->AlarmMsgOn);
         ini->WriteBool( str.c_str(), "ConnectBlock", PCfgObj(ObjTree->Items->Item[i]->Data)->ConnectBlock );
         ini->WriteInteger(str.c_str(), "OutType", PCfgObj(ObjTree->Items->Item[i]->Data)->OutType);
         ini->WriteInteger(str.c_str(), "asoosd_kk", PCfgObj(ObjTree->Items->Item[i]->Data)->asoosd_kk);
         ini->WriteInteger(str.c_str(), "asoosd_nn", PCfgObj(ObjTree->Items->Item[i]->Data)->asoosd_nn);
         ini->WriteString(str.c_str(), "Description", PCfgObj(ObjTree->Items->Item[i]->Data)->description);
         ini->WriteFloat(str.c_str(), "lan", PCfgObj(ObjTree->Items->Item[i]->Data)->lan);
         ini->WriteFloat(str.c_str(), "lon", PCfgObj(ObjTree->Items->Item[i]->Data)->lon);
         ini->WriteBool(str.c_str(), "UdpUse", PCfgObj(ObjTree->Items->Item[i]->Data)->UdpUse);
         ini->WriteString(str.c_str(), "UdpAdress", PCfgObj(ObjTree->Items->Item[i]->Data)->UdpAdress);
         ini->WriteInteger(str.c_str(), "UpdPort", PCfgObj(ObjTree->Items->Item[i]->Data)->UpdPort);
      }

      ini->UpdateFile();
      delete ini;

      StatusBar1->Panels->Items[0]->Text = SaveDialog1->FileName;
   }
}
void __fastcall TMainForm::FileOpenItemClick(TObject *Sender)
{
   
   OpenDialog1->HistoryList->Clear();
   OpenDialog1->InitialDir = ExtractFilePath(Application->ExeName);
   OpenDialog1->FileName = ExtractFilePath(Application->ExeName) + "rifx.ini";

   if( OpenDialog1->Execute() )
   {
      if( FileExists(OpenDialog1->FileName) )
      {
        FileNewItemClick(this);
        MyDelay(500);

        ObjTree->Items->Clear();
        PCfgObj  CfgObj;
        CfgObj = new TCfgObj;
        CfgObj->Name = MsgStr25;

        TTreeNode* tempNode;
        ObjTree->Items->BeginUpdate();
        tempNode = ObjTree->Items->AddObject( ObjTree->Selected, CfgObj->Name, CfgObj );
        tempNode->SelectedIndex = 4;
        tempNode->ImageIndex = 4;
        tempNode->Selected = true;
        ObjTreeClick(this);

        ObjTree->Items->EndUpdate();

        ComboBox27->ItemIndex = 0;

        ComboBox29->ItemIndex = 2;
        ComboBox29Change(this);

        Edit3->Text = "";
        StrCopy(POutObj(lpMapCfg)->PlanPath, Edit3->Text.c_str() );

        ComboBox16Click(this);

        for( int i = 0; i < MaxPortCnt; i++) UsePort[i] = UnUsedComPort;

        ComboBox4->ItemIndex = 0;
        ComboBox18->ItemIndex = 0;
        CSpinEdit5->Value = 50;
        for( int i = 0; i < MaxPortCnt; i++)
        {
           RifPortSpeed[i] = 4800;
           RifPortInterval[i] = 50;
        }
        ComboBox5->ItemIndex = 0;
        CSpinEdit18->Value = 20;

        ComboBox20->ItemIndex = 0;
        for( int kan = 0; kan < MaxKanalDev; kan++ )
        {
           SsoiM_PortNum[kan] = 0;
           SsoiM_Interval[kan] = 1500;
           SsoiM_MaxErrCnt[kan] = 2;
        }
        ComboBox20Change(this);

        RastrPortNum = ComboBox7->ItemIndex;
        ComboBox10->ItemIndex = 0;
        SolidPortNum = ComboBox10->ItemIndex;
        ComboBox12->ItemIndex = 0;
        Adam4068PortNum = ComboBox12->ItemIndex;
        CSpinEdit6->Value = 100;
        ComboBox24->ItemIndex = 0;
        TabloPortNum = ComboBox24->ItemIndex;
        CheckBox1->Checked = false;

        ComboBox6->ItemIndex = 0;
        RxSpinEdit1->Value = 0.0;
        RxSpinEdit2->Value = 5.0;

        ComboBox15->ItemIndex = 0;
        Edit7->Text = "localhost";
        CSpinEdit1->Value = 1972;
        CSpinEdit9->Value = 20;
        CSpinEdit3->Value = 1974;
        ComboBox23->ItemIndex = 0;
        ComboBox30->ItemIndex = 0;
        ComboBox31->ItemIndex = 1;

        ComboBox13->ItemIndex = 0;
        Edit6->Text = "localhost";
        Edit10->Text = "";
        Edit11->Text = "";
        CSpinEdit11->Value = 3306;
        Edit9->Text = "";
        ComboBox11->ItemIndex = 0;
        CheckBox2->Checked = false;
        CheckBox3->Checked = false;

        ComboBox32->ItemIndex = 0;
        Edit15->Text = "localhost";
        CSpinEdit10->Value = 1973;
        CSpinEdit19->Value = 10;
        CSpinEdit26->Value = 1976;

        ComboBox17->ItemIndex = 0;
        Edit8->Text = "localhost";
        CSpinEdit2->Value = 1975;

        Icon1Path = "";
        Icon2Path = "";
        Icon3Path = "";
        Icon4Path = "";
        Icon5Path = "";
        Icon6Path = "";
        Icon7Path = "";
        Icon8Path = "";

        RadioButton1->Checked = true;
        RadioButton2->Checked = false;
        GobiFixNewWarning = 0;

        ComboBox25->ItemIndex = 0;
        RxSpinEdit3->Value = 50;

        RxSpinEdit4->Value = 0;
        RxSpinEdit5->Value = 0;

        ComboBox26->ItemIndex = 1;
        ComboBox26Change(this);
        OpList->Reset();
        AdvStringGrid1->RowCount = 2;
        AdvStringGrid1->ClearRows(1,1);

        ComboBox33->ItemIndex = 0;

        ComboBox34->ItemIndex = 0;

         TMemIniFile *ini;
         ini = new TMemIniFile( OpenDialog1->FileName );

         StatusBar1->Panels->Items[0]->Text = OpenDialog1->FileName;

         Edit3->Text = ini->ReadString( "PARAMS", "PlanPath", "" );
         StrCopy(POutObj(lpMapCfg)->PlanPath, Edit3->Text.c_str() );

         ComboBox27->ItemIndex =  ini->ReadInteger( "PARAMS", "SoundType", 0 );

         ComboBox29->ItemIndex =  ini->ReadInteger( "PARAMS", "PlanType", 2 );
         if( ComboBox29->ItemIndex > 0 )
         {
            Label27->Visible = false;
            Edit3->Visible = false;
            SpeedButton7->Visible = false;
            SpeedButton8->Visible = false;
         }

         if( ComboBox29->ItemIndex == 0 )
         {
            HWND H = FindWindow("MainForm", "����");

            if (H == NULL)
            {
               POutObj(lpMapCfg)->CfgMode = true;
               AnsiString cmd;
               cmd = ExtractFilePath(Application->ExeName) + "m_plan.exe";
               WinExec(cmd.c_str(), SW_SHOW	);
            }
         }
         else
         {
            POutObj(lpMapCfg)->CfgMode = false;
         }

         if( ComboBox29->ItemIndex > 0 )
         {
            Label27->Visible = false;
            Edit3->Visible = false;
            SpeedButton7->Visible = false;
            SpeedButton8->Visible = false;
         }
         else
         {
            Label27->Visible = true;
            Edit3->Visible = true;
            SpeedButton7->Visible = true;
            SpeedButton8->Visible = true;
         }

         Icon1Path = ini->ReadString( "PARAMS", "Icon1Path", "" );
         Icon2Path = ini->ReadString( "PARAMS", "Icon2Path", "" );
         Icon3Path = ini->ReadString( "PARAMS", "Icon3Path", "" );
         Icon4Path = ini->ReadString( "PARAMS", "Icon4Path", "" );
         Icon5Path = ini->ReadString( "PARAMS", "Icon5Path", "" );
         Icon6Path = ini->ReadString( "PARAMS", "Icon6Path", "" );
         Icon7Path = ini->ReadString( "PARAMS", "Icon7Path", "" );
         Icon8Path = ini->ReadString( "PARAMS", "Icon8Path", "" );

         ComboBox34->ItemIndex = ini->ReadInteger( "PARAMS", "AutoStart", 0 );

         SsoiVersion = ini->ReadInteger( "SSOI", "Version", 2 );
         AnsiString str;
         for( int kan = 0; kan < MaxKanalDev; kan++ )
         {
            str.sprintf("SsoiM_PortNum%d", kan+1);
            SsoiM_PortNum[kan] = ini->ReadInteger( "SSOI", str, 0 );
            str.sprintf("SsoiM_Interval%d", kan+1);
            SsoiM_Interval[kan] = ini->ReadInteger( "SSOI", str, 1500 );
            str.sprintf("SsoiM_MaxErrCnt%d", kan+1);
            SsoiM_MaxErrCnt[kan] = ini->ReadInteger( "SSOI", str, 2 );

            if( SsoiM_PortNum[kan] > 0 ) UsePort[SsoiM_PortNum[kan]] = SsoiComPort;

         }
         if( SsoiVersion == 2 ) ComboBox20->ItemIndex = 0;
         else ComboBox20->ItemIndex = 1;

         ComboBox33->ItemIndex = ini->ReadBool( "SSOI", "SsoiAutoDkUse", false );

         ComboBox20Change(this);

         ComboBox7->ItemIndex = ini->ReadInteger( "RASTR", "Port", 0 );
         ComboBox10->ItemIndex = ini->ReadInteger( "SOLID", "Port", 0 );
         ComboBox12->ItemIndex = ini->ReadInteger( "ADAM4068", "Port", 0 );
         CSpinEdit6->Value = ini->ReadInteger( "ADAM4068", "Interval", 100 );
         if( CSpinEdit6->Value < 50 ) CSpinEdit6->Value = 50;

         ComboBox24->ItemIndex = ini->ReadInteger( "TABLO", "Port", 0 );
         CheckBox1->Checked = ini->ReadBool( "TABLO", "Blinking", false );

         RastrPortNum = ComboBox7->ItemIndex;
         if( RastrPortNum > 0 ) UsePort[RastrPortNum] = RastrComPort;
         SolidPortNum = ComboBox10->ItemIndex;
         if( SolidPortNum > 0 ) UsePort[SolidPortNum] = SolidComPort;
         Adam4068PortNum = ComboBox12->ItemIndex;
         if( Adam4068PortNum > 0 ) UsePort[Adam4068PortNum] = AdamComPort;
         TabloPortNum = ComboBox24->ItemIndex;
         if( TabloPortNum > 0 ) UsePort[TabloPortNum] = TabloComPort;

         GobiFixNewWarning = ini->ReadInteger( "SSOI", "SsoiFixNewWarning", 0 );
         switch( GobiFixNewWarning )
         {
            case  1: RadioButton2->Checked = true; break;
            default: RadioButton1->Checked = true; break;
         }

         for( int kan = 0; kan < MaxPortCnt; kan++ )
         {
            str.sprintf("RifPortSpeed%d", kan+1);
            RifPortSpeed[kan] = ini->ReadInteger( "RIF", str, 4800 );
            str.sprintf("RifPortInterval%d", kan+1);
            RifPortInterval[kan] = ini->ReadInteger( "RIF", str, 50 );
         }
         CSpinEdit18->Value =  ini->ReadInteger("RIF", "TochkaDirectionInterval", 20);
         ComboBox6->ItemIndex = ini->ReadInteger( "RIF", "AutoDK", 0 );
         RxSpinEdit1->Value = ini->ReadFloat( "RIF", "Ul", 0.0 );
         RxSpinEdit2->Value = ini->ReadFloat( "RIF", "Uh", 5.0 );

         switch( RifPortSpeed[ComboBox4->ItemIndex] )
         {
            case   4800: ComboBox18->ItemIndex = 0; break;
            case   9600: ComboBox18->ItemIndex = 1; break;
            case  19200: ComboBox18->ItemIndex = 2; break;
            case  38400: ComboBox18->ItemIndex = 3; break;
            case  57600: ComboBox18->ItemIndex = 4; break;
            case 115200: ComboBox18->ItemIndex = 5; break;
            case 250000: ComboBox18->ItemIndex = 6; break;
            default:     ComboBox18->ItemIndex = 0; break;
         }

         ComboBox15->ItemIndex = ini->ReadInteger( "RASTRMTV", "Use", 0 );
         Edit7->Text = ini->ReadString( "RASTRMTV", "Name", "localhost" );
         CSpinEdit1->Value = ini->ReadInteger( "RASTRMTV", "Port", 1972 );
         CSpinEdit3->Value = ini->ReadInteger( "RASTRMTV", "Port2", 1974 );
         CSpinEdit9->Value = ini->ReadInteger( "RASTRMTV", "KeepAliveInterval", 20 );
         ComboBox23->ItemIndex = ini->ReadInteger( "RASTRMTV", "ThermostatUse", 0 );
         ComboBox30->ItemIndex = ini->ReadInteger( "RASTRMTV", "dtInfoToJpg", 0 );
         int temp = ini->ReadInteger( "RASTRMTV", "AutoDkPeriod", 0 );
         if (temp != 0 ) ComboBox31->ItemIndex = 1;
         ComboBox15Change(this);

         ComboBox32->ItemIndex = ini->ReadInteger( "INTEGRATION", "Use", 0 );
         Edit15->Text = ini->ReadString( "INTEGRATION", "Host", "localhost" );
         CSpinEdit10->Value = ini->ReadInteger( "INTEGRATION", "Port", 1973 );
         CSpinEdit19->Value = ini->ReadInteger( "INTEGRATION", "KeepAliveInterval", 10 );
         CSpinEdit26->Value = ini->ReadInteger( "INTEGRATION", "Port2", 1976 );

         ComboBox13->ItemIndex = ini->ReadInteger( "MYSQL", "Use", 0 );
         Edit6->Text = ini->ReadString( "MYSQL", "Host", "" );
         CSpinEdit11->Value = ini->ReadInteger( "MYSQL", "Port", 3306);
         Edit10->Text = ini->ReadString( "MYSQL", "Login", "" );
         Edit11->Text = XOR_Crypt(ini->ReadString("MYSQL", "Password", ""), "start7");
         Edit9->Text = ini->ReadString( "MYSQL", "DbName", "" );;
         ComboBox11->ItemIndex = ini->ReadInteger( "MYSQL", "Mode", 0 );
         CheckBox2->Checked = ini->ReadBool( "MYSQL", "P1", false );
         CheckBox3->Checked = ini->ReadBool( "MYSQL", "P2", false );
         CheckBox4->Checked = ini->ReadBool("MYSQL", "AutoDbStart", false);
         CSpinEdit24->Value = ini->ReadInteger("MYSQL", "AutoDbStartHour", 0);
         CSpinEdit25->Value = ini->ReadInteger("MYSQL", "AutoDbStartMinute", 0);

         ComboBox19->Items->Clear();
         ComboBox19->Items->Add(ini->ReadString(  "RASTRMSSOI", "SerNum", "" ));
         ComboBox19->ItemIndex = 0;
         ComboBox25->ItemIndex = ini->ReadInteger( "RASTRMSSOI", "Speed", 0 );
         RxSpinEdit3->Value = ini->ReadInteger( "RASTRMSSOI", "Timeout", 50 );

         Edit2->Text = ini->ReadString( "BACKUP", "BackupPath", "" );
         if( Edit2->Text == "" ) Edit2->Text = ExtractFilePath(Application->ExeName) + "\Backup";
         ComboBox8->ItemIndex = ini->ReadInteger( "BACKUP", "MaxBdStringCnt", 0 );

         if( ComplexVersion == Rastr_M_TvComplexType && ini->ReadInteger( "PORT", "Use", 0 ) == 1 ) ComboBox15->ItemIndex = 3;

         if( ini->ReadInteger("OPERATORS", "Use", 0 ) == 1 ) ComboBox26->ItemIndex = 0;
         else ComboBox26->ItemIndex = 1; 

         AdvStringGrid1->RowCount = 2;
         AdvStringGrid1->ClearRows(1,1);

         {
            OpList->OpCnt = ini->ReadInteger("OPERATORS", "Count", 0 );
            if( OpList->OpCnt > 0 )
            {
               for( int i = 0; i < OpList->OpCnt; i++ )
               {
                  str.sprintf("Operator_%d", i);
                  OpList->Op[i].FamilyName = ini->ReadString( str.c_str(), "FN", "" );
                  OpList->Op[i].FirstName = ini->ReadString( str.c_str(), "N1", "" );
                  OpList->Op[i].SecondName = ini->ReadString( str.c_str(), "N2", "" );
                  OpList->Op[i].Password = XOR_Crypt(ini->ReadString( str.c_str(), "PW", "" ), "start7");
               }

               for( int i = 0; i <  OpList->OpCnt; i++ )
               {
                  AdvStringGrid1->AddRow();
                  AdvStringGrid1->Cells[0][i+1] = i+1;
                  AdvStringGrid1->Cells[1][i+1] = OpList->Op[i].FamilyName;
                  AdvStringGrid1->Cells[2][i+1] = OpList->Op[i].FirstName;
                  AdvStringGrid1->Cells[3][i+1] = OpList->Op[i].SecondName;
                  if( OpList->Op[i].Password.Length() > 0 )
                     AdvStringGrid1->Cells[4][i+1] = "+";
                  else
                     AdvStringGrid1->Cells[4][i+1] = "-";
               }
            }
         }
         if( AdvStringGrid1->RowCount < 2 ) AdvStringGrid1->RowCount = 2;
         AdvStringGrid1->FixedRows = 1;
         ComboBox26Change(this);

         ComboBox17->ItemIndex = ini->ReadInteger( "ASOOSD", "Use", 0 );
         Edit8->Text = ini->ReadString( "ASOOSD", "Host", "" );
         CSpinEdit2->Value = ini->ReadInteger( "ASOOSD", "Port", 1975);

         Edit18->Text = ini->ReadString( "INTEGRATION", "DevLine", "c:\\Program Files\\DevLine\\Line\\observer.exe" );

         ObjTree->Items->BeginUpdate();
         int Cnt = ini->ReadInteger( "TREE", "Count", 0 );
         if( Cnt > 0 )
         {
            for( int i = 1; i <= Cnt; i++ )
            {
               str.sprintf("Obj_%d", i);
               PCfgObj  CfgObj;
               CfgObj = new TCfgObj;
               CfgObj->Type = ini->ReadInteger( str.c_str(), "Type", 0 );
               CfgObj->Num1 = ini->ReadInteger( str.c_str(), "Num1", 0 );
               CfgObj->Num2 = ini->ReadInteger( str.c_str(), "Num2", 0 );
               CfgObj->Num3 = ini->ReadInteger( str.c_str(), "Num3", 0 );
               CfgObj->Level = ini->ReadInteger( str.c_str(), "Level", 0 );
               CfgObj->Name = ini->ReadString( str.c_str(), "Name", "" );
               CfgObj->IconVisible = ini->ReadBool( str.c_str(), "IconVisible", false );
               CfgObj->X = ini->ReadInteger( str.c_str(), "X", 0 );
               CfgObj->Y = ini->ReadInteger( str.c_str(), "Y", 0 );
               CfgObj->Icon1Path = ini->ReadString( str.c_str(), "Icon1Path", "" );
               CfgObj->Icon2Path = ini->ReadString( str.c_str(), "Icon2Path", "" );
               CfgObj->Icon3Path = ini->ReadString( str.c_str(), "Icon3Path", "" );
               CfgObj->Icon4Path = ini->ReadString( str.c_str(), "Icon4Path", "" );
               CfgObj->Icon5Path = ini->ReadString( str.c_str(), "Icon5Path", "" );
               CfgObj->Icon6Path = ini->ReadString( str.c_str(), "Icon6Path", "" );
               CfgObj->Icon7Path = ini->ReadString( str.c_str(), "Icon7Path", "" );
               CfgObj->Icon8Path = ini->ReadString( str.c_str(), "Icon8Path", "" );
               CfgObj->Dk = ini->ReadBool( str.c_str(), "DK", true );
               CfgObj->Bazalt = ini->ReadBool( str.c_str(), "Bazalt", false );
               CfgObj->Metka = ini->ReadBool( str.c_str(), "Metka", false );
               CfgObj->Razriv = ini->ReadBool(str.c_str(), "Razriv", false);
               CfgObj->AdamOff = ini->ReadInteger( str.c_str(), "AdamOff", 0 );
               CfgObj->AlarmMsgOn = ini->ReadBool( str.c_str(), "AlarmMsgOn", 0 );
               CfgObj->ConnectBlock = ini->ReadBool( str.c_str(), "ConnectBlock", 0 );
               CfgObj->OutType = ini->ReadInteger( str.c_str(), "OutType", 0 );
               CfgObj->asoosd_kk = ini->ReadInteger( str.c_str(), "asoosd_kk", 0 );
               CfgObj->asoosd_nn = ini->ReadInteger( str.c_str(), "asoosd_nn", 0 );
               CfgObj->description = ini->ReadString( str.c_str(), "Description", "" );
               CfgObj->lan = ini->ReadFloat( str.c_str(), "lan", 0.0 );
               CfgObj->lon = ini->ReadFloat( str.c_str(), "lon", 0.0 );
               CfgObj->UdpUse = ini->ReadBool( str.c_str(), "UdpUse", false );
               CfgObj->UdpAdress = ini->ReadString( str.c_str(), "UdpAdress", "" );
               CfgObj->UpdPort = ini->ReadInteger( str.c_str(), "UpdPort", 0 );

              if( CfgObj->Type == 1 || CfgObj->Type == 111 )
              {
                 CfgObj->ImgNum = 5;
              }
              else if( CfgObj->Type == 2 )
              {
                 CfgObj->ImgNum = 10;
              }
              else if( CfgObj->Type == 3  )
              {
                 CfgObj->ImgNum = 0;
              }
              else if( CfgObj->Type == 4 )
              {
                 CfgObj->ImgNum = 28;
              }
              else if( CfgObj->Type == 42 )
              {
                 CfgObj->ImgNum = 48;
              }
              else if( CfgObj->Type == 51 )
              {
                 CfgObj->ImgNum = 48;
              }
              else if( CfgObj->Type == 7 )
              {
                 CfgObj->ImgNum = 28;
              }
              else if( CfgObj->Type == 71 )
              {
                 CfgObj->ImgNum = 0;
              }
              else if( CfgObj->Type == 8 )
              {
                 CfgObj->ImgNum = 5;
              }
              else if( CfgObj->Type == 9 )
              {
                 CfgObj->ImgNum = 5;
              }
              else if( CfgObj->Type == 10 )
              {
                 CfgObj->ImgNum = 15;
              }
              else if( CfgObj->Type == 11 )
              {
                 CfgObj->ImgNum = 10;
              }
              else if( CfgObj->Type == 12 )
              {
                 CfgObj->ImgNum = 28;
              }
              else if( CfgObj->Type == 14 )
              {
                 CfgObj->ImgNum = 50;
              }
              else if( CfgObj->Type == 26 )
              {
                 CfgObj->ImgNum = 50;
              }
              else if( CfgObj->Type == 29 )
              {
                 CfgObj->ImgNum = 50;
              }
              else if( CfgObj->Type == 15 )
              {
                 CfgObj->ImgNum = 38;
              }
              else if( CfgObj->Type == 27 )
              {
                 CfgObj->ImgNum = 43;
              }
              else if( CfgObj->Type == 30 )
              {
                 CfgObj->ImgNum = 38;
              }
              else if( CfgObj->Type == 16 )
              {
                 CfgObj->ImgNum = 38;
              }
              else if( CfgObj->Type == 17 )
              {
                 CfgObj->ImgNum = 38;
              }
              else if( CfgObj->Type == 32 )
              {
                 CfgObj->ImgNum = 48;
              }

               tempNode = ObjTree->Selected;

               if( CfgObj->Level == tempNode->Level )
               {
                  tempNode = ObjTree->Items->AddObject( ObjTree->Selected, CfgObj->Name, CfgObj );
               }
               else if( CfgObj->Level > tempNode->Level )
               {
                  if( PCfgObj(tempNode->Data)->Type == 0 )
                  {
                        tempNode->SelectedIndex = 5;
                        tempNode->ImageIndex = 5;
                  }

                  tempNode = ObjTree->Items->AddChildObject( ObjTree->Selected, CfgObj->Name, CfgObj );
               }
               else
               {
                  do
                  {
                     tempNode = tempNode->Parent;
                     tempNode->Selected = true;
                  }while( CfgObj->Level != tempNode->Level );
                  tempNode = ObjTree->Items->AddObject( ObjTree->Selected, CfgObj->Name, CfgObj );
               }

               if( CfgObj->Type == 0 )
               {
                  tempNode->SelectedIndex = 4;
                  tempNode->ImageIndex = 4;
               }
               else
               {
                  if( CfgObj->Type == 1 || CfgObj->Type == 2 ||
                      CfgObj->Type == 8 || CfgObj->Type == 9 ||
                      CfgObj->Type == 91 || CfgObj->Type == 21 ||
                      CfgObj->Type == 10 || CfgObj->Type == 111 )
                  {
                     UsePort[PCfgObj(tempNode->Data)->Num3] = RifComPort;
                     tempNode->SelectedIndex = 7;
                     tempNode->ImageIndex = 7;
                  }
                  else if( CfgObj->Type == 11 || CfgObj->Type == 12 )
                  {
                     UsePort[PCfgObj(tempNode->Data)->Num3] = RifComPort;
                     tempNode->SelectedIndex = 7;
                     tempNode->ImageIndex = 7;
                  }
                  else if( CfgObj->Type == 3 || CfgObj->Type == 4 )
                  {
                      if( SsoiVersion != 2 )
                      {
                         if( SsoiM_PortNum[0] != 0 )
                         {
                            tempNode->SelectedIndex = 7;
                            tempNode->ImageIndex = 7;
                         }
                         else
                         {
                            tempNode->SelectedIndex = 6;
                            tempNode->ImageIndex = 6;
                         }
                      }
                      else
                      {
                         if( PCfgObj(tempNode->Data)->Num1 == 1 && SsoiM_PortNum[0] != 0 )
                         {
                            tempNode->SelectedIndex = 7;
                            tempNode->ImageIndex = 7;
                         }
                         else if( PCfgObj(tempNode->Data)->Num1 == 2 && SsoiM_PortNum[1] != 0 )
                         {
                            tempNode->SelectedIndex = 7;
                            tempNode->ImageIndex = 7;
                         }
                         else if( PCfgObj(tempNode->Data)->Num1 == 3 && SsoiM_PortNum[2] != 0 )
                         {
                            tempNode->SelectedIndex = 7;
                            tempNode->ImageIndex = 7;
                         }
                         else if( PCfgObj(tempNode->Data)->Num1 == 4 && SsoiM_PortNum[3] != 0 )
                         {
                            tempNode->SelectedIndex = 7;
                            tempNode->ImageIndex = 7;
                         }
                         else
                         {
                            tempNode->SelectedIndex = 6;
                            tempNode->ImageIndex = 6;
                         }
                      }
                  }
                  else if( CfgObj->Type == 41 )
                  {
                     if( ComboBox5->ItemIndex == 0 )
                     {
                        tempNode->SelectedIndex = 8;
                        tempNode->ImageIndex = 8;
                     }
                     else
                     {
                        tempNode->SelectedIndex = 9;
                        tempNode->ImageIndex = 9;
                     }
                  }
                  else if( CfgObj->Type == 42 )
                  {
                        tempNode->SelectedIndex = 11;
                        tempNode->ImageIndex = 11;
                  }
                  else if( CfgObj->Type == 5 )
                  {
                     if( ComboBox7->ItemIndex == 0 )
                     {
                        tempNode->SelectedIndex = 8;
                        tempNode->ImageIndex = 8;
                     }
                     else
                     {
                        tempNode->SelectedIndex = 9;
                        tempNode->ImageIndex = 9;
                     }
                  }
                  else if( CfgObj->Type == 51 )
                  {
                     if( ComboBox15->ItemIndex == 0 )
                     {
                        tempNode->SelectedIndex = 8;
                        tempNode->ImageIndex = 8;
                     }
                     else
                     {
                        tempNode->SelectedIndex = 9;
                        tempNode->ImageIndex = 9;
                     }
                  }
                  else if( CfgObj->Type == 6 )
                  {
                     if( ComboBox10->ItemIndex == 0 )
                     {
                        tempNode->SelectedIndex = 8;
                        tempNode->ImageIndex = 8;
                     }
                     else
                     {
                        tempNode->SelectedIndex = 9;
                        tempNode->ImageIndex = 9;
                     }
                  }
                  else if( CfgObj->Type == 7 )
                  {
                     if( ComboBox12->ItemIndex == 0 )
                     {
                        tempNode->SelectedIndex = 6;
                        tempNode->ImageIndex = 6;
                     }
                     else
                     {
                        tempNode->SelectedIndex = 7;
                        tempNode->ImageIndex = 7;
                     }
                  }
                  else if( CfgObj->Type == 71 )
                  {
                     if( ComboBox24->ItemIndex > 0 )
                     {
                        tempNode->SelectedIndex = 15;
                        tempNode->ImageIndex = 15;
                     }
                     else
                     {
                        tempNode->SelectedIndex = 6;
                        tempNode->ImageIndex = 6;
                     }
                  }
                  else if( CfgObj->Type == 14 ||  CfgObj->Type == 15 ||
                            CfgObj->Type == 16 ||  CfgObj->Type == 17  )
                  {
                     tempNode->SelectedIndex = 7;
                     tempNode->ImageIndex = 7;
                  }
                  else if( CfgObj->Type == 26 ||  CfgObj->Type == 27 ||
                            CfgObj->Type == 28 )
                  {
                     tempNode->SelectedIndex = 7;
                     tempNode->ImageIndex = 7;
                  }
                  else if( CfgObj->Type == 29 ||  CfgObj->Type == 30 ||
                            CfgObj->Type == 31 )
                  {
                     tempNode->SelectedIndex = 7;
                     tempNode->ImageIndex = 7;
                  }
                  else if( CfgObj->Type == 100 )
                  {
                     tempNode->SelectedIndex = 7;
                     tempNode->ImageIndex = 7;
                  }
                  else if( CfgObj->Type == 24 || CfgObj->Type == 25 )
                  {
                     tempNode->SelectedIndex = 11;
                     tempNode->ImageIndex = 11;
                  }
                  else if( CfgObj->Type ==32  )
                  {
                     tempNode->SelectedIndex = 11;
                     tempNode->ImageIndex = 11;
                  }
                  else if( CfgObj->Type == 200  )
                  {
                     tempNode->SelectedIndex = 16;
                     tempNode->ImageIndex = 16;
                  }
               }
               tempNode->Selected = true;
            }
         }

         tempNode = ObjTree->Items->Item[0];
         tempNode->Selected = true;
         ObjTreeClick(this);

         ObjTree->FullCollapse();
         ObjTree->Items->EndUpdate();

         delete ini;

         MyDelay(500);
         POutObj(lpMapCfg)->FileOperationId = 2;
      }
   }
}
void __fastcall TMainForm::ObjTreeClick(TObject *Sender)
{
   AnsiString str, str1;

   GroupBox25->Visible = false;

   if( PCfgObj(ObjTree->Selected->Data)->Type == 0 )
      str.sprintf("%s: \"%s\"", MsgStr26, PCfgObj(ObjTree->Selected->Data)->Name);
   else if( PCfgObj(ObjTree->Selected->Data)->Type == 1 )
   {
      if( PCfgObj(ObjTree->Selected->Data)->AdamOff == 0 )
      {
         if( !PCfgObj(ObjTree->Selected->Data)->UdpUse )
            str.sprintf("���-���:%d ���:%d", PCfgObj(ObjTree->Selected->Data)->Num1,
               PCfgObj(ObjTree->Selected->Data)->Num3);
         else
            str.sprintf("���-���:%d ���:%s::%d", PCfgObj(ObjTree->Selected->Data)->Num1,
               PCfgObj(ObjTree->Selected->Data)->UdpAdress, PCfgObj(ObjTree->Selected->Data)->UpdPort);
      }
      else if( PCfgObj(ObjTree->Selected->Data)->AdamOff == 1 )
      {
         if( !PCfgObj(ObjTree->Selected->Data)->UdpUse )
            str.sprintf("���-���24:%d ���:%d", PCfgObj(ObjTree->Selected->Data)->Num1,
               PCfgObj(ObjTree->Selected->Data)->Num3);
         else
            str.sprintf("���-���24:%d ���:%s::%d", PCfgObj(ObjTree->Selected->Data)->Num1,
               PCfgObj(ObjTree->Selected->Data)->UdpAdress, PCfgObj(ObjTree->Selected->Data)->UpdPort);
      }
      else if( PCfgObj(ObjTree->Selected->Data)->AdamOff == 2 )
      {
         if( !PCfgObj(ObjTree->Selected->Data)->UdpUse )
            str.sprintf("���-���(�):%d ���:%d", PCfgObj(ObjTree->Selected->Data)->Num1,
               PCfgObj(ObjTree->Selected->Data)->Num3);
         else
            str.sprintf("���-���(�):%d ���:%s::%d", PCfgObj(ObjTree->Selected->Data)->Num1,
               PCfgObj(ObjTree->Selected->Data)->UdpAdress, PCfgObj(ObjTree->Selected->Data)->UpdPort);
      }
       else if( PCfgObj(ObjTree->Selected->Data)->AdamOff == 3 )
       {
         if( !PCfgObj(ObjTree->Selected->Data)->UdpUse )
            str.sprintf("���-���:%d ���:%d", PCfgObj(ObjTree->Selected->Data)->Num1,
               PCfgObj(ObjTree->Selected->Data)->Num3);
         else
            str.sprintf("���-���:%d ���:%s::%d", PCfgObj(ObjTree->Selected->Data)->Num1,
               PCfgObj(ObjTree->Selected->Data)->UdpAdress, PCfgObj(ObjTree->Selected->Data)->UpdPort);
       }
       else if( PCfgObj(ObjTree->Selected->Data)->AdamOff == 4 )
       {
         if( !PCfgObj(ObjTree->Selected->Data)->UdpUse )
            str.sprintf("������:%d ���:%d", PCfgObj(ObjTree->Selected->Data)->Num1,
               PCfgObj(ObjTree->Selected->Data)->Num3);
         else
            str.sprintf("������:%d ���:%s::%d", PCfgObj(ObjTree->Selected->Data)->Num1,
               PCfgObj(ObjTree->Selected->Data)->UdpAdress, PCfgObj(ObjTree->Selected->Data)->UpdPort);
       }
       else if( PCfgObj(ObjTree->Selected->Data)->AdamOff == 5 )
       {
         if( !PCfgObj(ObjTree->Selected->Data)->UdpUse )
            str.sprintf("������-1�:%d ���:%d", PCfgObj(ObjTree->Selected->Data)->Num1,
               PCfgObj(ObjTree->Selected->Data)->Num3);
         else
            str.sprintf("������-1�:%d ���:%s::%d", PCfgObj(ObjTree->Selected->Data)->Num1,
               PCfgObj(ObjTree->Selected->Data)->UdpAdress, PCfgObj(ObjTree->Selected->Data)->UpdPort);
       }
       else
       {
         if( !PCfgObj(ObjTree->Selected->Data)->UdpUse )
            str.sprintf("���-���:%d ���:%d", PCfgObj(ObjTree->Selected->Data)->Num1,
               PCfgObj(ObjTree->Selected->Data)->Num3);
         else
            str.sprintf("���-���:%d ���:%s::%d", PCfgObj(ObjTree->Selected->Data)->Num1,
               PCfgObj(ObjTree->Selected->Data)->UdpAdress, PCfgObj(ObjTree->Selected->Data)->UpdPort);
       }

      RxSpinEdit6->Value = PCfgObj(ObjTree->Selected->Data)->lan;
      RxSpinEdit7->Value = PCfgObj(ObjTree->Selected->Data)->lon;
      Edit17->Text = PCfgObj(ObjTree->Selected->Data)->description;
      GroupBox25->Visible = true;
   }
   else if( PCfgObj(ObjTree->Selected->Data)->Type == 111 )
   {
      if( !PCfgObj(ObjTree->Selected->Data)->UdpUse )
         str.sprintf("���-���-�:%d ���:%d", PCfgObj(ObjTree->Selected->Data)->Num1,
            PCfgObj(ObjTree->Selected->Data)->Num3);
      else
         str.sprintf("���-���-�:%d ���:%s::%d", PCfgObj(ObjTree->Selected->Data)->Num1,
            PCfgObj(ObjTree->Selected->Data)->UdpAdress, PCfgObj(ObjTree->Selected->Data)->UpdPort);

      RxSpinEdit6->Value = PCfgObj(ObjTree->Selected->Data)->lan;
      RxSpinEdit7->Value = PCfgObj(ObjTree->Selected->Data)->lon;
      Edit17->Text = PCfgObj(ObjTree->Selected->Data)->description;
      GroupBox25->Visible = true;
   }
   else if( PCfgObj(ObjTree->Selected->Data)->Type == 2 )
   {
      if( !PCfgObj(ObjTree->Selected->Data)->UdpUse )
         str.sprintf("������������:%d ��:%d ���:%d", PCfgObj(ObjTree->Selected->Data)->Num1,
            PCfgObj(ObjTree->Selected->Data)->Num2, PCfgObj(ObjTree->Selected->Data)->Num3);
      else
         str.sprintf("������������:%d ��:%d ���:%s::%d", PCfgObj(ObjTree->Selected->Data)->Num1,
            PCfgObj(ObjTree->Selected->Data)->Num2,
            PCfgObj(ObjTree->Selected->Data)->UdpAdress, PCfgObj(ObjTree->Selected->Data)->UpdPort);

      RxSpinEdit6->Value = PCfgObj(ObjTree->Selected->Data)->lan;
      RxSpinEdit7->Value = PCfgObj(ObjTree->Selected->Data)->lon;
      Edit17->Text = PCfgObj(ObjTree->Selected->Data)->description;
      GroupBox25->Visible = true;
   }
   else if( PCfgObj(ObjTree->Selected->Data)->Type == 21 )
   {
      if( !PCfgObj(ObjTree->Selected->Data)->UdpUse )
         str.sprintf("������ ��:%d ��:%d ���:%d", PCfgObj(ObjTree->Selected->Data)->Num1,
            PCfgObj(ObjTree->Selected->Data)->Num2, PCfgObj(ObjTree->Selected->Data)->Num3);
      else
         str.sprintf("������ ��:%d ��:%d ���:%s::%d", PCfgObj(ObjTree->Selected->Data)->Num1,
            PCfgObj(ObjTree->Selected->Data)->Num2,
            PCfgObj(ObjTree->Selected->Data)->UdpAdress, PCfgObj(ObjTree->Selected->Data)->UpdPort);
      RxSpinEdit6->Value = PCfgObj(ObjTree->Selected->Data)->lan;
      RxSpinEdit7->Value = PCfgObj(ObjTree->Selected->Data)->lon;
      Edit17->Text = PCfgObj(ObjTree->Selected->Data)->description;
      GroupBox25->Visible = true;
   }
   else if( PCfgObj(ObjTree->Selected->Data)->Type == 3 && ComplexVersion != Rastr_M_SsoiComplexType )
   {
      if( PCfgObj(ObjTree->Selected->Data)->Num3 < 9 )
      {
         if( POprosObj(ObjTree->Selected->Data)->Bazalt )
         {
            str.sprintf("%s:%d %s:%d %s:%d + %s:%d", MsgStr27, PCfgObj(ObjTree->Selected->Data)->Num1, MsgStr28,
               PCfgObj(ObjTree->Selected->Data)->Num2, MsgStr29, PCfgObj(ObjTree->Selected->Data)->Num3, MsgStr30,
               PCfgObj(ObjTree->Selected->Data)->Num3 );
         }
         else if( POprosObj(ObjTree->Selected->Data)->ConnectBlock )
         {
            str.sprintf("%s:%d %s:%d %s:%d + %s:%d", MsgStr27, PCfgObj(ObjTree->Selected->Data)->Num1, MsgStr28,
               PCfgObj(ObjTree->Selected->Data)->Num2, MsgStr29, PCfgObj(ObjTree->Selected->Data)->Num3, MsgStr30,
               PCfgObj(ObjTree->Selected->Data)->Num3-3 );
         }
         else
         {
             switch( POprosObj(ObjTree->Selected->Data)->OutType )
             {
                case 1: str1 = "���-���"; break;
                case 2: str1 = "���-���"; break;
                case 3: str1 = "���-����"; break;
                case 4: str1 = "���-���-�"; break;
                case 5: str1 = "������"; break;
                case 6: str1 = "�����/�����"; break;
                case 7: str1 = "������"; break;
                default: str1 = " "; break;
             }

             str.sprintf("%s:%d %s:%d %s:%d %s", MsgStr27, POprosObj(ObjTree->Selected->Data)->Num1, MsgStr28,
                POprosObj(ObjTree->Selected->Data)->Num2, MsgStr29, POprosObj(ObjTree->Selected->Data)->Num3, str1);
         }
      }
      else
         str.sprintf("%s:%d %s:%d %s", MsgStr27, PCfgObj(ObjTree->Selected->Data)->Num1, MsgStr28,
            PCfgObj(ObjTree->Selected->Data)->Num2, MCFGInfoStr27);

      RxSpinEdit6->Value = PCfgObj(ObjTree->Selected->Data)->lan;
      RxSpinEdit7->Value = PCfgObj(ObjTree->Selected->Data)->lon;
      Edit17->Text = PCfgObj(ObjTree->Selected->Data)->description;
      GroupBox25->Visible = true;
   }
   else if( PCfgObj(ObjTree->Selected->Data)->Type == 4 && ComplexVersion != Rastr_M_SsoiComplexType )
   {
      if( PCfgObj(ObjTree->Selected->Data)->Num3 < 4 )
         str.sprintf("%s:%d %s:%d %s:%d", MsgStr27,PCfgObj(ObjTree->Selected->Data)->Num1, MsgStr28,
            PCfgObj(ObjTree->Selected->Data)->Num2, MsgStr30, PCfgObj(ObjTree->Selected->Data)->Num3);
      else str.sprintf("%s:%d %s:%d %s:%d", MsgStr27,PCfgObj(ObjTree->Selected->Data)->Num1, MsgStr28,
            PCfgObj(ObjTree->Selected->Data)->Num2, MsgStr31, (PCfgObj(ObjTree->Selected->Data)->Num3-3));
   }
   else if( PCfgObj(ObjTree->Selected->Data)->Type == 3 && ComplexVersion == Rastr_M_SsoiComplexType )
   {
      if( POprosObj(ObjTree->Selected->Data)->Num3 != 5 )
         str.sprintf("���:%d ��:%d ��:%d", POprosObj(ObjTree->Selected->Data)->Num1,
            POprosObj(ObjTree->Selected->Data)->Num2, POprosObj(ObjTree->Selected->Data)->Num3);
      else
         str.sprintf("���:%d ��:%d ��������", POprosObj(ObjTree->Selected->Data)->Num1,
            POprosObj(ObjTree->Selected->Data)->Num2 );

      RxSpinEdit6->Value = PCfgObj(ObjTree->Selected->Data)->lan;
      RxSpinEdit7->Value = PCfgObj(ObjTree->Selected->Data)->lon;
      Edit17->Text = PCfgObj(ObjTree->Selected->Data)->description;
      GroupBox25->Visible = true;
   }
   else if( PCfgObj(ObjTree->Selected->Data)->Type == 4 && ComplexVersion == Rastr_M_SsoiComplexType )
   {
      str.sprintf("���:%d ��:%d ��:%d", PCfgObj(ObjTree->Selected->Data)->Num1,
         PCfgObj(ObjTree->Selected->Data)->Num2, PCfgObj(ObjTree->Selected->Data)->Num3);
   }
   else if( PCfgObj(ObjTree->Selected->Data)->Type == 41 )
      str.sprintf("%s:%d-%02d-%d", MsgStr33, PCfgObj(ObjTree->Selected->Data)->Num1,
         PCfgObj(ObjTree->Selected->Data)->Num2, PCfgObj(ObjTree->Selected->Data)->Num3);
   else if( PCfgObj(ObjTree->Selected->Data)->Type == 42 )
   {
      str.sprintf("%s:\n%s -(%s)-%02d", MsgStr33, PCfgObj(ObjTree->Selected->Data)->Icon2Path,
         PCfgObj(ObjTree->Selected->Data)->Icon1Path, PCfgObj(ObjTree->Selected->Data)->Num3);
   }
   else if( PCfgObj(ObjTree->Selected->Data)->Type == 5 )
      str.sprintf("%s:%d %s:%d", MsgStr34, PCfgObj(ObjTree->Selected->Data)->Num1, MsgStr33,
         (PCfgObj(ObjTree->Selected->Data)->Num2-1));
   else if( PCfgObj(ObjTree->Selected->Data)->Type == 51 )
      str.sprintf("%s:%d %s:%d", MsgStr34, PCfgObj(ObjTree->Selected->Data)->Num1, MsgStr33,
         (PCfgObj(ObjTree->Selected->Data)->Num2));
   else if( PCfgObj(ObjTree->Selected->Data)->Type == 52 )
      str.sprintf("%s:%d", MsgStr33, PCfgObj(ObjTree->Selected->Data)->Num1);
   else if( PCfgObj(ObjTree->Selected->Data)->Type == 6 )
      str.sprintf("��C-������:%03d", PCfgObj(ObjTree->Selected->Data)->Num1);
   else if( PCfgObj(ObjTree->Selected->Data)->Type == 7 )
      str.sprintf("����-406x/4168:%03d-%d", PCfgObj(ObjTree->Selected->Data)->Num1,
         PCfgObj(ObjTree->Selected->Data)->Num2);
   else if( PCfgObj(ObjTree->Selected->Data)->Type == 71 )
      str.sprintf("���.�����: ���:%d %s", TabloPortNum, PCfgObj(ObjTree->Selected->Data)->Name);
   else if( PCfgObj(ObjTree->Selected->Data)->Type == 8 )
   {
      if( !PCfgObj(ObjTree->Selected->Data)->UdpUse )
         str.sprintf("�����, ������-2�:%d ���:%d", PCfgObj(ObjTree->Selected->Data)->Num1,
            PCfgObj(ObjTree->Selected->Data)->Num3);
      else
         str.sprintf("�����, ������-2�:%d ���:%s::%d", POprosObj(ObjTree->Selected->Data)->Num1,
            PCfgObj(ObjTree->Selected->Data)->UdpAdress, PCfgObj(ObjTree->Selected->Data)->UpdPort);

      RxSpinEdit6->Value = PCfgObj(ObjTree->Selected->Data)->lan;
      RxSpinEdit7->Value = PCfgObj(ObjTree->Selected->Data)->lon;
      Edit17->Text = PCfgObj(ObjTree->Selected->Data)->description;
      GroupBox25->Visible = true;
   }
   else if( PCfgObj(ObjTree->Selected->Data)->Type == 9 )
   {
      if( !PCfgObj(ObjTree->Selected->Data)->UdpUse )
         str.sprintf("����:%d ���:%d", PCfgObj(ObjTree->Selected->Data)->Num1,
            PCfgObj(ObjTree->Selected->Data)->Num3);
      else
         str.sprintf("����:%d ���:%s::%d", POprosObj(ObjTree->Selected->Data)->Num1,
            PCfgObj(ObjTree->Selected->Data)->UdpAdress, PCfgObj(ObjTree->Selected->Data)->UpdPort);

      RxSpinEdit6->Value = PCfgObj(ObjTree->Selected->Data)->lan;
      RxSpinEdit7->Value = PCfgObj(ObjTree->Selected->Data)->lon;
      Edit17->Text = PCfgObj(ObjTree->Selected->Data)->description;
      GroupBox25->Visible = true;
   }
   else if( PCfgObj(ObjTree->Selected->Data)->Type == 91 )
   {
      if( !PCfgObj(ObjTree->Selected->Data)->UdpUse )
         str.sprintf("�����:%d ���:%d", PCfgObj(ObjTree->Selected->Data)->Num1,
            PCfgObj(ObjTree->Selected->Data)->Num3);
      else
         str.sprintf("�����:%d ���:%s::%d", POprosObj(ObjTree->Selected->Data)->Num1,
            PCfgObj(ObjTree->Selected->Data)->UdpAdress, PCfgObj(ObjTree->Selected->Data)->UpdPort);

      RxSpinEdit6->Value = PCfgObj(ObjTree->Selected->Data)->lan;
      RxSpinEdit7->Value = PCfgObj(ObjTree->Selected->Data)->lon;
      Edit17->Text = PCfgObj(ObjTree->Selected->Data)->description;
      GroupBox25->Visible = true;
   }
   else if( PCfgObj(ObjTree->Selected->Data)->Type == 10 )
   {
      if( !PCfgObj(ObjTree->Selected->Data)->UdpUse )
         str.sprintf("�����/�����:%d ��:%d ���:%d", PCfgObj(ObjTree->Selected->Data)->Num1,
            PCfgObj(ObjTree->Selected->Data)->Num2, PCfgObj(ObjTree->Selected->Data)->Num3);
      else
         str.sprintf("�����/�����:%d ��:%d ���:%s::%d", POprosObj(ObjTree->Selected->Data)->Num1,
            PCfgObj(ObjTree->Selected->Data)->Num2,
            PCfgObj(ObjTree->Selected->Data)->UdpAdress, PCfgObj(ObjTree->Selected->Data)->UpdPort);


      RxSpinEdit6->Value = PCfgObj(ObjTree->Selected->Data)->lan;
      RxSpinEdit7->Value = PCfgObj(ObjTree->Selected->Data)->lon;
      Edit17->Text = PCfgObj(ObjTree->Selected->Data)->description;
      GroupBox25->Visible = true;
   }
   else if( PCfgObj(ObjTree->Selected->Data)->Type == 11 )
   {
      if( !PCfgObj(ObjTree->Selected->Data)->UdpUse )
      {
         if( POprosObj(ObjTree->Selected->Data)->Bazalt )
         {
            str.sprintf("��-IP ���:%d ��:%d - ��:%d", PCfgObj(ObjTree->Selected->Data)->Num3,
                                                      PCfgObj(ObjTree->Selected->Data)->Num2,
                                                      PCfgObj(ObjTree->Selected->Data)->Num2 );
         }
         else if( POprosObj(ObjTree->Selected->Data)->ConnectBlock )
         {
            str.sprintf("��-IP ���:%d ��:%d - ��:%d", PCfgObj(ObjTree->Selected->Data)->Num3,
                                                      PCfgObj(ObjTree->Selected->Data)->Num2,
                                                      PCfgObj(ObjTree->Selected->Data)->Num2-3 );
         }
         else str.sprintf("��-IP ���:%d ��:%d", PCfgObj(ObjTree->Selected->Data)->Num3,
                                                PCfgObj(ObjTree->Selected->Data)->Num2 );
      }
      else
      {
         if( POprosObj(ObjTree->Selected->Data)->Bazalt )
         {
            str.sprintf("��-IP ���:%s::%d ��:%d - ��:%d", PCfgObj(ObjTree->Selected->Data)->UdpAdress,
                                                           PCfgObj(ObjTree->Selected->Data)->UpdPort,
                                                           PCfgObj(ObjTree->Selected->Data)->Num2,
                                                           PCfgObj(ObjTree->Selected->Data)->Num2 );
         }
         else if( POprosObj(ObjTree->Selected->Data)->ConnectBlock )
         {
            str.sprintf("��-IP ���:%s::%d ��:%d - ��:%d", PCfgObj(ObjTree->Selected->Data)->UdpAdress,
                                                           PCfgObj(ObjTree->Selected->Data)->UpdPort,
                                                           PCfgObj(ObjTree->Selected->Data)->Num2,
                                                           PCfgObj(ObjTree->Selected->Data)->Num2-3 );
         }
         else str.sprintf("��-IP ���:%s::%d ��:%d", PCfgObj(ObjTree->Selected->Data)->UdpAdress,
                     PCfgObj(ObjTree->Selected->Data)->UpdPort, POprosObj(ObjTree->Selected->Data)->Num2 );
      }

      RxSpinEdit6->Value = PCfgObj(ObjTree->Selected->Data)->lan;
      RxSpinEdit7->Value = PCfgObj(ObjTree->Selected->Data)->lon;
      Edit17->Text = PCfgObj(ObjTree->Selected->Data)->description;
      GroupBox25->Visible = true;
   }
   else if( PCfgObj(ObjTree->Selected->Data)->Type == 12 )
   {
      if( !PCfgObj(ObjTree->Selected->Data)->UdpUse )
         str.sprintf("��-IP ���:%d ��:%d ", PCfgObj(ObjTree->Selected->Data)->Num3,
            PCfgObj(ObjTree->Selected->Data)->Num2 );
      else
         str.sprintf("��-IP ���:%s::%d ��:%d", PCfgObj(ObjTree->Selected->Data)->UdpAdress, PCfgObj(ObjTree->Selected->Data)->UpdPort,
                                               POprosObj(ObjTree->Selected->Data)->Num2);
   }
   else if( PCfgObj(ObjTree->Selected->Data)->Type == 100 )
   {
      str.sprintf("%s\n PID=%s", PCfgObj(ObjTree->Selected->Data)->Icon2Path,
                  PCfgObj(ObjTree->Selected->Data)->Icon1Path);
   }
   else if( PCfgObj(ObjTree->Selected->Data)->Type == 24 )
      str.sprintf("�����-IP: %s; %s", PCfgObj(ObjTree->Selected->Data)->Icon1Path, PCfgObj(ObjTree->Selected->Data)->Icon4Path);
   else if( PCfgObj(ObjTree->Selected->Data)->Type == 25 )
      str.sprintf("ONVIF-������:%s", PCfgObj(ObjTree->Selected->Data)->Icon1Path);
   else if( PCfgObj(ObjTree->Selected->Data)->Type == 26  ||
            PCfgObj(ObjTree->Selected->Data)->Type == 29  )
   {
      if( PCfgObj(ObjTree->Selected->Data)->Type == 26  )
      {
         if( !PCfgObj(ObjTree->Selected->Data)->UdpUse )
            str.sprintf("�����-�/�����-� ���:%d ���:%d", PCfgObj(ObjTree->Selected->Data)->Num3, PCfgObj(ObjTree->Selected->Data)->Num1);
         else
            str.sprintf("�����-�/�����-� ���:%s::%d ���:%d", PCfgObj(ObjTree->Selected->Data)->UdpAdress, PCfgObj(ObjTree->Selected->Data)->UpdPort,
               POprosObj(ObjTree->Selected->Data)->Num1);
      }
      else
      {
         if( !PCfgObj(ObjTree->Selected->Data)->UdpUse )
            str.sprintf("����/����-� ���:%d ���:%d", PCfgObj(ObjTree->Selected->Data)->Num3, PCfgObj(ObjTree->Selected->Data)->Num1);
         else
            str.sprintf("����/����-� ���:%s::%d ���:%d", PCfgObj(ObjTree->Selected->Data)->UdpAdress, PCfgObj(ObjTree->Selected->Data)->UpdPort,
                     POprosObj(ObjTree->Selected->Data)->Num1);
      }

      RxSpinEdit6->Value = PCfgObj(ObjTree->Selected->Data)->lan;
      RxSpinEdit7->Value = PCfgObj(ObjTree->Selected->Data)->lon;
      Edit17->Text = PCfgObj(ObjTree->Selected->Data)->description;
      GroupBox25->Visible = true;
   }
   else if( PCfgObj(ObjTree->Selected->Data)->Type == 27  ||
            PCfgObj(ObjTree->Selected->Data)->Type == 30  )
   {
      int flangnum = PCfgObj(ObjTree->Selected->Data)->Num2/100;
      if( PCfgObj(ObjTree->Selected->Data)->Type == 27  )
      {
         if( !PCfgObj(ObjTree->Selected->Data)->UdpUse )
            str.sprintf("�����-�/�����-� ���:%d ���:%d �������:%d", PCfgObj(ObjTree->Selected->Data)->Num3, PCfgObj(ObjTree->Selected->Data)->Num1, flangnum);
         else
            str.sprintf("�����-�/�����-� ���:%s::%d ���:%d �������:%d ", PCfgObj(ObjTree->Selected->Data)->UdpAdress, PCfgObj(ObjTree->Selected->Data)->UpdPort,
               POprosObj(ObjTree->Selected->Data)->Num1, flangnum);
      }
      else
      {
         if( !PCfgObj(ObjTree->Selected->Data)->UdpUse )
            str.sprintf("����/����-� ���:%d ���:%d �������:%d", PCfgObj(ObjTree->Selected->Data)->Num3, PCfgObj(ObjTree->Selected->Data)->Num1, flangnum );
         else
            str.sprintf("����/����-� ���:%s::%d ���:%d �������:%d", PCfgObj(ObjTree->Selected->Data)->UdpAdress, PCfgObj(ObjTree->Selected->Data)->UpdPort,
                  POprosObj(ObjTree->Selected->Data)->Num1, flangnum);
      }
   }
   else if( PCfgObj(ObjTree->Selected->Data)->Type == 28  ||
            PCfgObj(ObjTree->Selected->Data)->Type == 31  )
   {
      int flangnum = PCfgObj(ObjTree->Selected->Data)->Num2/100;
      int dvnum = PCfgObj(ObjTree->Selected->Data)->Num2%100 + 1;

      PCfgObj(ObjTree->Selected->Data)->IconVisible = false;

      if( PCfgObj(ObjTree->Selected->Data)->Type == 28  )
      {
         if( !PCfgObj(ObjTree->Selected->Data)->UdpUse )
            str.sprintf("�����-�/�����-�  ���:%d ���:%d �������:%d ��:%d", PCfgObj(ObjTree->Selected->Data)->Num3, PCfgObj(ObjTree->Selected->Data)->Num1, flangnum, dvnum);
         else
            str.sprintf("�����-�/�����-� ���:%s::%d ���:%d �������:%d ��:%d", PCfgObj(ObjTree->Selected->Data)->UdpAdress, PCfgObj(ObjTree->Selected->Data)->UpdPort,
               PCfgObj(ObjTree->Selected->Data)->Num1, flangnum, dvnum);
      }
      else
      {
         if( !PCfgObj(ObjTree->Selected->Data)->UdpUse )
            str.sprintf("����/����-� ���:%d ���:%d �������:%d ��:%d ", PCfgObj(ObjTree->Selected->Data)->Num3, PCfgObj(ObjTree->Selected->Data)->Num1, flangnum, dvnum);
         else
            str.sprintf("����/����-� ���:%s::%d ���:%d �������:%d ��:%d", PCfgObj(ObjTree->Selected->Data)->UdpAdress, PCfgObj(ObjTree->Selected->Data)->UpdPort,
               PCfgObj(ObjTree->Selected->Data)->Num1, flangnum, dvnum);
      }

      RxSpinEdit6->Value = PCfgObj(ObjTree->Selected->Data)->lan;
      RxSpinEdit7->Value = PCfgObj(ObjTree->Selected->Data)->lon;
      Edit17->Text = PCfgObj(ObjTree->Selected->Data)->description;
      GroupBox25->Visible = true;
   }
   else if( PCfgObj(ObjTree->Selected->Data)->Type == 32  )
   {
      str.sprintf("DevLine-������:%d �����:%d", PCfgObj(ObjTree->Selected->Data)->Num1,  PCfgObj(ObjTree->Selected->Data)->OutType);
      GroupBox27->Visible = true;

      CSpinEdit20->Value = PCfgObj(ObjTree->Selected->Data)->Num2;
      CSpinEdit21->Value = PCfgObj(ObjTree->Selected->Data)->Num3;
      CSpinEdit22->Value = PCfgObj(ObjTree->Selected->Data)->X;
      CSpinEdit23->Value = PCfgObj(ObjTree->Selected->Data)->Y;
   }
   else if( PCfgObj(ObjTree->Selected->Data)->Type == 200 )
      str.sprintf("������� ����-��:%s", PCfgObj(ObjTree->Selected->Data)->Icon1Path);

   StaticText1->Caption = str;

   if( PCfgObj(ObjTree->Selected->Data)->Type != 200 )
   {
      int type = POprosObj(ObjTree->Selected->Data)->Type;
      int num3 =  POprosObj(ObjTree->Selected->Data)->Num3;
      if( type == 4 && POprosObj(ObjTree->Selected->Data)->Num3 >= 4 && ComboBox20->ItemIndex == 0 ) { type = 44; num3 -= 3; }
      if( type == 3 && ComboBox20->ItemIndex == 0 ) type = 33;
      if( type == 4 && ComboBox20->ItemIndex == 0 ) type = 43;

      str.sprintf("img_%d_%d_%d_%d", type, PCfgObj(ObjTree->Selected->Data)->Num1, PCfgObj(ObjTree->Selected->Data)->Num2, num3);

       StrCopy(POutObj(lpMapCfg)->ImgName, str.c_str());
       POutObj(lpMapCfg)->ImgNum = PCfgObj(ObjTree->Selected->Data)->ImgNum;
       StrCopy(POutObj(lpMapCfg)->ImgPath, PCfgObj(ObjTree->Selected->Data)->Icon1Path.c_str());
       POutObj(lpMapCfg)->IconVisible = PCfgObj(ObjTree->Selected->Data)->IconVisible;

       if( PCfgObj(ObjTree->Selected->Data)->Type > 0 ) str = PCfgObj(ObjTree->Selected->Data)->Name + " (" + StaticText1->Caption + ")";
       else str = PCfgObj(ObjTree->Selected->Data)->Name;
       StrCopy(POutObj(lpMapCfg)->ObjName, str.c_str());
       POutObj(lpMapCfg)->ImgOperationId = 1;
   }
}
void __fastcall TMainForm::ObjTreeKeyUp(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
   ObjTreeClick(this);
}
void __fastcall TMainForm::ComboBox7Change(TObject *Sender)
{
   if( ComboBox7->ItemIndex > 0 && UsePort[ComboBox7->ItemIndex] != UnUsedComPort )
   {
      MessageBox (NULL,MCFGInfoStr93.c_str(),ErrorMsg.c_str(),MB_OK|MB_ICONERROR);
      ComboBox7->ItemIndex = RastrPortNum;
   }
   else
   {
      UsePort[RastrPortNum] = UnUsedComPort;
      RastrPortNum = ComboBox7->ItemIndex;
      UsePort[RastrPortNum] = RastrComPort;

      ObjTree->Items->BeginUpdate();
      TTreeNode* tempNode;

      for( int i = 1; i < ObjTree->Items->Count; i++ )
      {
         if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 5 )
         {
            tempNode = ObjTree->Items->Item[i];
            if( ComboBox7->ItemIndex == 0 )
            {
               tempNode->SelectedIndex = 8;
               tempNode->ImageIndex = 8;
            }
            else
            {
               tempNode->SelectedIndex = 9;
               tempNode->ImageIndex = 9;
            }

         }
      }
      ObjTree->Items->EndUpdate();
   }
}
void __fastcall TMainForm::ComboBox10Change(TObject *Sender)
{
   if( ComboBox10->ItemIndex > 0 && UsePort[ComboBox10->ItemIndex] != UnUsedComPort )
   {
      MessageBox (NULL,"���� ���� ��� ������������!","������",MB_OK|MB_ICONERROR);
      ComboBox10->ItemIndex = SolidPortNum;
   }
   else
   {
      UsePort[SolidPortNum] = UnUsedComPort;
      SolidPortNum = ComboBox10->ItemIndex;
      UsePort[SolidPortNum] = SolidComPort;

      ObjTree->Items->BeginUpdate();
      TTreeNode* tempNode;

      for( int i = 1; i < ObjTree->Items->Count; i++ )
      {
         if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 6 )
         {
            tempNode = ObjTree->Items->Item[i];
            if( ComboBox10->ItemIndex == 0 )
            {
               tempNode->SelectedIndex = 8;
               tempNode->ImageIndex = 8;
            }
            else
            {
               tempNode->SelectedIndex = 9;
               tempNode->ImageIndex = 9;
            }

         }
      }
      ObjTree->Items->EndUpdate();
   }
}
void __fastcall TMainForm::ComboBox12Change(TObject *Sender)
{
   if( ComboBox12->ItemIndex > 0 && UsePort[ComboBox12->ItemIndex] != UnUsedComPort)
   {
      MessageBox (NULL,"���� ���� ��� ������������!","������",MB_OK|MB_ICONERROR);
      ComboBox12->ItemIndex = Adam4068PortNum;
   }
   else
   {
      UsePort[Adam4068PortNum] = UnUsedComPort;
      Adam4068PortNum = ComboBox12->ItemIndex;
      UsePort[Adam4068PortNum] = AdamComPort;

      ObjTree->Items->BeginUpdate();
      TTreeNode* tempNode;

      for( int i = 1; i < ObjTree->Items->Count; i++ )
      {
         if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 7 )
         {
            tempNode = ObjTree->Items->Item[i];
            if( ComboBox12->ItemIndex == 0 )
            {
               tempNode->SelectedIndex = 6;
               tempNode->ImageIndex = 6;
            }
            else
            {
               tempNode->SelectedIndex = 7;
               tempNode->ImageIndex = 7;
            }

         }
      }
      ObjTree->Items->EndUpdate();
   }
}
void __fastcall TMainForm::PopupMenu1Popup(TObject *Sender)
{
   ObjTreeClick(this);

   if( ObjTree->Selected->AbsoluteIndex == 0 )
   {
      N2->Visible = true;
      N4->Visible = true;
      N6->Visible = true;
   }
   else
   {
      N2->Visible = false;
      N4->Visible = false;
      N6->Visible = false;
   }

   Razriv11_pdi->Visible = false;
   Razriv12_pdi->Visible = false;
   Razriv21_pdi->Visible = false;
   Razriv22_pdi->Visible = false;
   Adam4068AutoOff_pdi->Visible = false;
   Metka_pdi->Caption = "������� ��������";
   Metka_pdi->Visible = false;
   AlarmMsgOn_pdi->Visible = false;
   ConnectBlock_pdi->Visible = false;

   if( PCfgObj(ObjTree->Selected->Data)->Type == 3 && ComplexVersion != Rastr_M_SsoiComplexType || PCfgObj(ObjTree->Selected->Data)->Type == 33 )
   {
      IconVisible_pdi->Visible = true;
      N5->Visible = IconVisible_pdi->Visible;
      Bazalt_pdi->Checked = PCfgObj(ObjTree->Selected->Data)->Bazalt;
      AlarmMsgOn_pdi->Checked = PCfgObj(ObjTree->Selected->Data)->AlarmMsgOn;
      AlarmMsgOn_pdi->Visible = true;

      if( PCfgObj(ObjTree->Selected->Data)->Type == 3 )
      {
         switch( PCfgObj(ObjTree->Selected->Data)->Num3 )
         {
            case 1: Razriv11_pdi->Visible = true;
                    Razriv11_pdi->Checked = PCfgObj(ObjTree->Selected->Data)->Razriv;
                    break;
            case 2: Razriv12_pdi->Visible = true;
                    Razriv12_pdi->Checked = PCfgObj(ObjTree->Selected->Data)->Razriv;
                    break;
            case 3: Razriv21_pdi->Visible = true;
                    Razriv21_pdi->Checked = PCfgObj(ObjTree->Selected->Data)->Razriv;
                    break;
            case 4: Razriv22_pdi->Visible = true;
                    Razriv22_pdi->Checked = PCfgObj(ObjTree->Selected->Data)->Razriv;
                    break;
         }
      }

      if( PCfgObj(ObjTree->Selected->Data)->Num3 < 4 )
      {
         Bazalt_pdi->Checked = PCfgObj(ObjTree->Selected->Data)->Bazalt;
         Bazalt_pdi->Visible = true;
      }
      else Bazalt_pdi->Visible = false;

      if( PCfgObj(ObjTree->Selected->Data)->Num3 >= 4 && PCfgObj(ObjTree->Selected->Data)->Num3 < 7 )
      {
         ConnectBlock_pdi->Checked = PCfgObj(ObjTree->Selected->Data)->ConnectBlock;
         ConnectBlock_pdi->Visible = true;
      }

      if( PCfgObj(ObjTree->Selected->Data)->Bazalt )
      {
         PCfgObj(ObjTree->Selected->Data)->Dk = false;
         Dk_pdi->Checked = PCfgObj(ObjTree->Selected->Data)->Dk;
         Dk_pdi->Visible = false;
         PCfgObj(ObjTree->Selected->Data)->Metka = false;
      }
      else if( PCfgObj(ObjTree->Selected->Data)->ConnectBlock )
      {
         PCfgObj(ObjTree->Selected->Data)->Dk = false;
         Dk_pdi->Checked = PCfgObj(ObjTree->Selected->Data)->Dk;
         Dk_pdi->Visible = false;
         PCfgObj(ObjTree->Selected->Data)->Metka = false;
         Razriv11_pdi->Visible = false;
         Razriv11_pdi->Checked = false;
         Razriv12_pdi->Visible = false;
         Razriv12_pdi->Checked = false;
         Razriv21_pdi->Visible = false;
         Razriv21_pdi->Checked = false;
         Razriv22_pdi->Visible = false;
         Razriv22_pdi->Checked = false;
      }
      else if( PCfgObj(ObjTree->Selected->Data)->Metka )
      {
         PCfgObj(ObjTree->Selected->Data)->Bazalt = false;
         Bazalt_pdi->Checked = PCfgObj(ObjTree->Selected->Data)->Bazalt;
         Dk_pdi->Checked = PCfgObj(ObjTree->Selected->Data)->Dk;
         Dk_pdi->Visible = true;
      }
      else
      {
         if( PCfgObj(ObjTree->Selected->Data)->Num3 < 9 )
         {
            Dk_pdi->Checked = PCfgObj(ObjTree->Selected->Data)->Dk;
            Dk_pdi->Visible = true;
         }
         else
         {
            Dk_pdi->Checked = false;
            Dk_pdi->Visible = false;
         }
      }
   }
   else if( PCfgObj(ObjTree->Selected->Data)->Type == 3 && ComplexVersion == Rastr_M_SsoiComplexType )
   {
      IconVisible_pdi->Visible = true;
      N5->Visible = IconVisible_pdi->Visible;

      Dk_pdi->Checked = PCfgObj(ObjTree->Selected->Data)->Dk;
      Dk_pdi->Visible = true;

      Metka_pdi->Visible = false;
      Bazalt_pdi->Visible = false;

      if( PCfgObj(ObjTree->Selected->Data)->Num3 == 1 )
      {
         Bazalt_pdi->Checked = PCfgObj(ObjTree->Selected->Data)->Bazalt;
         Bazalt_pdi->Visible = true;
      }
      else Bazalt_pdi->Visible = false;

      if( PCfgObj(ObjTree->Selected->Data)->Bazalt )
      {
         PCfgObj(ObjTree->Selected->Data)->Dk = false;
         Dk_pdi->Checked = PCfgObj(ObjTree->Selected->Data)->Dk;
         Dk_pdi->Visible = false;
      }
   }
   else if( PCfgObj(ObjTree->Selected->Data)->Type == 4 && ComplexVersion == Rastr_M_SsoiComplexType )
   {
      IconVisible_pdi->Visible = true;
      N5->Visible = IconVisible_pdi->Visible;
      Dk_pdi->Visible = false;
      Bazalt_pdi->Visible = false;
      Metka_pdi->Visible = false;

      Adam4068AutoOff5s_pdi->Caption = "5 ���.";
      Adam4068AutoOff10s_pdi->Caption = "10 ���.";
      Adam4068AutoOff30s_pdi->Caption = "30 ���.";
      Adam4068AutoOff1m_pdi->Caption = "1 ���.";
      Adam4068AutoOff5m_pdi->Caption = "5 ���.";
      Adam4068AutoOff10m_pdi->Caption = "10 ���.";
      Adam4068AutoOff20m_pdi->Visible = true;
      Adam4068AutoOff30m_pdi->Visible = true;
      Adam4068AutoOff59m_pdi->Visible = true;

      Adam4068AutoOff0_pdi->Checked = false;
      Adam4068AutoOff5s_pdi->Checked = false;
      Adam4068AutoOff10s_pdi->Checked = false;
      Adam4068AutoOff30s_pdi->Checked = false;
      Adam4068AutoOff1m_pdi->Checked = false;
      Adam4068AutoOff5m_pdi->Checked = false;
      Adam4068AutoOff10m_pdi->Checked = false;
      Adam4068AutoOff20m_pdi->Checked = false;
      Adam4068AutoOff30m_pdi->Checked = false;
      Adam4068AutoOff59m_pdi->Checked = false;

      switch( PCfgObj(ObjTree->Selected->Data)->AdamOff )
      {
         case 0:  Adam4068AutoOff0_pdi->Checked = true;
                  break;
         case 1:  Adam4068AutoOff5s_pdi->Checked = true;
                  break;
         case 2:  Adam4068AutoOff10s_pdi->Checked = true;
                  break;
         case 3:  Adam4068AutoOff30s_pdi->Checked = true;
                  break;
         case 4:  Adam4068AutoOff1m_pdi->Checked = true;
                  break;
         case 5:  Adam4068AutoOff5m_pdi->Checked = true;
                  break;
         case 6: Adam4068AutoOff10m_pdi->Checked = true;
                  break;
         case 7: Adam4068AutoOff20m_pdi->Checked = true;
                  break;
         case 8: Adam4068AutoOff30m_pdi->Checked = true;
                  break;
         case 9: Adam4068AutoOff59m_pdi->Checked = true;
                  break;
         default:  Adam4068AutoOff0_pdi->Checked = true;
                  break;
      }

      Adam4068AutoOff_pdi->Visible = true;
   }
   else if( PCfgObj(ObjTree->Selected->Data)->Type == 4 && ComplexVersion == SsoiComplexType )
   {
      IconVisible_pdi->Visible = true;
      N5->Visible = IconVisible_pdi->Visible;
      Dk_pdi->Visible = false;
      Bazalt_pdi->Visible = false;
      Metka_pdi->Visible = false;

      Adam4068AutoOff5s_pdi->Caption = "5 ���.";
      Adam4068AutoOff10s_pdi->Caption = "10 ���.";
      Adam4068AutoOff30s_pdi->Caption = "30 ���.";
      Adam4068AutoOff1m_pdi->Caption = "1 ���.";
      Adam4068AutoOff5m_pdi->Caption = "5 ���.";
      Adam4068AutoOff10m_pdi->Caption = "10 ���.";
      Adam4068AutoOff20m_pdi->Visible = true;
      Adam4068AutoOff30m_pdi->Visible = true;
      Adam4068AutoOff59m_pdi->Visible = true;

      Adam4068AutoOff0_pdi->Checked = false;
      Adam4068AutoOff5s_pdi->Checked = false;
      Adam4068AutoOff10s_pdi->Checked = false;
      Adam4068AutoOff30s_pdi->Checked = false;
      Adam4068AutoOff1m_pdi->Checked = false;
      Adam4068AutoOff5m_pdi->Checked = false;
      Adam4068AutoOff10m_pdi->Checked = false;
      Adam4068AutoOff20m_pdi->Checked = false;
      Adam4068AutoOff30m_pdi->Checked = false;
      Adam4068AutoOff59m_pdi->Checked = false;

      switch( PCfgObj(ObjTree->Selected->Data)->AdamOff )
      {
         case 0:  Adam4068AutoOff0_pdi->Checked = true;
                  break;
         case 1:  Adam4068AutoOff5s_pdi->Checked = true;
                  break;
         case 2:  Adam4068AutoOff10s_pdi->Checked = true;
                  break;
         case 3:  Adam4068AutoOff30s_pdi->Checked = true;
                  break;
         case 4:  Adam4068AutoOff1m_pdi->Checked = true;
                  break;
         case 5:  Adam4068AutoOff5m_pdi->Checked = true;
                  break;
         case 6: Adam4068AutoOff10m_pdi->Checked = true;
                  break;
         case 7: Adam4068AutoOff20m_pdi->Checked = true;
                  break;
         case 8: Adam4068AutoOff30m_pdi->Checked = true;
                  break;
         case 9: Adam4068AutoOff59m_pdi->Checked = true;
                  break;
         default:  Adam4068AutoOff0_pdi->Checked = true;
                  break;
      }

      Adam4068AutoOff_pdi->Visible = true;
   }
   else if( PCfgObj(ObjTree->Selected->Data)->Type == 1 ||
            PCfgObj(ObjTree->Selected->Data)->Type == 2 ||
            PCfgObj(ObjTree->Selected->Data)->Type == 8 ||
            PCfgObj(ObjTree->Selected->Data)->Type == 9 ||
            PCfgObj(ObjTree->Selected->Data)->Type == 91 ||
            PCfgObj(ObjTree->Selected->Data)->Type == 21 ||
            PCfgObj(ObjTree->Selected->Data)->Type == 10 ||
            PCfgObj(ObjTree->Selected->Data)->Type == 11 ||
            PCfgObj(ObjTree->Selected->Data)->Type == 111 )
   {
      IconVisible_pdi->Visible = true;
      N5->Visible = IconVisible_pdi->Visible;
      Bazalt_pdi->Visible = false;
      Metka_pdi->Visible = false;
      if( PCfgObj(ObjTree->Selected->Data)->Type != 2 && PCfgObj(ObjTree->Selected->Data)->Type != 21 )
         Dk_pdi->Visible = false;
      else
      {
         Dk_pdi->Checked = PCfgObj(ObjTree->Selected->Data)->Dk;
         Dk_pdi->Visible = true;
      }

      if( PCfgObj(ObjTree->Selected->Data)->Type == 11 && PCfgObj(ObjTree->Selected->Data)->Num2 < 4 )
      {
         Bazalt_pdi->Checked = PCfgObj(ObjTree->Selected->Data)->Bazalt;
         Bazalt_pdi->Visible = true;
      }

      if( PCfgObj(ObjTree->Selected->Data)->Type == 1 ||
          PCfgObj(ObjTree->Selected->Data)->Type == 10 ||
          PCfgObj(ObjTree->Selected->Data)->Type == 11 ||
          PCfgObj(ObjTree->Selected->Data)->Type == 111 )
      {
         AlarmMsgOn_pdi->Checked = PCfgObj(ObjTree->Selected->Data)->AlarmMsgOn;
         AlarmMsgOn_pdi->Visible = true;
      }

      if( PCfgObj(ObjTree->Selected->Data)->Type == 11 && PCfgObj(ObjTree->Selected->Data)->Num2 < 9 )
      {
         if( !PCfgObj(ObjTree->Selected->Data)->Bazalt )
         {
            Dk_pdi->Checked = PCfgObj(ObjTree->Selected->Data)->Dk;
            Dk_pdi->Visible = true;
         }
         else
         {
            Dk_pdi->Checked = false;
            Dk_pdi->Visible = false;
         }
      }
   }
   else if( PCfgObj(ObjTree->Selected->Data)->Type == 28 ||
            PCfgObj(ObjTree->Selected->Data)->Type == 31 )
   {
      IconVisible_pdi->Visible = false;
      Dk_pdi->Visible = false;
      Bazalt_pdi->Visible = false;
      N5->Visible = false;

      AlarmMsgOn_pdi->Checked = PCfgObj(ObjTree->Selected->Data)->AlarmMsgOn;
      AlarmMsgOn_pdi->Visible = true;
   }
   else if( PCfgObj(ObjTree->Selected->Data)->Type == 7 )
   {
      IconVisible_pdi->Visible = true;
      N5->Visible = IconVisible_pdi->Visible;
      Dk_pdi->Visible = false;
      Bazalt_pdi->Visible = false;
      Metka_pdi->Visible = false;
      Adam4068AutoOff_pdi->Visible = true;

      Adam4068AutoOff5s_pdi->Caption = "5 ���.";
      Adam4068AutoOff10s_pdi->Caption = "10 ���.";
      Adam4068AutoOff30s_pdi->Caption = "30 ���.";
      Adam4068AutoOff1m_pdi->Caption = "1 ���.";
      Adam4068AutoOff5m_pdi->Caption = "5 ���.";
      Adam4068AutoOff10m_pdi->Caption = "10 ���.";
      Adam4068AutoOff20m_pdi->Visible = true;
      Adam4068AutoOff30m_pdi->Visible = true;
      Adam4068AutoOff59m_pdi->Visible = true;

      Adam4068AutoOff0_pdi->Checked = false;
      Adam4068AutoOff5s_pdi->Checked = false;
      Adam4068AutoOff10s_pdi->Checked = false;
      Adam4068AutoOff30s_pdi->Checked = false;
      Adam4068AutoOff1m_pdi->Checked = false;
      Adam4068AutoOff5m_pdi->Checked = false;
      Adam4068AutoOff10m_pdi->Checked = false;
      Adam4068AutoOff20m_pdi->Checked = false;
      Adam4068AutoOff30m_pdi->Checked = false;
      Adam4068AutoOff59m_pdi->Checked = false;
      switch( PCfgObj(ObjTree->Selected->Data)->AdamOff )
      {
         case 0:  Adam4068AutoOff0_pdi->Checked = true;
                  break;
         case 1:  Adam4068AutoOff5s_pdi->Checked = true;
                  break;
         case 2:  Adam4068AutoOff10s_pdi->Checked = true;
                  break;
         case 3:  Adam4068AutoOff30s_pdi->Checked = true;
                  break;
         case 4:  Adam4068AutoOff1m_pdi->Checked = true;
                  break;
         case 5:  Adam4068AutoOff5m_pdi->Checked = true;
                  break;
         case 6: Adam4068AutoOff10m_pdi->Checked = true;
                  break;
         case 7: Adam4068AutoOff20m_pdi->Checked = true;
                  break;
         case 8: Adam4068AutoOff30m_pdi->Checked = true;
                  break;
         case 9: Adam4068AutoOff59m_pdi->Checked = true;
                  break;
         default:  Adam4068AutoOff0_pdi->Checked = true;
                  break;
      }
   }
   else if( PCfgObj(ObjTree->Selected->Data)->Type == 12 )
   {
      IconVisible_pdi->Visible = true;
      N5->Visible = IconVisible_pdi->Visible;
      Dk_pdi->Visible = false;
      Bazalt_pdi->Visible = false;
      Metka_pdi->Visible = false;

      Adam4068AutoOff5s_pdi->Caption = "5 ���.";
      Adam4068AutoOff10s_pdi->Caption = "10 ���.";
      Adam4068AutoOff30s_pdi->Caption = "30 ���.";
      Adam4068AutoOff1m_pdi->Caption = "1 ���.";
      Adam4068AutoOff5m_pdi->Caption = "5 ���.";
      Adam4068AutoOff10m_pdi->Caption = "10 ���.";
      Adam4068AutoOff20m_pdi->Visible = true;
      Adam4068AutoOff30m_pdi->Visible = true;
      Adam4068AutoOff59m_pdi->Visible = true;

      Adam4068AutoOff_pdi->Visible = true;

      Adam4068AutoOff0_pdi->Checked = false;
      Adam4068AutoOff5s_pdi->Checked = false;
      Adam4068AutoOff10s_pdi->Checked = false;
      Adam4068AutoOff30s_pdi->Checked = false;
      Adam4068AutoOff1m_pdi->Checked = false;
      Adam4068AutoOff5m_pdi->Checked = false;
      Adam4068AutoOff10m_pdi->Checked = false;
      Adam4068AutoOff20m_pdi->Checked = false;
      Adam4068AutoOff30m_pdi->Checked = false;
      Adam4068AutoOff59m_pdi->Checked = false;
      switch( PCfgObj(ObjTree->Selected->Data)->AdamOff )
      {
         case 0:  Adam4068AutoOff0_pdi->Checked = true;
                  break;
         case 1:  Adam4068AutoOff5s_pdi->Checked = true;
                  break;
         case 2:  Adam4068AutoOff10s_pdi->Checked = true;
                  break;
         case 3:  Adam4068AutoOff30s_pdi->Checked = true;
                  break;
         case 4:  Adam4068AutoOff1m_pdi->Checked = true;
                  break;
         case 5:  Adam4068AutoOff5m_pdi->Checked = true;
                  break;
         case 6: Adam4068AutoOff10m_pdi->Checked = true;
                  break;
         case 7: Adam4068AutoOff20m_pdi->Checked = true;
                  break;
         case 8: Adam4068AutoOff30m_pdi->Checked = true;
                  break;
         case 9: Adam4068AutoOff59m_pdi->Checked = true;
                  break;
         default:  Adam4068AutoOff0_pdi->Checked = true;
                  break;
      }
   }
   else if( PCfgObj(ObjTree->Selected->Data)->Type == 14 ||
            PCfgObj(ObjTree->Selected->Data)->Type == 15 ||
            PCfgObj(ObjTree->Selected->Data)->Type == 16 ||
            PCfgObj(ObjTree->Selected->Data)->Type == 17 )
   {
      IconVisible_pdi->Visible = true;
      N5->Visible = IconVisible_pdi->Visible;
      Dk_pdi->Visible = false;
      Bazalt_pdi->Visible = false;
      Metka_pdi->Visible = false;
   }
   else if( PCfgObj(ObjTree->Selected->Data)->Type == 42 )
   {
      IconVisible_pdi->Visible = true;
      N5->Visible = IconVisible_pdi->Visible;
      Dk_pdi->Visible = false;
      Bazalt_pdi->Visible = false;
      Metka_pdi->Visible = false;

      Adam4068AutoOff5s_pdi->Caption = "1 ���";
      Adam4068AutoOff10s_pdi->Caption = "2 ����";
      Adam4068AutoOff30s_pdi->Caption = "3 ����";
      Adam4068AutoOff1m_pdi->Caption = "4 ����";
      Adam4068AutoOff5m_pdi->Caption = "5 �����";
      Adam4068AutoOff10m_pdi->Caption = "6 �����";
      Adam4068AutoOff20m_pdi->Caption = "7 �����";
      Adam4068AutoOff30m_pdi->Caption = "8 �����";
      Adam4068AutoOff59m_pdi->Visible = false;
      Adam4068AutoOff_pdi->Visible = true;

      Adam4068AutoOff0_pdi->Checked = false;
      Adam4068AutoOff5s_pdi->Checked = false;
      Adam4068AutoOff10s_pdi->Checked = false;
      Adam4068AutoOff30s_pdi->Checked = false;
      Adam4068AutoOff1m_pdi->Checked = false;
      Adam4068AutoOff5m_pdi->Checked = false;
      Adam4068AutoOff10m_pdi->Checked = false;
      Adam4068AutoOff20m_pdi->Checked = false;
      Adam4068AutoOff30m_pdi->Checked = false;
      Adam4068AutoOff59m_pdi->Checked = false;
      switch( PCfgObj(ObjTree->Selected->Data)->AdamOff )
      {
         case 0:  Adam4068AutoOff0_pdi->Checked = true;
                  break;
         case 1:  Adam4068AutoOff5s_pdi->Checked = true;
                  break;
         case 2:  Adam4068AutoOff10s_pdi->Checked = true;
                  break;
         case 3:  Adam4068AutoOff30s_pdi->Checked = true;
                  break;
         case 4:  Adam4068AutoOff1m_pdi->Checked = true;
                  break;
         case 5:  Adam4068AutoOff5m_pdi->Checked = true;
                  break;
         case 6: Adam4068AutoOff10m_pdi->Checked = true;
                  break;
         case 7: Adam4068AutoOff20m_pdi->Checked = true;
                  break;
         case 8: Adam4068AutoOff30m_pdi->Checked = true;
                  break;
         case 9: Adam4068AutoOff59m_pdi->Checked = true;
                  break;
         default:  Adam4068AutoOff0_pdi->Checked = true;
                  break;
      }
   }
   else
   {
      IconVisible_pdi->Visible = false;
      N5->Visible = IconVisible_pdi->Visible;
      if( PCfgObj(ObjTree->Selected->Data)->Type == 4 ||
          PCfgObj(ObjTree->Selected->Data)->Type == 41 ||
          PCfgObj(ObjTree->Selected->Data)->Type == 42 ||
          PCfgObj(ObjTree->Selected->Data)->Type == 51 ||
          PCfgObj(ObjTree->Selected->Data)->Type == 5 ||
          PCfgObj(ObjTree->Selected->Data)->Type == 6 ||
          PCfgObj(ObjTree->Selected->Data)->Type == 26 ||
          PCfgObj(ObjTree->Selected->Data)->Type == 27 ||
          PCfgObj(ObjTree->Selected->Data)->Type == 29 ||
          PCfgObj(ObjTree->Selected->Data)->Type == 30 ) IconVisible_pdi->Visible = true;
      N5->Visible = IconVisible_pdi->Visible;
      Dk_pdi->Visible = false;
      Bazalt_pdi->Visible = false;
      Metka_pdi->Visible = false;
   }
}
void __fastcall TMainForm::IconVisible_pdiClick(TObject *Sender)
{
   IconDlg = new TIconDlg(this);
   IconDlg->ShowModal();
   delete IconDlg;

   ObjTreeClick(this);
}
void __fastcall TMainForm::SpeedButton7Click(TObject *Sender)
{
   
   if( OpenPictureDialog2->Execute() )
   {
      if ( FileExists(OpenPictureDialog2->FileName) )
      {
         Edit3->Text = OpenPictureDialog2->FileName;
         StrCopy(POutObj(lpMapCfg)->PlanPath, Edit3->Text.c_str() );
      }
   }
}
void __fastcall TMainForm::SpeedButton8Click(TObject *Sender)
{
   
   Edit3->Text = "";
   StrCopy(POutObj(lpMapCfg)->PlanPath, Edit3->Text.c_str() );
}
void __fastcall TMainForm::CfgTimerTimer(TObject *Sender)
{
   if( POutObj(lpMapPlan)->ImgOperationId == POutObj(lpMapCfg)->ImgOperationId )
      POutObj(lpMapCfg)->ImgOperationId = 0;
   else
   {
      if( (POutObj(lpMapPlan)->ImgOperationId == 4 || POutObj(lpMapPlan)->ImgOperationId == 5) &&
           POutObj(lpMapPlan)->ImgOperationId != POutObj(lpMapCfg)->ImgOperationId ) 
      {
         
         int type = 0, num1 = 0, num2 = 0, num3 = 0;
         AnsiString str, str1, str2;
         str = POutObj(lpMapPlan)->ImgName;
         sscanf(str.c_str(),"img_%d_%d_%d_%d", &type, &num1, &num2, &num3);
         if( type == 44 && ComboBox20->ItemIndex == 0  ) { type = 4, num3 +=3; }
         if( type == 33 && ComboBox20->ItemIndex == 0  ) type = 3;
         if( type == 43 && ComboBox20->ItemIndex == 0  ) type = 4;

         if( type > 0 )
         {
             ObjTree->Items->BeginUpdate();
             for( int i = 0; i < ObjTree->Items->Count; i++ )
             {
                if( type == PCfgObj(ObjTree->Items->Item[i]->Data)->Type &&
                    num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
                    num2 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num2 &&
                    num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 )
                {
                   MainForm->SetFocus();
                   ObjTree->TabStop = true;

                   ObjTree->SetFocus();
                   ObjTree->Items->Item[i]->Selected = true;
                   ObjTree->Items->Item[i]->MakeVisible();

                   ObjTreeClick(this);


                   if( POutObj(lpMapPlan)->ImgOperationId == 5 )
                   {
                      PCfgObj(ObjTree->Selected->Data)->X = POutObj(lpMapPlan)->ImgLeft;
                      PCfgObj(ObjTree->Selected->Data)->Y = POutObj(lpMapPlan)->ImgTop;
                   }

                   break;
                }
            }
            ObjTree->Items->EndUpdate();
         }



         POutObj(lpMapCfg)->ImgOperationId = 6;
      }
   }

   TPoint pt;
   GetCursorPos(&pt);
   if( Edit19->Visible && Edit20->Visible )
   {
      Edit19->Text = pt.x;
      Edit20->Text = pt.y;
   }
}
void __fastcall TMainForm::Dk_pdiClick(TObject *Sender)
{
   Dk_pdi->Checked = !Dk_pdi->Checked;
   PCfgObj(ObjTree->Selected->Data)->Dk = Dk_pdi->Checked;
}
void __fastcall TMainForm::BitBtn7Click(TObject *Sender)
{
   WORD wVersionRequested;
   WSADATA WSAData;
   wVersionRequested = MAKEWORD(1,1);

   if( WSAStartup(wVersionRequested, &WSAData) )
      MessageBox (NULL,MCFGInfoStr96.c_str(),ErrorMsg.c_str(),MB_OK|MB_ICONERROR);
   else
   {
      hostent *P;
      char s[128];
      in_addr in;
      char *P2;
      gethostname(s,128);
      P=gethostbyname(s);
      Edit6->Text = P->h_name;

   }
   WSACleanup();
}
void __fastcall TMainForm::Bazalt_pdiClick(TObject *Sender)
{
   Bazalt_pdi->Checked = !Bazalt_pdi->Checked;
   PCfgObj(ObjTree->Selected->Data)->Bazalt = Bazalt_pdi->Checked;

   Metka_pdi->Checked = false;
   PCfgObj(ObjTree->Selected->Data)->Metka = Metka_pdi->Checked;

   if( PCfgObj(ObjTree->Selected->Data)->Bazalt )
   {
      PCfgObj(ObjTree->Selected->Data)->Dk = false;
      Dk_pdi->Checked = PCfgObj(ObjTree->Selected->Data)->Dk;
      Dk_pdi->Visible = false;

      switch( PCfgObj(ObjTree->Selected->Data)->Num3 )
      {
         case 1: Razriv11_pdi->Visible = false;
                 Razriv11_pdi->Checked = PCfgObj(ObjTree->Selected->Data)->Razriv;
                 break;
         case 2: Razriv12_pdi->Visible = false;
                 Razriv12_pdi->Checked = PCfgObj(ObjTree->Selected->Data)->Razriv;
                 break;
         case 3: Razriv21_pdi->Visible = false;
                 Razriv21_pdi->Checked = PCfgObj(ObjTree->Selected->Data)->Razriv;
                 break;
         case 4: Razriv22_pdi->Visible = false;
                 Razriv22_pdi->Checked = PCfgObj(ObjTree->Selected->Data)->Razriv;
                 break;
      }
   }

   int type = PCfgObj(ObjTree->Selected->Data)->Type;
   int num1 = PCfgObj(ObjTree->Selected->Data)->Num1;
   int num2 = PCfgObj(ObjTree->Selected->Data)->Num2;
   int num3 = PCfgObj(ObjTree->Selected->Data)->Num3+3;

   if( Bazalt_pdi->Checked )
      PCfgObj(ObjTree->Selected->Data)->ImgNum = 49;
   else
   {
      if( type == 3 ) PCfgObj(ObjTree->Selected->Data)->ImgNum = 0;
      if( type == 11 ) PCfgObj(ObjTree->Selected->Data)->ImgNum = 10;
   }

   ObjTree->Items->BeginUpdate();
   for( int i = 0; i < ObjTree->Items->Count; i++ )
   {
      if( type == PCfgObj(ObjTree->Items->Item[i]->Data)->Type &&
          num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
          num2 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num2 &&
          num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 )
      {
         if( PCfgObj(ObjTree->Selected->Data)->Bazalt )
            PCfgObj(ObjTree->Items->Item[i]->Data)->ConnectBlock = false;
      }
   }
   ObjTree->Items->EndUpdate();

   ObjTreeClick(this);
}
void __fastcall TMainForm::BitBtn11Click(TObject *Sender)
{
   WORD wVersionRequested;
   WSADATA WSAData;
   wVersionRequested = MAKEWORD(1,1);

   if( WSAStartup(wVersionRequested, &WSAData) )
      MessageBox (NULL,MCFGInfoStr96.c_str(),ErrorMsg.c_str(),MB_OK|MB_ICONERROR);
   else
   {
      hostent *P;
      char s[128];
      in_addr in;
      char *P2;
      gethostname(s,128);
      P=gethostbyname(s);
      Edit7->Text = P->h_name;

   }
   WSACleanup();
}
void __fastcall TMainForm::ComboBox15Change(TObject *Sender)
{
   if( ComboBox15->ItemIndex == 1 || (ComboBox15->ItemIndex == 2  && ComplexVersion == Rastr_M_TvComplexType) || (ComboBox15->ItemIndex == 3  && ComplexVersion == Rastr_M_TvComplexType) )
   {
       AnsiString fn = ExtractFilePath(Application->ExeName) + "rastrmtv_cfg.ini";
       if( FileExists(fn) )
       {
          for( int i = 0; i < 4; i++ )
          {
             RastrmtvDevSn[i] = "";
             RastrmtvDevName[i] = "";
          }

          TMemIniFile *ini;
          ini = new TMemIniFile( OpenDialog2->FileName );

          AnsiString str1, str2, str3;
          int k = 0;
          for( int i = 0; i < 4; i++ )
          {
             str1.sprintf("DEVICE_%d",i);
             str2 = ini->ReadString( str1.c_str(), "Name", "" );
             str3 = ini->ReadString( str1.c_str(), "SerNum", "" );
             if( str3 != "" )
             {
                RastrmtvDevName[k] = str2;
                RastrmtvDevSn[k] = str3;
                k += 1;
             }
          }
          delete ini;

          ComboBox1->Items->Clear();
          if( RastrmtvDevSn[0] == "" ) ComboBox1->Items->Add("�� ����������");
          else
          {
             AnsiString str;
             for( int i = 0; i < 4; i++ )
                if( RastrmtvDevSn[i] != "" )
                {
                   str.sprintf("%d-%s(%s)", i+1, RastrmtvDevName[i], RastrmtvDevSn[i]);
                   ComboBox1->Items->Add(str);
                }
          }
          ComboBox1->ItemIndex = 0;
       }
       else
       {
          ComboBox15->ItemIndex = 0;
          MessageBox (NULL,MCFGInfoStr97.c_str(),ErrorMsg.c_str(),MB_OK|MB_ICONERROR);
       }
   }

   ObjTree->Items->BeginUpdate();
   TTreeNode* tempNode;

   for( int i = 1; i < ObjTree->Items->Count; i++ )
   {
         if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 51 ||
             PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 52 )
         {
            tempNode = ObjTree->Items->Item[i];
            if( ComboBox15->ItemIndex == 0 )
            {
               tempNode->SelectedIndex = 8;
               tempNode->ImageIndex = 8;
            }
            else
            {
               tempNode->SelectedIndex = 9;
               tempNode->ImageIndex = 9;
            }
         }
   }
   ObjTree->Items->EndUpdate();
}
void __fastcall TMainForm::Metka_pdiClick(TObject *Sender)
{
   Metka_pdi->Checked = !Metka_pdi->Checked;
   PCfgObj(ObjTree->Selected->Data)->Metka = Metka_pdi->Checked;

   if( PCfgObj(ObjTree->Selected->Data)->Type != 10 )
   {
      Bazalt_pdi->Checked = false;
      PCfgObj(ObjTree->Selected->Data)->Bazalt = false;
   }
}
void __fastcall TMainForm::ComboBox16Click(TObject *Sender)
{
   
   ShowObjGroupBox();
}
void __fastcall TMainForm::Razriv11_pdiClick(TObject *Sender)
{
   Razriv11_pdi->Checked = !Razriv11_pdi->Checked;
   PCfgObj(ObjTree->Selected->Data)->Razriv = Razriv11_pdi->Checked;

   Bazalt_pdi->Checked = false;
   PCfgObj(ObjTree->Selected->Data)->Bazalt = Bazalt_pdi->Checked;

   Metka_pdi->Checked = false;
   PCfgObj(ObjTree->Selected->Data)->Metka = Metka_pdi->Checked;
}
void __fastcall TMainForm::Razriv12_pdiClick(TObject *Sender)
{
   Razriv12_pdi->Checked = !Razriv12_pdi->Checked;
   PCfgObj(ObjTree->Selected->Data)->Razriv = Razriv12_pdi->Checked;

   Bazalt_pdi->Checked = false;
   PCfgObj(ObjTree->Selected->Data)->Bazalt = Bazalt_pdi->Checked;

   Metka_pdi->Checked = false;
   PCfgObj(ObjTree->Selected->Data)->Metka = Metka_pdi->Checked;
}
void __fastcall TMainForm::Razriv21_pdiClick(TObject *Sender)
{
   Razriv21_pdi->Checked = !Razriv21_pdi->Checked;
   PCfgObj(ObjTree->Selected->Data)->Razriv = Razriv21_pdi->Checked;

   Bazalt_pdi->Checked = false;
   PCfgObj(ObjTree->Selected->Data)->Bazalt = Bazalt_pdi->Checked;

   Metka_pdi->Checked = false;
   PCfgObj(ObjTree->Selected->Data)->Metka = Metka_pdi->Checked;
}
void __fastcall TMainForm::Razriv22_pdiClick(TObject *Sender)
{
   Razriv22_pdi->Checked = !Razriv22_pdi->Checked;
   PCfgObj(ObjTree->Selected->Data)->Razriv = Razriv22_pdi->Checked;

   Bazalt_pdi->Checked = false;
   PCfgObj(ObjTree->Selected->Data)->Bazalt = Bazalt_pdi->Checked;

   Metka_pdi->Checked = false;
   PCfgObj(ObjTree->Selected->Data)->Metka = Metka_pdi->Checked;
}
void __fastcall TMainForm::Adam4068AutoOff0_pdiClick(TObject *Sender)
{
   PCfgObj(ObjTree->Selected->Data)->AdamOff = 0;

   int type = PCfgObj(ObjTree->Selected->Data)->Type;
   int num1 = PCfgObj(ObjTree->Selected->Data)->Num1;
   int num2 = PCfgObj(ObjTree->Selected->Data)->Num2;
   int num3 = PCfgObj(ObjTree->Selected->Data)->Num3;

   ObjTree->Items->BeginUpdate();
   for( int i = 0; i < ObjTree->Items->Count; i++ )
   {
      if( type == PCfgObj(ObjTree->Items->Item[i]->Data)->Type &&
          num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
          num2 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num2 &&
          num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 )
      {
         PCfgObj(ObjTree->Items->Item[i]->Data)->AdamOff = PCfgObj(ObjTree->Selected->Data)->AdamOff;
      }
   }
   ObjTree->Items->EndUpdate();
}
void __fastcall TMainForm::Adam4068AutoOff1m_pdiClick(TObject *Sender)
{
   PCfgObj(ObjTree->Selected->Data)->AdamOff = 4;

   int type = PCfgObj(ObjTree->Selected->Data)->Type;
   int num1 = PCfgObj(ObjTree->Selected->Data)->Num1;
   int num2 = PCfgObj(ObjTree->Selected->Data)->Num2;
   int num3 = PCfgObj(ObjTree->Selected->Data)->Num3;

   ObjTree->Items->BeginUpdate();
   for( int i = 0; i < ObjTree->Items->Count; i++ )
   {
      if( type == PCfgObj(ObjTree->Items->Item[i]->Data)->Type &&
          num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
          num2 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num2 &&
          num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 )
      {
         PCfgObj(ObjTree->Items->Item[i]->Data)->AdamOff = PCfgObj(ObjTree->Selected->Data)->AdamOff;
      }
   }
   ObjTree->Items->EndUpdate();
}
void __fastcall TMainForm::Adam4068AutoOff5m_pdiClick(TObject *Sender)
{
   PCfgObj(ObjTree->Selected->Data)->AdamOff = 5;

   int type = PCfgObj(ObjTree->Selected->Data)->Type;
   int num1 = PCfgObj(ObjTree->Selected->Data)->Num1;
   int num2 = PCfgObj(ObjTree->Selected->Data)->Num2;
   int num3 = PCfgObj(ObjTree->Selected->Data)->Num3;

   ObjTree->Items->BeginUpdate();
   for( int i = 0; i < ObjTree->Items->Count; i++ )
   {
      if( type == PCfgObj(ObjTree->Items->Item[i]->Data)->Type &&
          num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
          num2 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num2 &&
          num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 )
      {
         PCfgObj(ObjTree->Items->Item[i]->Data)->AdamOff = PCfgObj(ObjTree->Selected->Data)->AdamOff;
      }
   }
   ObjTree->Items->EndUpdate();
}
void __fastcall TMainForm::Adam4068AutoOff10m_pdiClick(TObject *Sender)
{
   PCfgObj(ObjTree->Selected->Data)->AdamOff = 6;

   int type = PCfgObj(ObjTree->Selected->Data)->Type;
   int num1 = PCfgObj(ObjTree->Selected->Data)->Num1;
   int num2 = PCfgObj(ObjTree->Selected->Data)->Num2;
   int num3 = PCfgObj(ObjTree->Selected->Data)->Num3;

   ObjTree->Items->BeginUpdate();
   for( int i = 0; i < ObjTree->Items->Count; i++ )
   {
      if( type == PCfgObj(ObjTree->Items->Item[i]->Data)->Type &&
          num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
          num2 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num2 &&
          num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 )
      {
         PCfgObj(ObjTree->Items->Item[i]->Data)->AdamOff = PCfgObj(ObjTree->Selected->Data)->AdamOff;
      }
   }
   ObjTree->Items->EndUpdate();
}
void __fastcall TMainForm::Adam4068AutoOff20m_pdiClick(TObject *Sender)
{
   PCfgObj(ObjTree->Selected->Data)->AdamOff = 7;

   int type = PCfgObj(ObjTree->Selected->Data)->Type;
   int num1 = PCfgObj(ObjTree->Selected->Data)->Num1;
   int num2 = PCfgObj(ObjTree->Selected->Data)->Num2;
   int num3 = PCfgObj(ObjTree->Selected->Data)->Num3;

   ObjTree->Items->BeginUpdate();
   for( int i = 0; i < ObjTree->Items->Count; i++ )
   {
      if( type == PCfgObj(ObjTree->Items->Item[i]->Data)->Type &&
          num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
          num2 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num2 &&
          num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 )
      {
         PCfgObj(ObjTree->Items->Item[i]->Data)->AdamOff = PCfgObj(ObjTree->Selected->Data)->AdamOff;
      }
   }
   ObjTree->Items->EndUpdate();
}
void __fastcall TMainForm::Adam4068AutoOff30m_pdiClick(TObject *Sender)
{
   PCfgObj(ObjTree->Selected->Data)->AdamOff = 8;

   int type = PCfgObj(ObjTree->Selected->Data)->Type;
   int num1 = PCfgObj(ObjTree->Selected->Data)->Num1;
   int num2 = PCfgObj(ObjTree->Selected->Data)->Num2;
   int num3 = PCfgObj(ObjTree->Selected->Data)->Num3;

   ObjTree->Items->BeginUpdate();
   for( int i = 0; i < ObjTree->Items->Count; i++ )
   {
      if( type == PCfgObj(ObjTree->Items->Item[i]->Data)->Type &&
          num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
          num2 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num2 &&
          num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 )
      {
         PCfgObj(ObjTree->Items->Item[i]->Data)->AdamOff = PCfgObj(ObjTree->Selected->Data)->AdamOff;
      }
   }
   ObjTree->Items->EndUpdate();
}
void __fastcall TMainForm::Adam4068AutoOff59m_pdiClick(TObject *Sender)
{
   PCfgObj(ObjTree->Selected->Data)->AdamOff = 9;

   int type = PCfgObj(ObjTree->Selected->Data)->Type;
   int num1 = PCfgObj(ObjTree->Selected->Data)->Num1;
   int num2 = PCfgObj(ObjTree->Selected->Data)->Num2;
   int num3 = PCfgObj(ObjTree->Selected->Data)->Num3;

   ObjTree->Items->BeginUpdate();
   for( int i = 0; i < ObjTree->Items->Count; i++ )
   {
      if( type == PCfgObj(ObjTree->Items->Item[i]->Data)->Type &&
          num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
          num2 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num2 &&
          num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 )
      {
         PCfgObj(ObjTree->Items->Item[i]->Data)->AdamOff = PCfgObj(ObjTree->Selected->Data)->AdamOff;
      }
   }
   ObjTree->Items->EndUpdate();
}
void __fastcall TMainForm::Adam4068AutoOff5s_pdiClick(TObject *Sender)
{
   PCfgObj(ObjTree->Selected->Data)->AdamOff = 1;

   int type = PCfgObj(ObjTree->Selected->Data)->Type;
   int num1 = PCfgObj(ObjTree->Selected->Data)->Num1;
   int num2 = PCfgObj(ObjTree->Selected->Data)->Num2;
   int num3 = PCfgObj(ObjTree->Selected->Data)->Num3;

   ObjTree->Items->BeginUpdate();
   for( int i = 0; i < ObjTree->Items->Count; i++ )
   {
      if( type == PCfgObj(ObjTree->Items->Item[i]->Data)->Type &&
          num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
          num2 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num2 &&
          num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 )
      {
         PCfgObj(ObjTree->Items->Item[i]->Data)->AdamOff = PCfgObj(ObjTree->Selected->Data)->AdamOff;
      }
   }
   ObjTree->Items->EndUpdate();
}
void __fastcall TMainForm::Adam4068AutoOff10s_pdiClick(TObject *Sender)
{
   PCfgObj(ObjTree->Selected->Data)->AdamOff = 2;

   int type = PCfgObj(ObjTree->Selected->Data)->Type;
   int num1 = PCfgObj(ObjTree->Selected->Data)->Num1;
   int num2 = PCfgObj(ObjTree->Selected->Data)->Num2;
   int num3 = PCfgObj(ObjTree->Selected->Data)->Num3;

   ObjTree->Items->BeginUpdate();
   for( int i = 0; i < ObjTree->Items->Count; i++ )
   {
      if( type == PCfgObj(ObjTree->Items->Item[i]->Data)->Type &&
          num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
          num2 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num2 &&
          num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 )
      {
         PCfgObj(ObjTree->Items->Item[i]->Data)->AdamOff = PCfgObj(ObjTree->Selected->Data)->AdamOff;
      }
   }
   ObjTree->Items->EndUpdate();
}
void __fastcall TMainForm::Adam4068AutoOff30s_pdiClick(TObject *Sender)
{
   PCfgObj(ObjTree->Selected->Data)->AdamOff = 3;

   int type = PCfgObj(ObjTree->Selected->Data)->Type;
   int num1 = PCfgObj(ObjTree->Selected->Data)->Num1;
   int num2 = PCfgObj(ObjTree->Selected->Data)->Num2;
   int num3 = PCfgObj(ObjTree->Selected->Data)->Num3;

   ObjTree->Items->BeginUpdate();
   for( int i = 0; i < ObjTree->Items->Count; i++ )
   {
      if( type == PCfgObj(ObjTree->Items->Item[i]->Data)->Type &&
          num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
          num2 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num2 &&
          num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 )
      {
         PCfgObj(ObjTree->Items->Item[i]->Data)->AdamOff = PCfgObj(ObjTree->Selected->Data)->AdamOff;
      }
   }
   ObjTree->Items->EndUpdate();
}
void __fastcall TMainForm::BitBtn12Click(TObject *Sender)
{
   WORD wVersionRequested;
   WSADATA WSAData;
   wVersionRequested = MAKEWORD(1,1);

   if( WSAStartup(wVersionRequested, &WSAData) )
      MessageBox (NULL,MCFGInfoStr96.c_str(),ErrorMsg.c_str(),MB_OK|MB_ICONERROR);
   else
   {
      hostent *P;
      char s[128];
      in_addr in;
      char *P2;
      gethostname(s,128);
      P=gethostbyname(s);
      Edit15->Text = P->h_name;

   }
   WSACleanup();
}
void __fastcall TMainForm::ComboBox20Change(TObject *Sender)
{
   GroupBox20->Caption = "";
   GroupBox21->Visible = false;
   GroupBox22->Visible = false;
   GroupBox23->Visible = false;
   Label53->Visible = false;
   CSpinEdit12->Visible = false;
   Label54->Visible = false;
   CSpinEdit13->Visible = false;

   ComboBox14->ItemIndex = SsoiM_PortNum[0];

   if( ComboBox20->ItemIndex == 0 ) 
   {
      SsoiVersion = 2;

      GroupBox20->Caption = MsgStr27 + " 1";
      Label53->Visible = true;
      CSpinEdit12->Value = SsoiM_Interval[0];
      CSpinEdit12->Visible = true;
      Label54->Visible = true;
      CSpinEdit13->Value = SsoiM_MaxErrCnt[0];
      CSpinEdit13->Visible = true;

      GroupBox21->Visible = true;
      ComboBox5->ItemIndex = SsoiM_PortNum[1];
      CSpinEdit7->Value = SsoiM_Interval[1];
      CSpinEdit7->Visible = true;
      CSpinEdit8->Value = SsoiM_MaxErrCnt[1];
      CSpinEdit8->Visible = true;

      GroupBox22->Visible = true;
      ComboBox21->ItemIndex = SsoiM_PortNum[2];
      CSpinEdit14->Value = SsoiM_Interval[2];
      CSpinEdit14->Visible = true;
      CSpinEdit15->Value = SsoiM_MaxErrCnt[2];
      CSpinEdit15->Visible = true;

      GroupBox23->Visible = true;
      ComboBox22->ItemIndex = SsoiM_PortNum[3];
      CSpinEdit16->Value = SsoiM_Interval[3];
      CSpinEdit16->Visible = true;
      CSpinEdit17->Value = SsoiM_MaxErrCnt[3];
      CSpinEdit17->Visible = true;
   }
   else 
   {
      SsoiVersion = 1;
   }

   ShowObjGroupBox();
}
void __fastcall TMainForm::ComboBox14Change(TObject *Sender)
{
   if( ComboBox14->ItemIndex > 0 && UsePort[ComboBox14->ItemIndex] != UnUsedComPort )
   {
      MessageBox (NULL,MCFGInfoStr93.c_str(),ErrorMsg.c_str(),MB_OK|MB_ICONERROR);
      ComboBox14->ItemIndex = SsoiM_PortNum[0];
   }
   else
   {
      UsePort[SsoiM_PortNum[0]] = UnUsedComPort;
      SsoiM_PortNum[0] = ComboBox14->ItemIndex;
      UsePort[SsoiM_PortNum[0]] = SsoiComPort;

      ObjTree->Items->BeginUpdate();
      TTreeNode* tempNode;

      for( int i = 1; i < ObjTree->Items->Count; i++ )
      {
         if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 3 ||
             PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 4 )
         {
            tempNode = ObjTree->Items->Item[i];

            if( SsoiM_PortNum[0] != 0 )
            {
               tempNode->SelectedIndex = 7;
               tempNode->ImageIndex = 7;
            }
            else
            {
               tempNode->SelectedIndex = 6;
               tempNode->ImageIndex = 6;
            }
         }
         else if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 41 )
         {
            tempNode = ObjTree->Items->Item[i];

            if( SsoiVersion != 2 && SsoiM_PortNum[0] != 0 )
            {
               tempNode->SelectedIndex = 8;
               tempNode->ImageIndex = 8;
            }
            else
            {
               tempNode->SelectedIndex = 9;
               tempNode->ImageIndex = 9;
            }
         }
      }
      ObjTree->Items->EndUpdate();
   }
}
void __fastcall TMainForm::ComboBox5Change(TObject *Sender)
{
   if( ComboBox5->ItemIndex > 0 && UsePort[ComboBox5->ItemIndex] != UnUsedComPort )
   {
      MessageBox (NULL,MCFGInfoStr93.c_str(),ErrorMsg.c_str(),MB_OK|MB_ICONERROR);
      ComboBox5->ItemIndex = SsoiM_PortNum[1];
   }
   else
   {
      UsePort[SsoiM_PortNum[1]] = UnUsedComPort;
      SsoiM_PortNum[1] = ComboBox5->ItemIndex;
      UsePort[SsoiM_PortNum[1]] = SsoiComPort;

      ObjTree->Items->BeginUpdate();
      TTreeNode* tempNode;

      for( int i = 1; i < ObjTree->Items->Count; i++ )
      {
         if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 3 ||
             PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 4 )
         {
            tempNode = ObjTree->Items->Item[i];

            if( SsoiM_PortNum[1] != 0 )
            {
               tempNode->SelectedIndex = 7;
               tempNode->ImageIndex = 7;
            }
            else
            {
               tempNode->SelectedIndex = 6;
               tempNode->ImageIndex = 6;
            }
         }
      }
      ObjTree->Items->EndUpdate();
   }
}
void __fastcall TMainForm::ComboBox21Change(TObject *Sender)
{
   if( ComboBox21->ItemIndex > 0 && UsePort[ComboBox21->ItemIndex] != UnUsedComPort )
   {
      MessageBox (NULL,MCFGInfoStr93.c_str(),ErrorMsg.c_str(),MB_OK|MB_ICONERROR);
      ComboBox21->ItemIndex = SsoiM_PortNum[2];
   }
   else
   {
      UsePort[SsoiM_PortNum[2]] = UnUsedComPort;
      SsoiM_PortNum[2] = ComboBox21->ItemIndex;
      UsePort[SsoiM_PortNum[2]] = SsoiComPort;

      ObjTree->Items->BeginUpdate();
      TTreeNode* tempNode;

      for( int i = 1; i < ObjTree->Items->Count; i++ )
      {
         if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 3 ||
             PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 4 )
         {
            tempNode = ObjTree->Items->Item[i];

            if( SsoiM_PortNum[2] != 0 )
            {
               tempNode->SelectedIndex = 7;
               tempNode->ImageIndex = 7;
            }
            else
            {
               tempNode->SelectedIndex = 6;
               tempNode->ImageIndex = 6;
            }
         }
      }
      ObjTree->Items->EndUpdate();
   }
}
void __fastcall TMainForm::ComboBox22Change(TObject *Sender)
{
   if( ComboBox22->ItemIndex > 0 && UsePort[ComboBox22->ItemIndex] != UnUsedComPort )
   {
      MessageBox (NULL,MCFGInfoStr93.c_str(),ErrorMsg.c_str(),MB_OK|MB_ICONERROR);
      ComboBox22->ItemIndex = SsoiM_PortNum[3];
   }
   else
   {
      UsePort[SsoiM_PortNum[3]] = UnUsedComPort;
      SsoiM_PortNum[3] = ComboBox22->ItemIndex;
      UsePort[SsoiM_PortNum[3]] = SsoiComPort;

      ObjTree->Items->BeginUpdate();
      TTreeNode* tempNode;

      for( int i = 1; i < ObjTree->Items->Count; i++ )
      {
         if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 3 ||
             PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 4 )
         {
            tempNode = ObjTree->Items->Item[i];

            if( SsoiM_PortNum[3] != 0 )
            {
               tempNode->SelectedIndex = 7;
               tempNode->ImageIndex = 7;
            }
            else
            {
               tempNode->SelectedIndex = 6;
               tempNode->ImageIndex = 6;
            }
         }
      }
      ObjTree->Items->EndUpdate();
   }
}
void __fastcall TMainForm::Button1Click(TObject *Sender)
{
   MySQLDlg = new TMySQLDlg(this);
   MySQLDlg->ShowModal();
   delete MySQLDlg;
}
void __fastcall TMainForm::ComboBox1Click(TObject *Sender)
{
   if( ComboBox16->ItemIndex == SdIpBlIdx || ComboBox16->ItemIndex == IuIpBlIdx )
   {
      AnsiString str;
      if( ComboBox1->ItemIndex == 0 )
      {
         ComboBox3->Items->Clear();
         for( int i = 0; i < MaxRifDev; i++ )
         {
            str.sprintf("%03d", i+1);
            ComboBox3->Items->Add(str);
         }
         ComboBox3->ItemIndex = 0;
      }
      else
      {
         ComboBox3->Items->Clear();
         for( int i = 0; i < 2; i++ )
         {
            str.sprintf("%d", i+1);
            ComboBox3->Items->Add(str);
         }
         ComboBox3->ItemIndex = 0;
      }
   }
}
void __fastcall TMainForm::ComboBox4Change(TObject *Sender)
{
   if( ComboBox4->ItemIndex > 0 )
   {
      if( UsePort[ComboBox4->ItemIndex] == UnUsedComPort ||
          UsePort[ComboBox4->ItemIndex] == RifComPort )
      {
         switch( RifPortSpeed[ComboBox4->ItemIndex-1] )
         {
            case   4800: ComboBox18->ItemIndex = 0; break;
            case   9600: ComboBox18->ItemIndex = 1; break;
            case  19200: ComboBox18->ItemIndex = 2; break;
            case  38400: ComboBox18->ItemIndex = 3; break;
            case  57600: ComboBox18->ItemIndex = 4; break;
            case 115200: ComboBox18->ItemIndex = 5; break;
            case 250000: ComboBox18->ItemIndex = 6; break;
            default:     ComboBox18->ItemIndex = 0; break;
         }

         CSpinEdit5->Value = RifPortInterval[ComboBox4->ItemIndex-1];

         UsePort[ComboBox4->ItemIndex] = RifComPort;
      }
      else
      {
         ComboBox4->ItemIndex = 0;
         MessageBox (NULL,MCFGInfoStr93.c_str(),ErrorMsg.c_str(),MB_OK|MB_ICONERROR);
      }
   }
}
void __fastcall TMainForm::ComboBox18Change(TObject *Sender)
{
   if( ComboBox4->ItemIndex > 0 )
   {
      switch( ComboBox18->ItemIndex )
      {
         case  0: RifPortSpeed[ComboBox4->ItemIndex-1] = 4800; break;
         case  1: RifPortSpeed[ComboBox4->ItemIndex-1] = 9600; break;
         case  2: RifPortSpeed[ComboBox4->ItemIndex-1] = 19200; break;
         case  3: RifPortSpeed[ComboBox4->ItemIndex-1] = 38400; break;
         case  4: RifPortSpeed[ComboBox4->ItemIndex-1] = 57600; break;
         case  5: RifPortSpeed[ComboBox4->ItemIndex-1] = 115200; break;
         case  6: RifPortSpeed[ComboBox4->ItemIndex-1] = 250000; break;
         default: RifPortSpeed[ComboBox4->ItemIndex-1] = 4800; break;
      }
   }
   else MessageBox (NULL,MCFGInfoStr93.c_str(),ErrorMsg.c_str(),MB_OK|MB_ICONERROR);
}
void __fastcall TMainForm::CSpinEdit5Change(TObject *Sender)
{
   if( ComboBox4->ItemIndex > 0 )
   {
      try
      {
         if( CSpinEdit5->Value > 0 && CSpinEdit5->Value < 5000)
            RifPortInterval[ComboBox4->ItemIndex-1] = CSpinEdit5->Value;
      }
      catch(...)
      {
         ;
      }
   }
   else MessageBox (NULL,"�� ������ COM-����!","������",MB_OK|MB_ICONERROR);
}
void __fastcall TMainForm::Button2Click(TObject *Sender)
{
   ComboBox19->Enabled = false;
   ComboBox19->Clear();
   
   int rez = AppError002;
   UART_STATUS status;
   AnsiString str, sn;

	DEVICE_ID_PARAMS devID[4];
	PDEVICE_ID_PARAMS pID;

   char sernum[8];

   for( int dev = 0 ; dev < 4; dev++ )
   {
      for( int i = 0; i < 8; i++ ) sernum[i] = 0;

      pID=&devID[dev];
      if( GetDeviceID(dev,pID) == AppOK )
      {
         sernum[0] = devID[dev].chDeviceSerial[0];
         sernum[1] = devID[dev].chDeviceSerial[1];
         sernum[2] = devID[dev].chDeviceSerial[2];
         sernum[3] = devID[dev].chDeviceSerial[3];
         sernum[4] = devID[dev].chDeviceSerial[4];
         sernum[5] = devID[dev].chDeviceSerial[5];
         sernum[6] = devID[dev].chDeviceSerial[6];
         sernum[7] = devID[dev].chDeviceSerial[7];

         sn.sprintf("%02X %02X %02X %02X %02X", sernum[3]&0xFF, sernum[4]&0xFF, sernum[5]&0xFF, sernum[6]&0xFF, sernum[7]&0xFF);

         ComboBox19->Items->Add(sn);
         ComboBox19->ItemIndex = 0;
         ComboBox19->Enabled = true;
      }
   }
}
BOOL OpenFolder(LPSTR szFolder, HWND hwndOwner, int nFolder, bool NewFolderButton )
{
   *szFolder=0;
   LPMALLOC IMalloc;
   if(SHGetMalloc(&IMalloc)==E_FAIL) return FALSE;
   ITEMIDLIST *piidl=NULL;
   BOOL ret=FALSE;
   if(nFolder==-1)
   {
      BROWSEINFO bi;
      bi.hwndOwner=hwndOwner;
      bi.pidlRoot=NULL;
      bi.pszDisplayName=szFolder;
      bi.lpszTitle="������� �������";
      bi.ulFlags = BIF_STATUSTEXT|BIF_BROWSEFORCOMPUTER|BIF_EDITBOX|
                   BIF_NEWDIALOGSTYLE|BIF_USENEWUI;
      if( !NewFolderButton ) bi.ulFlags |= BIF_NONEWFOLDERBUTTON;
      bi.lpfn=NULL;
      bi.lParam=0;
      bi.iImage=0;
      piidl=SHBrowseForFolder(&bi);
      if(piidl!=NULL) ret=SHGetPathFromIDList(piidl, szFolder);
   }
   else
   {
      ret=(SHGetSpecialFolderLocation(hwndOwner, nFolder, &piidl)==NOERROR);
      if(ret) ret=SHGetPathFromIDList(piidl, szFolder);
   }
   if(piidl) IMalloc->Free(piidl);
   IMalloc->Release();

   return ret;
}
void __fastcall TMainForm::Button3Click(TObject *Sender)
{
   
   char szPath[MAX_PATH];
   AnsiString destPath;

   if( OpenFolder(szPath,NULL,-1, false) )
   {
      destPath = szPath;

      if( DirectoryExists(destPath) )
      {
         Edit2->Text =  destPath;
      }
      else MessageBox(NULL, MCFGInfoStr99.c_str(),ErrorMsg.c_str(),MB_OK|MB_ICONERROR);
   }
}
void __fastcall TMainForm::AdvStringGrid1GetAlignment(TObject *Sender,
      int ARow, int ACol, TAlignment &HAlign, TVAlignment &VAlign)
{
   if( ARow == 0 ) HAlign = taCenter;
   else
   {
      if( ACol == 0 ) HAlign = taCenter;
      else HAlign = taLeftJustify;
   }
   VAlign = vtaCenter;
}
void __fastcall TMainForm::Button4Click(TObject *Sender)
{
   OpDlgMode = 1;
   OperatorDlg = new TOperatorDlg(this);
   OperatorDlg->ShowModal();
   delete OperatorDlg;
}
void __fastcall TMainForm::Button5Click(TObject *Sender)
{
   if( OpList->OpCnt == 0 )
      MessageBox (NULL,MsgStr7.c_str(),ErrorMsg.c_str(),MB_OK|MB_ICONERROR);
   else
   {
      OpDlgMode = 2;
      OperatorDlg = new TOperatorDlg(this);
      OperatorDlg->ShowModal();
      delete OperatorDlg;
   }
}
void __fastcall TMainForm::Button6Click(TObject *Sender)
{
   if( OpList->OpCnt == 0 )
      MessageBox (NULL,MsgStr7.c_str(),ErrorMsg.c_str(),MB_OK|MB_ICONERROR);
   else
   {
      OpDlgMode = 3;
      OperatorDlg = new TOperatorDlg(this);
      OperatorDlg->ShowModal();
      delete OperatorDlg;
   }
}
void __fastcall TMainForm::AdvStringGrid1GetDisplText(TObject *Sender,
      int ACol, int ARow, AnsiString &Value)
{
   if( Value == "(null)" ) Value = " ";
}
void __fastcall TMainForm::ComboBox26Change(TObject *Sender)
{
   if( ComboBox26->ItemIndex == 0 )
   {
      AdvStringGrid1->Enabled = true;
      AdvStringGrid1->Color = clWindow;
      AdvStringGrid1->ShowSelection = true;
      Button4->Enabled = true;
      Button5->Enabled = true;
      Button6->Enabled = true;
   }
   else
   {
      AdvStringGrid1->Color = clBtnFace;
      AdvStringGrid1->ShowSelection = false;
      AdvStringGrid1->Enabled = false;
      Button4->Enabled = false;
      Button5->Enabled = false;
      Button6->Enabled = false;
   }
}
bool TMainForm::LoadLangConfig( AnsiString fp )
{
   TMemIniFile *ini;
   ini = new TMemIniFile( fp );

   MainForm->Caption = ini->ReadString( "MCFG", "Caption", "��������� ���������" );

   FileItems->Caption = ini->ReadString( "MCFG", "FileItemsCaption", "����" );
   FileNewItem->Caption = ini->ReadString( "MCFG", "FileNewCaption", "�������" );
   FileOpenItem->Caption = ini->ReadString( "MCFG", "FileOpenCaption", "�������" );
   FileSaveItem->Caption = ini->ReadString( "MCFG", "FileSaveCaption", "���������" );
   ExitItem->Caption = ini->ReadString( "MAINFORM", "ExitItemCaption", "�����" );
   ToolButton1->Caption = FileNewItem->Caption;
   ToolButton2->Caption = FileOpenItem->Caption;
   ToolButton3->Caption = FileSaveItem->Caption;
   TreeGroupBox->Caption = ini->ReadString( "MAINFORM", "GroupBox1Caption", "������ ��������" );

   PlanGroupBox->Caption = ini->ReadString( "MCFG", "PlanGroupBoxCaption", "���� � ����" );
   Label27->Caption = ini->ReadString( "MCFG", "FileItemsCaption", "����" );
   SpeedButton7->Hint = ini->ReadString( "MCFG", "SpeedButton7Hint", "������� ���� �����" );
   SpeedButton8->Hint = ini->ReadString( "MCFG", "SpeedButton8Hint", "������� ���� �����" );
   Label65->Caption = ini->ReadString( "MCFG", "Label65Caption", "�������� ����. ������������" );
   ComboBox27->Items->Clear();
   ComboBox27->Items->Add(ini->ReadString( "MCFG", "MCFGInfoStr1", "�������� �����" ));
   ComboBox27->Items->Add(ini->ReadString( "MCFG", "MCFGInfoStr2", "��������� �������" ));
   ComboBox27->Items->Add(ini->ReadString( "MCFG", "MCFGInfoStr3", "��� �����" ));
   ComboBox27->ItemIndex = 0;

   ObjGroupBox->Caption = ini->ReadString( "MCFG", "ObjGroupBoxCaption", "������" );
   GroupBox2->Caption = ini->ReadString( "MCFG", "GroupBox2Caption", "���������" );
   Label36->Caption = ini->ReadString( "MCFG", "Label36Caption", "���" );

   Label1->Caption = ini->ReadString( "MCFG", "Label1Caption", "���" );
   MsgStr6 = ini->ReadString( "MSGSTRING", "MsgStr6", "������ ��������� ������ ��� ������ ������!" );
   MsgStr7 = ini->ReadString( "MSGSTRING", "MsgStr7", "� ����� ������������ ����������� ���������� �� ���������� ���������!" );
   MsgStr25 = ini->ReadString( "MSGSTRING", "MsgStr25", "�������" );
   MsgStr27 = ini->ReadString( "MSGSTRING", "MsgStr27", "�����" );
   MsgStr28 = ini->ReadString( "MSGSTRING", "MsgStr28", "��" );
   MsgStr29 = ini->ReadString( "MSGSTRING", "MsgStr29", "��" );
   MsgStr30 = ini->ReadString( "MSGSTRING", "MsgStr30", "��" );
   MsgStr31 = ini->ReadString( "MSGSTRING", "MsgStr31", "��" );
   MsgStr33 = ini->ReadString( "MSGSTRING", "MsgStr33", "��-������" );
   MsgStr34 = ini->ReadString( "MSGSTRING", "MsgStr34", "�������" );
   MsgStr35 = ini->ReadString( "MSGSTRING", "MsgStr35", "�����" );
   MsgStr36 = ini->ReadString( "MSGSTRING", "MsgStr36", "�����-�-��" );
   MsgStr37 = ini->ReadString( "MSGSTRING", "MsgStr37", "����� (������.)" );
   MsgStr38 = ini->ReadString( "MSGSTRING", "MsgStr38", "���. �����" );

   MCFGInfoStr65 = ini->ReadString( "TABLE1STRINGS", "Table1Str11", "����" );
   MCFGInfoStr66 = ini->ReadString( "TABLE1STRINGS", "Table1Str12", "���" );
   MCFGInfoStr102 = ini->ReadString( "TABLE1STRINGS", "Table1Str32", "������ �������� �����" );

   MsgStr26 = ini->ReadString( "MSGSTRING", "MsgStr26", "������" );
   if( ComplexVersion == SsoiComplexType )
   {
      ComboBox16->Items->Clear();
      ComboBox16->Items->Add(MsgStr26);
      ComboBox16->Items->Add(MsgStr29);
      ComboBox16->Items->Add(MsgStr30);
      ComboBox16->Items->Add(MsgStr33 + " " + MsgStr35);
      ComboBox16->Items->Add(MsgStr33 + " " + MsgStr36);
      ComboBox16->Items->Add(MsgStr33 + " " + MsgStr37);
      ComboBox16->Items->Add(MsgStr38);
      ComboBox16->ItemIndex = 0;
   }

   BitBtn1->Caption = ini->ReadString( "MCFG", "BitBtn1Caption", "��������" );
   BitBtn2->Caption = ini->ReadString( "MCFG", "BitBtn2Caption", "�������" );
   BitBtn3->Caption = ini->ReadString( "MCFG", "BitBtn3Caption", "�����" );
   BitBtn10->Caption = ini->ReadString( "MCFG", "BitBtn10Caption", "�������������" );
   BitBtn4->Caption = ini->ReadString( "MCFG", "BitBtn4Caption", "�����" );
   BitBtn5->Caption = ini->ReadString( "MCFG", "BitBtn5Caption", "����" );

   GroupBox5->Caption = ini->ReadString( "MCFG", "GroupBox2Caption", "���������" );
   GroupBox24->Caption = ini->ReadString( "MCFG", "GroupBox24Caption", "������ ����������" );
   Label48->Caption = ini->ReadString( "MCFG", "Label48Caption", "�����" );
   ComboBox26->Items->Clear();
   ComboBox26->Items->Add(ini->ReadString( "MCFG", "MCFGInfoStr17", "� �����������" ));
   ComboBox26->Items->Add(ini->ReadString( "MCFG", "MCFGInfoStr18", "��� ����������" ));
   ComboBox26->ItemIndex = 1;
   AdvStringGrid1->RowCount = 2;
   AdvStringGrid1->Cells[0][0] = "N";
   AdvStringGrid1->Cells[1][0] = ini->ReadString( "MCFG", "MCFGInfoStr19", "�������" );
   AdvStringGrid1->Cells[2][0] = ini->ReadString( "MCFG", "MCFGInfoStr20", "���" );
   AdvStringGrid1->Cells[3][0] = ini->ReadString( "MCFG", "MCFGInfoStr21", "��������" );
   AdvStringGrid1->Cells[4][0] = ini->ReadString( "MCFG", "MCFGInfoStr22", "������" );
   Button4->Caption = ini->ReadString( "MCFG", "BitBtn1Caption", "��������" );
   Button5->Caption = ini->ReadString( "MCFG", "Button5Caption", "��������" );
   Button6->Caption = ini->ReadString( "MCFG", "BitBtn2Caption", "�������" );

   MCFGInfoStr26 = ini->ReadString( "MCFG", "MCFGInfoStr26", "��������" );
   MCFGInfoStr27 = ini->ReadString( "MCFG", "MCFGInfoStr27", "��������" );
   MCFGInfoStr28 = ini->ReadString( "MCFG", "MCFGInfoStr28", "��� �����" );
   MCFGInfoStr29 = ini->ReadString( "MCFG", "MCFGInfoStr29", "������ ��" );
   MCFGInfoStr62 = ini->ReadString( "MCFG", "MCFGInfoStr62", "������������� �����" );

   GroupBox10->Caption = ini->ReadString( "MCFG", "GroupBox10Caption", "����" );
   Label46->Caption = ini->ReadString( "MCFG", "Label36Caption", "���" );
   ComboBox20->Items->Clear();
   ComboBox20->Items->Add(ini->ReadString( "MCFG", "MCFGInfoStr31", "����-�" ));
   ComboBox20->Items->Add(ini->ReadString( "MCFG", "MCFGInfoStr30", "����" ));
   ComboBox20->ItemIndex = 0;

   GroupBox20->Caption = ini->ReadString( "MAINFORM", "GobiDkKan1Item", "����� 1" );
   MCFGInfoStr63 = ini->ReadString( "MCFG", "MCFGInfoStr63", "����" );
   Label49->Caption = MCFGInfoStr63;
   ComboBox14->Items->Clear();
   ComboBox14->Items->Add(MCFGInfoStr65);
   for( int i = 1; i < 100; i++ ) ComboBox14->Items->Add("COM"+IntToStr(i));
   ComboBox14->ItemIndex = 0;
   Label53->Caption = ini->ReadString( "MCFG", "Label53Caption", "�������� ������, ����" );
   Label54->Caption = ini->ReadString( "MCFG", "Label54Caption", "���-�� ��������" );

   GroupBox21->Caption = ini->ReadString( "MAINFORM", "GobiDkKan2Item", "����� 2" );
   Label16->Caption = MCFGInfoStr63;
   ComboBox5->Items->Clear();
   ComboBox5->Items->Add(MCFGInfoStr65);
   for( int i = 1; i < 100; i++ ) ComboBox5->Items->Add("COM"+IntToStr(i));
   ComboBox5->ItemIndex = 0;
   Label44->Caption = ini->ReadString( "MCFG", "Label53Caption", "�������� ������, ����" );
   Label45->Caption = ini->ReadString( "MCFG", "Label54Caption", "���-�� ��������" );

   GroupBox22->Caption = ini->ReadString( "MAINFORM", "GobiDkKan3Item", "����� 3" );
   Label55->Caption = MCFGInfoStr63;
   ComboBox21->Items->Clear();
   ComboBox21->Items->Add(MCFGInfoStr65);
   for( int i = 1; i < 100; i++ ) ComboBox21->Items->Add("COM"+IntToStr(i));
   ComboBox21->ItemIndex = 0;
   Label56->Caption = ini->ReadString( "MCFG", "Label53Caption", "�������� ������, ����" );
   Label57->Caption = ini->ReadString( "MCFG", "Label54Caption", "���-�� ��������" );

   GroupBox23->Caption = ini->ReadString( "MAINFORM", "GobiDkKan4Item", "����� 4" );
   Label58->Caption = MCFGInfoStr63;
   ComboBox22->Items->Clear();
   ComboBox22->Items->Add(MCFGInfoStr65);
   for( int i = 1; i < 100; i++ ) ComboBox22->Items->Add("COM"+IntToStr(i));
   ComboBox22->ItemIndex = 0;
   Label59->Caption = ini->ReadString( "MCFG", "Label53Caption", "�������� ������, ����" );
   Label60->Caption = ini->ReadString( "MCFG", "Label54Caption", "���-�� ��������" );

   GroupBox1->Caption = ini->ReadString( "MCFG", "GroupBox1Caption", "�������� ����� ������� (������ ��� ����)"  );
   RadioButton1->Caption = ini->ReadString( "MCFG", "RadioButton1Caption", "������"  );
   RadioButton2->Caption = ini->ReadString( "MCFG", "RadioButton2aption", "������ ����� \"������ ������\""  );

   GroupBox11->Caption = ini->ReadString( "MAINFORM", "MsgStr38", "���. �����" );
   Label66->Caption = MCFGInfoStr63;
   ComboBox24->Items->Clear();
   ComboBox24->Items->Add(MCFGInfoStr65);
   for( int i = 1; i < 100; i++ ) ComboBox24->Items->Add("COM"+IntToStr(i));
   ComboBox24->ItemIndex = 0;

   GroupBox13->Caption = MsgStr35 + ", " + MsgStr36;
   Label33->Caption = ini->ReadString( "MCFG", "Label48Caption", "�����" );
   ComboBox15->Items->Clear();
   ComboBox15->Items->Add(MCFGInfoStr65);
   ComboBox15->Items->Add(MsgStr36);
   ComboBox15->Items->Add(MsgStr35);
   ComboBox15->ItemIndex = 0;
   Label34->Caption = ini->ReadString( "MCFG", "Label34Caption", "������" );
   Label35->Caption = MCFGInfoStr63;
   BitBtn11->Caption = ini->ReadString( "MCFG", "BitBtn11Caption", "����������" );
   Label47->Caption = ini->ReadString( "MCFG", "Label47Caption", "�������� \"� ���\", ���" );

   GroupBox6->Caption = MsgStr37;
   Label17->Caption = MCFGInfoStr63;
   ComboBox7->Items->Clear();
   ComboBox7->Items->Add(MCFGInfoStr65);
   for( int i = 1; i < 100; i++ ) ComboBox7->Items->Add("COM"+IntToStr(i));
   ComboBox7->ItemIndex = 0;

   GroupBox12->Caption = ini->ReadString( "MCFG", "GroupBox12Caption", "������ MySQL"  );
   Label22->Caption = ini->ReadString( "MCFG", "Label48Caption", "�����" );
   ComboBox13->Items->Clear();
   ComboBox13->Items->Add(MCFGInfoStr65);
   ComboBox13->Items->Add(MCFGInfoStr66);
   ComboBox13->ItemIndex = 0;
   Label23->Caption = ini->ReadString( "MCFG", "Label34Caption", "������" );
   Label28->Caption = MCFGInfoStr63;
   BitBtn7->Caption = ini->ReadString( "MCFG", "BitBtn11Caption", "����������" );
   MCFGInfoStr64 = ini->ReadString( "MCFG", "MCFGInfoStr64", "�����" );
   Label51->Caption = MCFGInfoStr64;
   Label52->Caption = ini->ReadString( "OPERATORSDLG", "OperatorsDlgLabel2Caption", "������" );
   Label62->Caption = ini->ReadString( "DB", "MainCaption", "���� ������" );
   Button1->Caption = ini->ReadString( "MCFG", "Button1Caption", "������������" );
   Label15->Caption = ini->ReadString( "MCFG", "Label15Caption", "����� ������ �������" );
   ComboBox11->Items->Clear();
   ComboBox11->Items->Add(ini->ReadString( "MCFG", "ComboBox11Item0", "��� ����������" ));
   ComboBox11->Items->Add(ini->ReadString( "MCFG", "ComboBox11Item1", "� �����������" ));
   ComboBox11->ItemIndex = 0;
   CheckBox2->Caption = ini->ReadString( "MCFG", "CheckBox2Caption", "������������ ���������� ������" );
   CheckBox3->Caption = ini->ReadString( "MCFG", "CheckBox3Caption", "������������ ���������� �������� ���" );

   GroupBox4->Caption = ini->ReadString( "MCFG", "GroupBox4Caption", "��������� �����������"  );
   Label24->Caption = ini->ReadString( "MCFG", "Label24Caption", "���� � ��������� �����" );
   Label25->Caption = ini->ReadString( "MCFG", "Label25Caption", "����. ���-�� �������" );
   Button3->Caption = ini->ReadString( "MCFG", "Button5Caption", "��������" );

   Dk_pdi->Caption = ini->ReadString( "MCFG", "Dk_pdiCaption", "��������� ������� ��" );
   Bazalt_pdi->Caption = ini->ReadString( "MCFG", "Bazalt_pdiCaption", "�� �������" );
   Razriv11_pdi->Caption = ini->ReadString( "MCFG", "Razriv11_pdiCaption", "������ - ������ 1 ������� ������" );
   Razriv12_pdi->Caption = ini->ReadString( "MCFG", "Razriv12_pdiCaption", "������ - ������ 2 ������� ������" );
   Razriv21_pdi->Caption = ini->ReadString( "MCFG", "Razriv21_pdiCaption", "������ - ������ 1 ������� ������" );
   Razriv22_pdi->Caption = ini->ReadString( "MCFG", "Razriv22_pdiCaption", "������ - ������ 2 ������� ������" );

   OpenPictureDialog1->Title =  ini->ReadString( "MCFG", "OpenPictureDialog1Title", "������� ���� ������" );
   OpenPictureDialog2->Title =  ini->ReadString( "MCFG", "OpenPictureDialog2Title", "������� ���� �����" );
   OpenDialog1->Title =  ini->ReadString( "MCFG", "OpenDialog1Title", "������� ���� ��������" );
   OpenDialog2->Title =  ini->ReadString( "MCFG", "OpenDialog2Title", "������� ���� �������� \"�����-�-��\"" );
   SaveDialog1->Title =  ini->ReadString( "MCFG", "SaveDialog1Title", "��������� ���� ��������" );

   MCFGInfoStr55 = ini->ReadString( "MCFG", "MCFGInfoStr55", "����������� ������ �� �����" );
   MCFGInfoStr67 = ini->ReadString( "MCFG", "MCFGInfoStr67", "������������ ��" );
   MCFGInfoStr68 = ini->ReadString( "MCFG", "MCFGInfoStr68", "������" );
   MCFGInfoStr69 = ini->ReadString( "MCFG", "MCFGInfoStr69", "������������" );
   MCFGInfoStr70 = ini->ReadString( "MCFG", "MCFGInfoStr70", "������" );
   MCFGInfoStr71 = ini->ReadString( "MCFG", "MCFGInfoStr71", "�������" );
   MCFGInfoStr72 = ini->ReadString( "MCFG", "MCFGInfoStr72", "���������" );
   MCFGInfoStr73 = ini->ReadString( "MCFG", "MCFGInfoStr73", "������������ root �������� ��� ������� ������!" );
   MCFGInfoStr74 = ini->ReadString( "MCFG", "MCFGInfoStr74", "������ �������� ���� ������" );
   MCFGInfoStr75 = ini->ReadString( "MCFG", "MCFGInfoStr75", "���� ������ �������!" );
   MCFGInfoStr76 = ini->ReadString( "MCFG", "MCFGInfoStr76", "���� ������ ����� ������� � ��� ������ �������. ������� ���� ������?" );
   MCFGInfoStr77 = ini->ReadString( "MCFG", "MCFGInfoStr77", "������ �������� ���� ������" );
   MCFGInfoStr78 = ini->ReadString( "MCFG", "MCFGInfoStr78", "���� ������ �������!" );
   MCFGInfoStr79 = ini->ReadString( "MCFG", "MCFGInfoStr79", "�� ������ ������� ���������!" );
   MCFGInfoStr80 = ini->ReadString( "MCFG", "MCFGInfoStr80", "�� ����� ������ ���������!" );
   MCFGInfoStr81 = ini->ReadString( "MCFG", "MCFGInfoStr81", "����� �������� ��� ����������!" );
   MCFGInfoStr82 = ini->ReadString( "MCFG", "MCFGInfoStr82", "��������� ����" );
   MCFGInfoStr83 = ini->ReadString( "MCFG", "MCFGInfoStr83", "������ ������� ������!" );
   MCFGInfoStr84 = ini->ReadString( "MCFG", "MCFGInfoStr84", "������ ������������ �����!" );
   MCFGInfoStr85 = ini->ReadString( "MCFG", "MCFGInfoStr85", "������ �������� ������ ������������ ��!" );
   MCFGInfoStr86 = ini->ReadString( "MCFG", "MCFGInfoStr86", "����� ������������ �� ������!" );
   MCFGInfoStr87 = ini->ReadString( "MCFG", "MCFGInfoStr87", "�� ����� �����!" );
   MCFGInfoStr88 = ini->ReadString( "MCFG", "MCFGInfoStr88", "������ �������� ������������ ��!" );
   MCFGInfoStr89 = ini->ReadString( "MCFG", "MCFGInfoStr89", "������������ �� ������!" );
   MCFGInfoStr90 = ini->ReadString( "MCFG", "MCFGInfoStr90", "�� ������ ��� ��-������!" );
   MCFGInfoStr91 = ini->ReadString( "MCFG", "MCFGInfoStr91", "����� ������ ��� ����������!" );
   MCFGInfoStr92 = ini->ReadString( "MCFG", "MCFGInfoStr92", "�� ���������� ����������!" );
   MCFGInfoStr93 = ini->ReadString( "MCFG", "MCFGInfoStr93", "���� ���� ��� ������������!" );
   MCFGInfoStr94 = ini->ReadString( "MCFG", "MCFGInfoStr94", "�� ������ ��� �������!" );
   MCFGInfoStr95 = ini->ReadString( "MCFG", "MCFGInfoStr95", "������ �� ������!" );
   MCFGInfoStr96 = ini->ReadString( "MCFG", "MCFGInfoStr96", "������ ����������� ������� ����������. ������ ������� ����������!" );
   MCFGInfoStr97 = ini->ReadString( "MCFG", "MCFGInfoStr97", "���� rastrmtv_cfg.ini �� ������!" );
   MCFGInfoStr98 = ini->ReadString( "MCFG", "MCFGInfoStr98", "��" );
   MCFGInfoStr99 = ini->ReadString( "MCFG", "MCFGInfoStr99", "������� �� ������" );
   MCFGInfoStr100 = ini->ReadString( "MCFG", "MCFGInfoStr100", "����������" );
   MCFGInfoStr101 = ini->ReadString( "MCFG", "MCFGInfoStr101", "�� ����������" );

   InfoStr2 = ini->ReadString( "DB", "InfoStr2", "������ ���������� � �������� ��� ������ MySQL!" );
   InfoStr3 = ini->ReadString( "DB", "InfoStr3", "��� ������" );
   InfoStr4 = ini->ReadString( "DB", "InfoStr4", "C��������" );
   InfoStr5 = ini->ReadString( "DB", "InfoStr5", "������ � ��������� ����������� �� �������!" );

   WarningMsg = ini->ReadString( "MSGSTRING", "WarningMsg", "��������������" );
   ErrorMsg = ini->ReadString( "MSGSTRING", "ErrorMsg", "������" );

   delete ini;

   return true;
}
void __fastcall TMainForm::Bazalt_pdiDrawItem(TObject *Sender,
      TCanvas *ACanvas, TRect &ARect, bool Selected)
{
   if( PCfgObj(ObjTree->Selected->Data)->Bazalt )
   {
      ACanvas->TextRect(ARect, ARect.Left+20, ARect.Top+2, Bazalt_pdi->Caption);
      ACanvas->Draw(ARect.Left, ARect.Top+2, I1Img);
   }
   else
   {
      ACanvas->TextRect(ARect, ARect.Left+5, ARect.Top+2, Bazalt_pdi->Caption);
   }
}
void __fastcall TMainForm::Bazalt_pdiMeasureItem(TObject *Sender,
      TCanvas *ACanvas, int &Width, int &Height)
{
   Width = 300;
   Height = 20;
}
void __fastcall TMainForm::Dk_pdiDrawItem(TObject *Sender,
      TCanvas *ACanvas, TRect &ARect, bool Selected)
{
   if( PCfgObj(ObjTree->Selected->Data)->Dk )
   {
      ACanvas->TextRect(ARect, ARect.Left+20, ARect.Top+2, Dk_pdi->Caption);
      ACanvas->Draw(ARect.Left, ARect.Top+2, I1Img);
   }
   else
   {
      ACanvas->TextRect(ARect, ARect.Left+5, ARect.Top+2, Dk_pdi->Caption);
   }
}
void __fastcall TMainForm::Dk_pdiMeasureItem(TObject *Sender,
      TCanvas *ACanvas, int &Width, int &Height)
{
   Width = 300;
   Height = 20;
}
void __fastcall TMainForm::Razriv11_pdiDrawItem(TObject *Sender,
      TCanvas *ACanvas, TRect &ARect, bool Selected)
{
   if( PCfgObj(ObjTree->Selected->Data)->Razriv )
   {
      ACanvas->TextRect(ARect, ARect.Left+20, ARect.Top+2, Razriv11_pdi->Caption);
      ACanvas->Draw(ARect.Left, ARect.Top+2, I1Img);
   }
   else
   {
      ACanvas->TextRect(ARect, ARect.Left+5, ARect.Top+2, Razriv11_pdi->Caption);
   }
}
void __fastcall TMainForm::Razriv11_pdiMeasureItem(TObject *Sender,
      TCanvas *ACanvas, int &Width, int &Height)
{
   Width = 300;
   Height = 20;
}
void __fastcall TMainForm::Razriv12_pdiDrawItem(TObject *Sender,
      TCanvas *ACanvas, TRect &ARect, bool Selected)
{
   if( PCfgObj(ObjTree->Selected->Data)->Razriv )
   {
      ACanvas->TextRect(ARect, ARect.Left+20, ARect.Top+2, Razriv12_pdi->Caption);
      ACanvas->Draw(ARect.Left, ARect.Top+2, I1Img);
   }
   else
   {
      ACanvas->TextRect(ARect, ARect.Left+5, ARect.Top+2, Razriv12_pdi->Caption);
   }
}
void __fastcall TMainForm::Razriv12_pdiMeasureItem(TObject *Sender,
      TCanvas *ACanvas, int &Width, int &Height)
{
   Width = 300;
   Height = 20;
}
void __fastcall TMainForm::Razriv21_pdiDrawItem(TObject *Sender,
      TCanvas *ACanvas, TRect &ARect, bool Selected)
{
   if( PCfgObj(ObjTree->Selected->Data)->Razriv )
   {
      ACanvas->TextRect(ARect, ARect.Left+20, ARect.Top+2, Razriv21_pdi->Caption);
      ACanvas->Draw(ARect.Left, ARect.Top+2, I1Img);
   }
   else
   {
      ACanvas->TextRect(ARect, ARect.Left+5, ARect.Top+2, Razriv21_pdi->Caption);
   }
}
void __fastcall TMainForm::Razriv21_pdiMeasureItem(TObject *Sender,
      TCanvas *ACanvas, int &Width, int &Height)
{
   Width = 300;
   Height = 20;
}
void __fastcall TMainForm::Razriv22_pdiDrawItem(TObject *Sender,
      TCanvas *ACanvas, TRect &ARect, bool Selected)
{
   if( PCfgObj(ObjTree->Selected->Data)->Razriv )
   {
      ACanvas->TextRect(ARect, ARect.Left+20, ARect.Top+2, Razriv22_pdi->Caption);
      ACanvas->Draw(ARect.Left, ARect.Top+2, I1Img);
   }
   else
   {
      ACanvas->TextRect(ARect, ARect.Left+5, ARect.Top+2, Razriv22_pdi->Caption);
   }
}
void __fastcall TMainForm::Razriv22_pdiMeasureItem(TObject *Sender,
      TCanvas *ACanvas, int &Width, int &Height)
{
   Width = 300;
   Height = 20;
}
void __fastcall TMainForm::KedrImportItemClick(TObject *Sender)
{
   OpenDialog3->HistoryList->Clear();
   OpenDialog3->InitialDir = ExtractFilePath(Application->ExeName);

   if( OpenDialog3->Execute() )
   {
      if( FileExists(OpenDialog3->FileName) )
      {
         TStringList *KedrList;
         KedrList = new TStringList;
         KedrList->LoadFromFile(OpenDialog3->FileName);

         if( KedrList->Count > 0 )
         {
            ObjTree->Items->Clear();
            PCfgObj  CfgObj;
            CfgObj = new TCfgObj;
            CfgObj->Name = MsgStr25;

            TTreeNode* tempNode;
            ObjTree->Items->BeginUpdate();
            tempNode = ObjTree->Items->AddObject( ObjTree->Selected, CfgObj->Name, CfgObj );
            tempNode->SelectedIndex = 4;
            tempNode->ImageIndex = 4;
            tempNode->Selected = true;
            ObjTreeClick(this);

            ObjTree->Items->EndUpdate();


            AnsiString str, name, desc, pid, type;
            int p = 0;

            for( int i = 0; i < KedrList->Count; i++ )
            {
               str = KedrList->Strings[i];

               p = str.Pos("object=");
               if( p > 0 )
               {
                  name = "";
                  desc = "";
                  type = "";
                  pid = "";
               }

               p = str.Pos("name=");
               if( p > 0 ) name = str.SubString(p+5, str.Length() - p - 4 );

               p = str.Pos("desc=");
               if( p > 0 ) desc = str.SubString(p+5, str.Length() - p - 4 );

               p = str.Pos("phispointtype=");
               if( p > 0 ) type = str.SubString(p+14, str.Length() - p - 13 );

               p = str.Pos("pointid=");
               if( p > 0 ) pid = str.SubString(p+8, str.Length() - p - 7 );

               if( name.Length() > 0 && type == "CO" && pid.Length() > 0 )
               {
                  PCfgObj  CfgObj;
                  CfgObj = new TCfgObj;
                  CfgObj->Type = 100;
                  CfgObj->Num1 = 0;
                  CfgObj->Num2 = 0;
                  CfgObj->Num3 = 0;
                  CfgObj->Level = 1;
                  CfgObj->Name = name;
                  CfgObj->IconVisible = false;
                  CfgObj->X = 0;
                  CfgObj->Y = 0;
                  CfgObj->Icon1Path = pid;
                  CfgObj->Icon2Path = desc;
                  CfgObj->Icon3Path = "";
                  CfgObj->Icon4Path = "";
                  CfgObj->Icon5Path = "";
                  CfgObj->Icon6Path = "";
                  CfgObj->Icon7Path = "";
                  CfgObj->Icon8Path = "";
                  CfgObj->Dk = false;
                  CfgObj->Bazalt = false;
                  CfgObj->Metka = false;
                  CfgObj->Razriv = false;
                  CfgObj->AdamOff = false;

                  tempNode = ObjTree->Selected;

                  if( CfgObj->Level == tempNode->Level )
                  {
                     tempNode = ObjTree->Items->AddObject( ObjTree->Selected, CfgObj->Name, CfgObj );
                  }
                  else
                  {
                     tempNode = ObjTree->Items->AddChildObject( ObjTree->Selected, CfgObj->Name, CfgObj );
                  }

                  tempNode->SelectedIndex = 7;
                  tempNode->ImageIndex = 7;

                  name = "";
                  desc = "";
                  type = "";
                  pid = "";
               }

               p = str.Pos("end");
               if( p > 0 )
               {
                  name = "";
                  desc = "";
                  type = "";
                  pid = "";
               }
            }

            tempNode = ObjTree->Items->Item[0];
            tempNode->Selected = true;
            ObjTreeClick(this);

            ObjTree->Items->EndUpdate();
         }

         delete KedrList;
      }
   }
}
void __fastcall TMainForm::Edit1KeyPress(TObject *Sender, char &Key)
{
   if( Key == '"' || Key == '\'' ) Key = 0;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::AlarmMsgOn_pdiClick(TObject *Sender)
{
   AlarmMsgOn_pdi->Checked = !AlarmMsgOn_pdi->Checked;
   PCfgObj(ObjTree->Selected->Data)->AlarmMsgOn = AlarmMsgOn_pdi->Checked;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::ConnectBlock_pdiClick(TObject *Sender)
{
   ConnectBlock_pdi->Checked = !ConnectBlock_pdi->Checked;
   PCfgObj(ObjTree->Selected->Data)->ConnectBlock = ConnectBlock_pdi->Checked;

   Metka_pdi->Checked = false;
   PCfgObj(ObjTree->Selected->Data)->Metka = Metka_pdi->Checked;

   int type = PCfgObj(ObjTree->Selected->Data)->Type;
   int num1 = PCfgObj(ObjTree->Selected->Data)->Num1;
   int num2 = PCfgObj(ObjTree->Selected->Data)->Num2;
   int num3 = PCfgObj(ObjTree->Selected->Data)->Num3-3;

   if( ConnectBlock_pdi->Checked )
      PCfgObj(ObjTree->Selected->Data)->ImgNum = 56;
   else
   {
      if( type == 3 ) PCfgObj(ObjTree->Selected->Data)->ImgNum = 0;
      if( type == 11 ) PCfgObj(ObjTree->Selected->Data)->ImgNum = 10;
   }

   ObjTree->Items->BeginUpdate();
   for( int i = 0; i < ObjTree->Items->Count; i++ )
   {
      if( type == PCfgObj(ObjTree->Items->Item[i]->Data)->Type &&
          num1 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 &&
          num2 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num2 &&
          num3 == PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 )
      {
         if( PCfgObj(ObjTree->Selected->Data)->ConnectBlock )
            PCfgObj(ObjTree->Items->Item[i]->Data)->Bazalt = false;
      }
   }
   ObjTree->Items->EndUpdate();

   ObjTreeClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::ComboBox24Change(TObject *Sender)
{
   if( ComboBox24->ItemIndex > 0 && UsePort[ComboBox24->ItemIndex] != UnUsedComPort )
   {
      MessageBox (NULL,MCFGInfoStr93.c_str(),ErrorMsg.c_str(),MB_OK|MB_ICONERROR);
      ComboBox24->ItemIndex = TabloPortNum;
   }
   else
   {
      UsePort[TabloPortNum] = UnUsedComPort;
      TabloPortNum = ComboBox24->ItemIndex;
      UsePort[TabloPortNum] = TabloComPort;

      ObjTree->Items->BeginUpdate();
      TTreeNode* tempNode;

      for( int i = 1; i < ObjTree->Items->Count; i++ )
      {
         if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 71 )
         {
            tempNode = ObjTree->Items->Item[i];
            if( ComboBox24->ItemIndex == 0 )
            {
               tempNode->SelectedIndex = 14;
               tempNode->ImageIndex = 14;
            }
            else
            {
               tempNode->SelectedIndex = 13;
               tempNode->ImageIndex = 13;
            }

         }
      }
      ObjTree->Items->EndUpdate();
   }
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::ComboBox29Change(TObject *Sender)
{
   Label27->Visible = true;
   Edit3->Visible = true;
   SpeedButton7->Visible = true;
   SpeedButton8->Visible = true;

   if( ComboBox29->ItemIndex > 0 )
   {
      Label27->Visible = false;
      Edit3->Visible = false;
      SpeedButton7->Visible = false;
      SpeedButton8->Visible = false;
   }

   if( ComboBox29->ItemIndex == 1 )
   {
        MessageBox (NULL,"��� ������ � ���� ������ ���������� �������� � ��������� ��������� \
������ \"���������� � ������� ��\"!","��������������",MB_OK|MB_ICONINFORMATION);
   }

   if( ComboBox29->ItemIndex == 0 )
   {
      HWND H = FindWindow("MainForm", "����");

      if (H == NULL)
      {
         POutObj(lpMapCfg)->CfgMode = true;
         AnsiString cmd;
         cmd = ExtractFilePath(Application->ExeName) + "m_plan.exe";
         WinExec(cmd.c_str(), SW_SHOW	);
      }
   }
   else
   {
      POutObj(lpMapCfg)->CfgMode = false;
   }
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::ComboBox17Change(TObject *Sender)
{
   if( ComboBox17->ItemIndex == 0 )
   {
      Label39->Visible = ComboBox17->ItemIndex;
      RxSpinEdit4->Visible = ComboBox17->ItemIndex;
      Label78->Visible = ComboBox17->ItemIndex;
      RxSpinEdit5->Visible = ComboBox17->ItemIndex;
   }
   else
   {
      if( ComboBox16->ItemIndex == 1 )
      {
         Label39->Visible = ComboBox17->ItemIndex;
         RxSpinEdit4->Visible = ComboBox17->ItemIndex;
         Label78->Visible = ComboBox17->ItemIndex;
         RxSpinEdit5->Visible = ComboBox17->ItemIndex;
      }
      else
      {
         Label39->Visible = false;
         RxSpinEdit4->Visible = false;
         Label78->Visible = false;
         RxSpinEdit5->Visible = false;
      }
   }
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::Button7Click(TObject *Sender)
{
   PCfgObj(ObjTree->Selected->Data)->lan = RxSpinEdit6->Value;
   PCfgObj(ObjTree->Selected->Data)->lon = RxSpinEdit7->Value;
   PCfgObj(ObjTree->Selected->Data)->description = Edit17->Text;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::Edit17KeyPress(TObject *Sender, char &Key)
{
   if( Key == '"' || Key == '\'' ) Key = 0;
}
void __fastcall TMainForm::Button8Click(TObject *Sender)
{
   OpenDialog4->HistoryList->Clear();
   OpenDialog4->InitialDir = ExtractFilePath(Edit18->Text);

   if( OpenDialog4->Execute() )
   {
      if( FileExists(OpenDialog4->FileName) )
      {
         Edit18->Text = OpenDialog4->FileName;
      }
   }
}
void __fastcall TMainForm::Button9Click(TObject *Sender)
{
   if( PCfgObj(ObjTree->Selected->Data)->Type == 32  )
   {
      ObjTree->Items->BeginUpdate();
      for( int i = 0; i < ObjTree->Items->Count; i++ )
      {
         if( PCfgObj(ObjTree->Items->Item[i]->Data)->Type == 32  &&
             PCfgObj(ObjTree->Items->Item[i]->Data)->Num1 == PCfgObj(ObjTree->Selected->Data)->Num1 )
         {
            PCfgObj(ObjTree->Items->Item[i]->Data)->Num2 = CSpinEdit20->Value;
            PCfgObj(ObjTree->Items->Item[i]->Data)->Num3 = CSpinEdit21->Value;
            PCfgObj(ObjTree->Items->Item[i]->Data)->X = CSpinEdit22->Value;
            PCfgObj(ObjTree->Items->Item[i]->Data)->Y = CSpinEdit23->Value;
         }
      }
      ObjTree->Items->EndUpdate();
   }
}
void __fastcall TMainForm::N2Click(TObject *Sender)
{
   ObjTree->FullExpand();
}

void __fastcall TMainForm::N5Click(TObject *Sender)
{
   AnsiString str;
   int type = POprosObj(ObjTree->Selected->Data)->Type;
   int num3 =  POprosObj(ObjTree->Selected->Data)->Num3;
   if( type == 4 && POprosObj(ObjTree->Selected->Data)->Num3 >= 4 && ComboBox20->ItemIndex == 0 ) { type = 44; num3 -= 3; }
   if( type == 3 && ComboBox20->ItemIndex == 0 ) type = 33;
   if( type == 4 && ComboBox20->ItemIndex == 0 ) type = 43;
   str.sprintf("img_%d_%d_%d_%d", type,
                                  PCfgObj(ObjTree->Selected->Data)->Num1, PCfgObj(ObjTree->Selected->Data)->Num2,
                                  num3);

   StrCopy(POutObj(lpMapCfg)->ImgName, str.c_str());

   POutObj(lpMapCfg)->ImgOperationId = 8;
}
void __fastcall TMainForm::N6Click(TObject *Sender)
{
   ObjTree->FullCollapse();
}
void __fastcall TMainForm::ComboBox35Change(TObject *Sender)
{
   Label79->Visible = false;
   Edit16->Visible = false;
   Label78->Visible = false;
   RxSpinEdit5->Visible = false;
   Label4->Visible = false;
   ComboBox3->Visible = false;

   if( ComboBox35->ItemIndex == 0 )
   {
      Label4->Visible = true;
      ComboBox3->Visible = true;
   }
   else
   {
      Label79->Visible = true;
      Edit16->Visible = true;
      Label78->Visible = true;
      if( RxSpinEdit5->Value == 0 ) RxSpinEdit5->Value = 4001;
      RxSpinEdit5->Visible = true;
   }
}

