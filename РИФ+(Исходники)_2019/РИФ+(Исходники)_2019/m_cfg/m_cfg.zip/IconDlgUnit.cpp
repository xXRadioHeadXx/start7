#include <vcl.h>
#pragma hdrstop

#include "IconDlgUnit.h"
#include "MainUnit.h"
#pragma resource "*.dfm"
TIconDlg *IconDlg;
__fastcall TIconDlg::TIconDlg(TComponent* AOwner)
	: TForm(AOwner)
{
}
void __fastcall TIconDlg::FormCreate(TObject *Sender)
{
   if( PCfgObj(MainForm->ObjTree->Selected->Data)->Bazalt )
   {
      PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible = true;
      ComboBox1->Enabled = false;
   }

   if( PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible ) ComboBox1->ItemIndex = 0;
   else ComboBox1->ItemIndex = 1;

   LoadIcons();
}
void __fastcall TIconDlg::ComboBox1Change(TObject *Sender)
{
   if( ComboBox1->ItemIndex == 0 ) PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible = true;
   else PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible = false;

   LoadIcons();
}
void __fastcall TIconDlg::Button1Click(TObject *Sender)
{
   if( OpenPictureDialog1->Execute() )
   {
      if ( FileExists(OpenPictureDialog1->FileName) )
      {
         Image1->Picture->LoadFromFile(OpenPictureDialog1->FileName);
         PCfgObj(MainForm->ObjTree->Selected->Data)->Icon1Path = OpenPictureDialog1->FileName;
      }
   }
}
void TIconDlg::LoadIcons()
{
   
   MainForm->ImageList2->GetBitmap(Ico_Unknown,Image1->Picture->Bitmap);
   MainForm->ImageList2->GetBitmap(Ico_Norma,Image2->Picture->Bitmap);
   MainForm->ImageList2->GetBitmap(Ico_Alarm,Image3->Picture->Bitmap);
   MainForm->ImageList2->GetBitmap(Ico_Warning,Image4->Picture->Bitmap);
   MainForm->ImageList2->GetBitmap(Ico_Defect,Image5->Picture->Bitmap);
   MainForm->ImageList2->GetBitmap(Ico_Up,Image6->Picture->Bitmap);
   MainForm->ImageList2->GetBitmap(Ico_Down,Image7->Picture->Bitmap);

   Button8->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
   Button9->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

   if( PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 1 ||      
       PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 111 ||    
       PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 8 ||      
       PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 9 ||      
       PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 91 ||     
       PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 21 )      
   {
      MainForm->ImageList2->GetBitmap(Ico_Unknown+5,Image1->Picture->Bitmap);
      try
      {
         if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon1Path) )
         {
            Image1->Picture->Bitmap->Dormant();
            Image1->Picture->Bitmap->FreeImage();
            Image1->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon1Path);
         }
      }
      catch(...)
      {
         MainForm->ImageList2->GetBitmap(Ico_Unknown+5,Image1->Picture->Bitmap);
      }
      Image1->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Label1->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button1->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button10->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

      MainForm->ImageList2->GetBitmap(Ico_Norma+5,Image2->Picture->Bitmap);
      try
      {
         if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon2Path) )
         {
            Image2->Picture->Bitmap->Dormant();
            Image2->Picture->Bitmap->FreeImage();
            Image2->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon2Path);
         }
      }
      catch(...)
      {
         MainForm->ImageList2->GetBitmap(Ico_Norma+5,Image2->Picture->Bitmap);
      }
      Image2->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Label2->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button2->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button11->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

      MainForm->ImageList2->GetBitmap(Ico_Alarm+5,Image3->Picture->Bitmap);
      try
      {
         if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon3Path) )
         {
            Image3->Picture->Bitmap->Dormant();
            Image3->Picture->Bitmap->FreeImage();
            Image3->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon3Path);
         }
      }
      catch(...)
      {
         MainForm->ImageList2->GetBitmap(Ico_Alarm+5,Image3->Picture->Bitmap);
      }
      Image3->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Label3->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button3->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button12->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

      MainForm->ImageList2->GetBitmap(Ico_Warning+5,Image4->Picture->Bitmap);
      try
      {
         if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon4Path) )
         {
            Image4->Picture->Bitmap->Dormant();
            Image4->Picture->Bitmap->FreeImage();
            Image4->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon4Path);
         }
      }
      catch(...)
      {
         MainForm->ImageList2->GetBitmap(Ico_Warning+5,Image4->Picture->Bitmap);
      }
      Image4->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Label4->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button4->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button13->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

      MainForm->ImageList2->GetBitmap(Ico_Defect+5,Image5->Picture->Bitmap);
      try
      {
         if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon5Path) )
         {
            Image5->Picture->Bitmap->Dormant();
            Image5->Picture->Bitmap->FreeImage();
            Image5->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon5Path);
         }
      }
      catch(...)
      {
         MainForm->ImageList2->GetBitmap(Ico_Defect+5,Image5->Picture->Bitmap);
      }
      Image5->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Label5->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button5->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button14->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

      Image6->Visible = false;
      Label6->Visible = false;
      Button6->Visible = false;
      Button15->Visible = false;

      Image7->Visible = false;
      Label7->Visible = false;
      Button7->Visible = false;
      Button16->Visible = false;
   }
   else if( PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 2 ||    
       PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 11 )         
   {
      if( !PCfgObj(MainForm->ObjTree->Selected->Data)->Bazalt )
      {
          MainForm->ImageList2->GetBitmap(Ico_Unknown+10,Image1->Picture->Bitmap);
          try
          {
             if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon1Path) )
             {
                Image1->Picture->Bitmap->Dormant();
                Image1->Picture->Bitmap->FreeImage();
                Image1->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon1Path);
             }
          }
          catch(...)
          {
             MainForm->ImageList2->GetBitmap(Ico_Unknown+10,Image1->Picture->Bitmap);
          }
          Image1->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Label1->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button1->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button10->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

          MainForm->ImageList2->GetBitmap(Ico_Norma+10,Image2->Picture->Bitmap);
          try
          {
             if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon2Path) )
             {
                Image2->Picture->Bitmap->Dormant();
                Image2->Picture->Bitmap->FreeImage();
                Image2->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon2Path);
             }
          }
          catch(...)
          {
             MainForm->ImageList2->GetBitmap(Ico_Norma+10,Image2->Picture->Bitmap);
          }
          Image2->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Label2->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button2->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button11->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

          MainForm->ImageList2->GetBitmap(Ico_Alarm+10,Image3->Picture->Bitmap);
          try
          {
             if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon3Path) )
             {
                Image3->Picture->Bitmap->Dormant();
                Image3->Picture->Bitmap->FreeImage();
                Image3->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon3Path);
             }
          }
          catch(...)
          {
             MainForm->ImageList2->GetBitmap(Ico_Alarm+10,Image3->Picture->Bitmap);
          }
          Image3->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Label3->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button3->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button12->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

          MainForm->ImageList2->GetBitmap(Ico_Warning+10,Image4->Picture->Bitmap);
          try
          {
             if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon4Path) )
             {
                Image4->Picture->Bitmap->Dormant();
                Image4->Picture->Bitmap->FreeImage();
                Image4->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon4Path);
             }
          }
          catch(...)
          {
             MainForm->ImageList2->GetBitmap(Ico_Warning+10,Image4->Picture->Bitmap);
          }
          Image4->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Label4->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button4->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button13->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

          MainForm->ImageList2->GetBitmap(Ico_Defect+10,Image5->Picture->Bitmap);
          try
          {
             if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon5Path) )
             {
                Image5->Picture->Bitmap->Dormant();
                Image5->Picture->Bitmap->FreeImage();
                Image5->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon5Path);
             }
          }
          catch(...)
          {
             MainForm->ImageList2->GetBitmap(Ico_Defect+10,Image5->Picture->Bitmap);
          }
          Image5->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Label5->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button5->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button14->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

          Image6->Visible = false;
          Label6->Visible = false;
          Button6->Visible = false;
          Button15->Visible = false;
      }
      else  
      {
          MainForm->ImageList2->GetBitmap(49,Image1->Picture->Bitmap);
          try
          {
             if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon1Path) )
             {
                Image1->Picture->Bitmap->Dormant();
                Image1->Picture->Bitmap->FreeImage();
                Image1->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon1Path);
             }
          }
          catch(...)
          {
             MainForm->ImageList2->GetBitmap(49,Image1->Picture->Bitmap);
          }
          Image1->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Label1->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button1->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button10->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

          MainForm->ImageList2->GetBitmap(32,Image2->Picture->Bitmap);
          try
          {
             if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon2Path) )
             {
                Image2->Picture->Bitmap->Dormant();
                Image2->Picture->Bitmap->FreeImage();
                Image2->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon2Path);
             }
          }
          catch(...)
          {
             MainForm->ImageList2->GetBitmap(32,Image2->Picture->Bitmap);
          }
          Image2->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Label2->Caption = "1. ������";
          Label2->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button2->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button11->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

          MainForm->ImageList2->GetBitmap(33,Image3->Picture->Bitmap);
          try
          {
             if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon3Path) )
             {
                Image3->Picture->Bitmap->Dormant();
                Image3->Picture->Bitmap->FreeImage();
                Image3->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon3Path);
             }
          }
          catch(...)
          {
             MainForm->ImageList2->GetBitmap(33,Image3->Picture->Bitmap);
          }
          Image3->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Label3->Caption = "2. ������";
          Label3->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button3->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button12->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

          MainForm->ImageList2->GetBitmap(34,Image4->Picture->Bitmap);
          try
          {
             if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon4Path) )
             {
                Image4->Picture->Bitmap->Dormant();
                Image4->Picture->Bitmap->FreeImage();
                Image4->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon4Path);
             }
          }
          catch(...)
          {
             MainForm->ImageList2->GetBitmap(34,Image4->Picture->Bitmap);
          }
          Image4->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Label4->Caption = "3. ������ ������";
          Label4->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button4->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button13->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

          MainForm->ImageList2->GetBitmap(35,Image5->Picture->Bitmap);
          try
          {
             if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon5Path) )
             {
                Image5->Picture->Bitmap->Dormant();
                Image5->Picture->Bitmap->FreeImage();
                Image5->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon5Path);
             }
          }
          catch(...)
          {
             MainForm->ImageList2->GetBitmap(35,Image5->Picture->Bitmap);
          }
          Image5->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Label5->Caption = "4. ������ ������";
          Label5->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button5->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button14->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

          MainForm->ImageList2->GetBitmap(36,Image6->Picture->Bitmap);
          try
          {
             if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon6Path) )
             {
                Image6->Picture->Bitmap->Dormant();
                Image6->Picture->Bitmap->FreeImage();
                Image6->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon6Path);
             }
          }
          catch(...)
          {
             MainForm->ImageList2->GetBitmap(36,Image6->Picture->Bitmap);
          }
          Image6->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Label6->Caption = "5. ��� �����";
          Label6->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button6->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button15->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      }

      Image7->Visible = false;
      Label7->Visible = false;
      Button7->Visible = false;
      Button16->Visible = false;
   }
   else if( PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 10 )    
   {
      MainForm->ImageList2->GetBitmap(Ico_Unknown+15,Image1->Picture->Bitmap);
      try
      {
         if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon1Path) )
         {
            Image1->Picture->Bitmap->Dormant();
            Image1->Picture->Bitmap->FreeImage();
            Image1->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon1Path);
         }
      }
      catch(...)
      {
         MainForm->ImageList2->GetBitmap(Ico_Unknown+15,Image1->Picture->Bitmap);
      }
      Image1->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Label1->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button1->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button10->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

      MainForm->ImageList2->GetBitmap(Ico_Norma+15,Image2->Picture->Bitmap);
      try
      {
         if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon2Path) )
         {
            Image2->Picture->Bitmap->Dormant();
            Image2->Picture->Bitmap->FreeImage();
            Image2->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon2Path);
         }
      }
      catch(...)
      {
         MainForm->ImageList2->GetBitmap(Ico_Norma+15,Image2->Picture->Bitmap);
      }
      Image2->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Label2->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button2->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button11->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

      MainForm->ImageList2->GetBitmap(Ico_Alarm+15,Image3->Picture->Bitmap);
      try
      {
         if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon3Path) )
         {
            Image3->Picture->Bitmap->Dormant();
            Image3->Picture->Bitmap->FreeImage();
            Image3->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon3Path);
         }
      }
      catch(...)
      {
         MainForm->ImageList2->GetBitmap(Ico_Alarm+15,Image3->Picture->Bitmap);
      }
      Image3->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Label3->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button3->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button12->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

      MainForm->ImageList2->GetBitmap(Ico_Warning+15,Image4->Picture->Bitmap);
      try
      {
         if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon4Path) )
         {
            Image4->Picture->Bitmap->Dormant();
            Image4->Picture->Bitmap->FreeImage();
            Image4->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon4Path);
         }
      }
      catch(...)
      {
         MainForm->ImageList2->GetBitmap(Ico_Warning+15,Image4->Picture->Bitmap);
      }
      Image4->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Label4->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button4->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button13->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

      MainForm->ImageList2->GetBitmap(Ico_Defect+15,Image5->Picture->Bitmap);
      try
      {
         if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon5Path) )
         {
            Image5->Picture->Bitmap->Dormant();
            Image5->Picture->Bitmap->FreeImage();
            Image5->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon5Path);
         }
      }
      catch(...)
      {
         MainForm->ImageList2->GetBitmap(Ico_Defect+15,Image5->Picture->Bitmap);
      }
      Image5->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Label5->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button5->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button14->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

      MainForm->ImageList2->GetBitmap(Ico_Up,Image6->Picture->Bitmap);
      try
      {
         if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon6Path) )
         {
            Image6->Picture->Bitmap->Dormant();
            Image6->Picture->Bitmap->FreeImage();
            Image6->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon6Path);
         }
      }
      catch(...)
      {
         MainForm->ImageList2->GetBitmap(Ico_Up,Image6->Picture->Bitmap);
      }
      Image6->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Label6->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button6->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button15->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

      MainForm->ImageList2->GetBitmap(Ico_Down,Image7->Picture->Bitmap);
      try
      {
         if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon7Path) )
         {
            Image7->Picture->Bitmap->Dormant();
            Image7->Picture->Bitmap->FreeImage();
            Image7->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon7Path);
         }
      }
      catch(...)
      {
         MainForm->ImageList2->GetBitmap(Ico_Down,Image7->Picture->Bitmap);
      }
      Image7->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Label7->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button7->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button16->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
   }
   else if( PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 3 ) 
   {
      if( !PCfgObj(MainForm->ObjTree->Selected->Data)->Bazalt && !PCfgObj(MainForm->ObjTree->Selected->Data)->ConnectBlock )
      {
          MainForm->ImageList2->GetBitmap(Ico_Unknown,Image1->Picture->Bitmap);
          try
          {
             if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon1Path) )
             {
                Image1->Picture->Bitmap->Dormant();
                Image1->Picture->Bitmap->FreeImage();
                Image1->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon1Path);
             }
          }
          catch(...)
          {
             MainForm->ImageList2->GetBitmap(Ico_Unknown,Image1->Picture->Bitmap);
          }
          Image1->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Label1->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button1->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button10->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

          MainForm->ImageList2->GetBitmap(Ico_Norma,Image2->Picture->Bitmap);
          try
          {
             if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon2Path) )
             {
                Image2->Picture->Bitmap->Dormant();
                Image2->Picture->Bitmap->FreeImage();
                Image2->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon2Path);
             }
          }
          catch(...)
          {
             MainForm->ImageList2->GetBitmap(Ico_Norma,Image2->Picture->Bitmap);
          }
          Image2->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Label2->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button2->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button11->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

          MainForm->ImageList2->GetBitmap(Ico_Alarm,Image3->Picture->Bitmap);
          try
          {
             if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon3Path) )
             {
                Image3->Picture->Bitmap->Dormant();
                Image3->Picture->Bitmap->FreeImage();
                Image3->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon3Path);
             }
          }
          catch(...)
          {
             MainForm->ImageList2->GetBitmap(Ico_Alarm,Image3->Picture->Bitmap);
          }
          Image3->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Label3->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button3->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button12->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

          MainForm->ImageList2->GetBitmap(Ico_Warning,Image4->Picture->Bitmap);
          try
          {
             if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon4Path) )
             {
                Image4->Picture->Bitmap->Dormant();
                Image4->Picture->Bitmap->FreeImage();
                Image4->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon4Path);
             }
          }
          catch(...)
          {
             MainForm->ImageList2->GetBitmap(Ico_Warning,Image4->Picture->Bitmap);
          }
          Image4->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Label4->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button4->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button13->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

          MainForm->ImageList2->GetBitmap(Ico_Defect,Image5->Picture->Bitmap);
          try
          {
             if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon5Path) )
             {
                Image5->Picture->Bitmap->Dormant();
                Image5->Picture->Bitmap->FreeImage();
                Image5->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon5Path);
             }
          }
          catch(...)
          {
             MainForm->ImageList2->GetBitmap(Ico_Defect,Image5->Picture->Bitmap);
          }
          Image5->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Label5->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button5->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button14->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

         Image6->Visible = false;
         Label6->Visible = false;
         Button6->Visible = false;
         Button15->Visible = false;

         Image7->Visible = false;
         Label7->Visible = false;
         Button7->Visible = false;
         Button16->Visible = false;
      }
      else if( PCfgObj(MainForm->ObjTree->Selected->Data)->Bazalt ) 
      {
          MainForm->ImageList2->GetBitmap(49,Image1->Picture->Bitmap);
          try
          {
             if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon1Path) )
             {
                Image1->Picture->Bitmap->Dormant();
                Image1->Picture->Bitmap->FreeImage();
                Image1->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon1Path);
             }
          }
          catch(...)
          {
             MainForm->ImageList2->GetBitmap(49,Image1->Picture->Bitmap);
          }
          Image1->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Label1->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button1->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button10->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

          MainForm->ImageList2->GetBitmap(32,Image2->Picture->Bitmap);
          try
          {
             if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon2Path) )
             {
                Image2->Picture->Bitmap->Dormant();
                Image2->Picture->Bitmap->FreeImage();
                Image2->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon2Path);
             }
          }
          catch(...)
          {
             MainForm->ImageList2->GetBitmap(32,Image2->Picture->Bitmap);
          }
          Image2->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Label2->Caption = "2. ������";
          Label2->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button2->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button11->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

          MainForm->ImageList2->GetBitmap(33,Image3->Picture->Bitmap);
          try
          {
             if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon3Path) )
             {
                Image3->Picture->Bitmap->Dormant();
                Image3->Picture->Bitmap->FreeImage();
                Image3->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon3Path);
             }
          }
          catch(...)
          {
             MainForm->ImageList2->GetBitmap(33,Image3->Picture->Bitmap);
          }
          Image3->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Label3->Caption = "3. ������";
          Label3->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button3->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button12->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

          MainForm->ImageList2->GetBitmap(34,Image4->Picture->Bitmap);
          try
          {
             if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon4Path) )
             {
                Image4->Picture->Bitmap->Dormant();
                Image4->Picture->Bitmap->FreeImage();
                Image4->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon4Path);
             }
          }
          catch(...)
          {
             MainForm->ImageList2->GetBitmap(34,Image4->Picture->Bitmap);
          }
          Image4->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Label4->Caption = "4. ������ ������";
          Label4->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button4->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button13->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

          MainForm->ImageList2->GetBitmap(35,Image5->Picture->Bitmap);
          try
          {
             if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon5Path) )
             {
                Image5->Picture->Bitmap->Dormant();
                Image5->Picture->Bitmap->FreeImage();
                Image5->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon5Path);
             }
          }
          catch(...)
          {
             MainForm->ImageList2->GetBitmap(35,Image5->Picture->Bitmap);
          }
          Image5->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Label5->Caption = "5. ������ ������";
          Label5->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button5->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button14->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

          MainForm->ImageList2->GetBitmap(36,Image6->Picture->Bitmap);
          try
          {
             if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon6Path) )
             {
                Image6->Picture->Bitmap->Dormant();
                Image6->Picture->Bitmap->FreeImage();
                Image6->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon6Path);
             }
          }
          catch(...)
          {
             MainForm->ImageList2->GetBitmap(36,Image6->Picture->Bitmap);
          }
          Image6->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Label6->Caption = "6. ��� �����";
          Label6->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button6->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button15->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

          MainForm->ImageList2->GetBitmap(56,Image7->Picture->Bitmap);
          try
          {
             if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon7Path) )
             {
                Image7->Picture->Bitmap->Dormant();
                Image7->Picture->Bitmap->FreeImage();
                Image7->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon7Path);
             }
          }
          catch(...)
          {
             MainForm->ImageList2->GetBitmap(56,Image6->Picture->Bitmap);
          }
          Image7->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Label7->Caption = "7. ������� �� ���������";
          Label7->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button7->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button16->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      }
      else if( PCfgObj(MainForm->ObjTree->Selected->Data)->ConnectBlock ) 
      {
          MainForm->ImageList2->GetBitmap(57,Image1->Picture->Bitmap);
          try
          {
             if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon1Path) )
             {
                Image1->Picture->Bitmap->Dormant();
                Image1->Picture->Bitmap->FreeImage();
                Image1->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon1Path);
             }
          }
          catch(...)
          {
             MainForm->ImageList2->GetBitmap(57,Image1->Picture->Bitmap);
          }
          Image1->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Label1->Caption = "1. C�������� ��� ������ ������";
          Label1->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button1->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button10->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

          MainForm->ImageList2->GetBitmap(58,Image2->Picture->Bitmap);
          try
          {
             if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon2Path) )
             {
                Image2->Picture->Bitmap->Dormant();
                Image2->Picture->Bitmap->FreeImage();
                Image2->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon2Path);
             }
          }
          catch(...)
          {
             MainForm->ImageList2->GetBitmap(58,Image2->Picture->Bitmap);
          }
          Image2->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Label2->Caption = "2. �����";
          Label2->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button2->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button11->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

          MainForm->ImageList2->GetBitmap(59,Image3->Picture->Bitmap);
          try
          {
             if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon3Path) )
             {
                Image3->Picture->Bitmap->Dormant();
                Image3->Picture->Bitmap->FreeImage();
                Image3->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon3Path);
             }
          }
          catch(...)
          {
             MainForm->ImageList2->GetBitmap(59,Image3->Picture->Bitmap);
          }
          Image3->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Label3->Caption = "3. �������� ������, ��������� ������";
          Label3->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button3->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button12->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

          MainForm->ImageList2->GetBitmap(60,Image4->Picture->Bitmap);
          try
          {
             if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon4Path) )
             {
                Image4->Picture->Bitmap->Dormant();
                Image4->Picture->Bitmap->FreeImage();
                Image4->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon4Path);
             }
          }
          catch(...)
          {
             MainForm->ImageList2->GetBitmap(60,Image4->Picture->Bitmap);
          }
          Image4->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Label4->Caption = "4. ��� �����";
          Label4->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button4->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
          Button13->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

          Image5->Visible = false;
          Label5->Visible = false;
          Button5->Visible = false;
          Button14->Visible = false;

          Image6->Visible = false;
          Label6->Visible = false;
          Button6->Visible = false;
          Button15->Visible = false;

          Image7->Visible = false;
          Label7->Visible = false;
          Button7->Visible = false;
          Button16->Visible = false;
      }
   }
   else if( PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 4 ||  
            PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 12 || 
            PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 7 ) 
   {
      MainForm->ImageList2->GetBitmap(28,Image1->Picture->Bitmap);
      try
      {
         if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon1Path) )
         {
            Image1->Picture->Bitmap->Dormant();
            Image1->Picture->Bitmap->FreeImage();
            Image1->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon1Path);
         }
      }
      catch(...)
      {
         MainForm->ImageList2->GetBitmap(28,Image1->Picture->Bitmap);
      }
      Image1->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Label1->Caption = "1. ��������� ��� ������ ������";
      Label1->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button1->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button10->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

      MainForm->ImageList2->GetBitmap(29,Image2->Picture->Bitmap);
      try
      {
         if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon2Path) )
         {
            Image2->Picture->Bitmap->Dormant();
            Image2->Picture->Bitmap->FreeImage();
            Image2->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon2Path);
         }
      }
      catch(...)
      {
         MainForm->ImageList2->GetBitmap(29,Image2->Picture->Bitmap);
      }
      Image2->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Label2->Caption = "2. �������";
      Label2->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button2->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button11->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

      MainForm->ImageList2->GetBitmap(30,Image3->Picture->Bitmap);
      try
      {
         if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon3Path) )
         {
            Image3->Picture->Bitmap->Dormant();
            Image3->Picture->Bitmap->FreeImage();
            Image3->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon3Path);
         }
      }
      catch(...)
      {
         MainForm->ImageList2->GetBitmap(30,Image3->Picture->Bitmap);
      }
      Image3->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Label3->Caption = "3. ��������";
      Label3->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button3->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button12->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

      MainForm->ImageList2->GetBitmap(31,Image4->Picture->Bitmap);
      try
      {
         if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon4Path) )
         {
            Image4->Picture->Bitmap->Dormant();
            Image4->Picture->Bitmap->FreeImage();
            Image4->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon4Path);
         }
      }
      catch(...)
      {
         MainForm->ImageList2->GetBitmap(31,Image4->Picture->Bitmap);
      }
      Image4->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Label4->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button4->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button13->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

      Image5->Visible = false;
      Label5->Visible = false;
      Button5->Visible = false;
      Button14->Visible = false;

      Image6->Visible = false;
      Label6->Visible = false;
      Button6->Visible = false;
      Button15->Visible = false;

      Image7->Visible = false;
      Label7->Visible = false;
      Button7->Visible = false;
      Button16->Visible = false;
   }
   else if( PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 24 ||  
            PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 25 ||  
            PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 41 ||  
            PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 42 ||  
            PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 51 ||  
            PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 5  ||  
            PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 6  ||  
            PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 32 )   
   {
      MainForm->ImageList2->GetBitmap(48,Image1->Picture->Bitmap);
      try
      {
         if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon1Path) )
         {
            Image1->Picture->Bitmap->Dormant();
            Image1->Picture->Bitmap->FreeImage();
            Image1->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon1Path);
         }
      }
      catch(...)
      {
         MainForm->ImageList2->GetBitmap(48,Image1->Picture->Bitmap);
      }
      Image1->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Label1->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button1->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button10->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

      MainForm->ImageList2->GetBitmap(37,Image2->Picture->Bitmap);
      try
      {
         if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon2Path) )
         {
            Image2->Picture->Bitmap->Dormant();
            Image2->Picture->Bitmap->FreeImage();
            Image2->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon1Path);
         }
      }
      catch(...)
      {
         MainForm->ImageList2->GetBitmap(37,Image1->Picture->Bitmap);
      }
      Image2->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Label2->Caption = "2. ��������� ������ �� �����";
      Label2->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button2->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button11->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

      Image3->Visible = false;
      Label3->Visible = false;
      Button3->Visible = false;
      Button12->Visible = false;

      Image4->Visible = false;
      Label4->Visible = false;
      Button4->Visible = false;
      Button13->Visible = false;

      Image5->Visible = false;
      Label5->Visible = false;
      Button5->Visible = false;
      Button14->Visible = false;

      Image6->Visible = false;
      Label6->Visible = false;
      Button6->Visible = false;
      Button15->Visible = false;

      Image7->Visible = false;
      Label7->Visible = false;
      Button7->Visible = false;
      Button16->Visible = false;
   }
   else if( PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 14 ||  
            PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 15 ||  
            PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 16 ||  
            PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 17 ||  
            PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 29 ||  
            PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 30 ||  
            PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 31 )   

   {
      if( PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 14 ||
          PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 29 )
          MainForm->ImageList2->GetBitmap(50,Image1->Picture->Bitmap);
      else MainForm->ImageList2->GetBitmap(38,Image1->Picture->Bitmap);

      try
      {
         if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon1Path) )
         {
            Image1->Picture->Bitmap->Dormant();
            Image1->Picture->Bitmap->FreeImage();
            Image1->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon1Path);
         }
      }
      catch(...)
      {
         if( PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 14 ||
             PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 29 )
             MainForm->ImageList2->GetBitmap(50,Image1->Picture->Bitmap);
         else MainForm->ImageList2->GetBitmap(38,Image1->Picture->Bitmap);
      }
      Image1->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Label1->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button1->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button10->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

      if( PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 14 ||
          PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 29 )
          MainForm->ImageList2->GetBitmap(51,Image2->Picture->Bitmap);
      else MainForm->ImageList2->GetBitmap(39,Image2->Picture->Bitmap);

      try
      {
         if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon2Path) )
         {
            Image2->Picture->Bitmap->Dormant();
            Image2->Picture->Bitmap->FreeImage();
            Image2->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon2Path);
         }
      }
      catch(...)
      {
         if( PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 14 ||
             PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 29 )
             MainForm->ImageList2->GetBitmap(51,Image2->Picture->Bitmap);
         else MainForm->ImageList2->GetBitmap(39,Image2->Picture->Bitmap);
      }
      Image2->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Label2->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button2->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button11->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

      if( PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 14 ||
          PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 29 )
          MainForm->ImageList2->GetBitmap(52,Image3->Picture->Bitmap);
      else MainForm->ImageList2->GetBitmap(40,Image3->Picture->Bitmap);
      try
      {
         if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon3Path) )
         {
            Image3->Picture->Bitmap->Dormant();
            Image3->Picture->Bitmap->FreeImage();
            Image3->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon3Path);
         }
      }
      catch(...)
      {
         if( PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 14 ||
             PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 29 )
             MainForm->ImageList2->GetBitmap(52,Image3->Picture->Bitmap);
         else MainForm->ImageList2->GetBitmap(40,Image3->Picture->Bitmap);
      }
      Image3->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Label3->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button3->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button12->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

      if( PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 14 ||
          PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 29 )
          MainForm->ImageList2->GetBitmap(53,Image4->Picture->Bitmap);
      else MainForm->ImageList2->GetBitmap(41,Image4->Picture->Bitmap);

      try
      {
         if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon4Path) )
         {
            Image4->Picture->Bitmap->Dormant();
            Image4->Picture->Bitmap->FreeImage();
            Image4->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon4Path);
         }
      }
      catch(...)
      {
         if( PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 14 ||
             PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 29 )
             MainForm->ImageList2->GetBitmap(53,Image4->Picture->Bitmap);
         else MainForm->ImageList2->GetBitmap(41,Image4->Picture->Bitmap);
      }
      Image4->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Label4->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button4->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button13->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

      if( PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 14 ||
          PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 29 )
          MainForm->ImageList2->GetBitmap(54,Image5->Picture->Bitmap);
      else MainForm->ImageList2->GetBitmap(42,Image5->Picture->Bitmap);
      try
      {
         if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon5Path) )
         {
            Image5->Picture->Bitmap->Dormant();
            Image5->Picture->Bitmap->FreeImage();
            Image5->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon5Path);
         }
      }
      catch(...)
      {
         if( PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 14 ||
             PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 29 )
             MainForm->ImageList2->GetBitmap(54,Image5->Picture->Bitmap);
         else MainForm->ImageList2->GetBitmap(42,Image5->Picture->Bitmap);
      }
      Image5->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Label5->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button5->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button14->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

      Image6->Visible = false;
      Label6->Visible = false;
      Button6->Visible = false;
      Button15->Visible = false;

      Image7->Visible = false;
      Label7->Visible = false;
      Button7->Visible = false;
      Button16->Visible = false;
   }
   else if( PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 26 ||  
            PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 27 ||  
            PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 28 )   

   {
      if( PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 26 )
          MainForm->ImageList2->GetBitmap(50,Image1->Picture->Bitmap);
      else MainForm->ImageList2->GetBitmap(43,Image1->Picture->Bitmap);
      try
      {
         if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon1Path) )
         {
            Image1->Picture->Bitmap->Dormant();
            Image1->Picture->Bitmap->FreeImage();
            Image1->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon1Path);
         }
      }
      catch(...)
      {
         if( PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 26 )
             MainForm->ImageList2->GetBitmap(50,Image1->Picture->Bitmap);
         else MainForm->ImageList2->GetBitmap(43,Image1->Picture->Bitmap);
      }
      Image1->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Label1->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button1->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button10->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

      if( PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 26 )
          MainForm->ImageList2->GetBitmap(51,Image2->Picture->Bitmap);
      else MainForm->ImageList2->GetBitmap(44,Image2->Picture->Bitmap);
      try
      {
         if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon2Path) )
         {
            Image2->Picture->Bitmap->Dormant();
            Image2->Picture->Bitmap->FreeImage();
            Image2->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon2Path);
         }
      }
      catch(...)
      {
         if( PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 26 )
             MainForm->ImageList2->GetBitmap(51,Image2->Picture->Bitmap);
         else MainForm->ImageList2->GetBitmap(44,Image2->Picture->Bitmap);
      }
      Image2->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Label2->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button2->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button11->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

      if( PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 26 )
          MainForm->ImageList2->GetBitmap(52,Image3->Picture->Bitmap);
      else MainForm->ImageList2->GetBitmap(45,Image3->Picture->Bitmap);
      try
      {
         if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon3Path) )
         {
            Image3->Picture->Bitmap->Dormant();
            Image3->Picture->Bitmap->FreeImage();
            Image3->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon3Path);
         }
      }
      catch(...)
      {
         if( PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 26 )
             MainForm->ImageList2->GetBitmap(52,Image3->Picture->Bitmap);
         else MainForm->ImageList2->GetBitmap(45,Image3->Picture->Bitmap);
      }
      Image3->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Label3->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button3->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button12->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

      if( PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 26 )
          MainForm->ImageList2->GetBitmap(53,Image4->Picture->Bitmap);
      else MainForm->ImageList2->GetBitmap(46,Image4->Picture->Bitmap);
      try
      {
         if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon4Path) )
         {
            Image4->Picture->Bitmap->Dormant();
            Image4->Picture->Bitmap->FreeImage();
            Image4->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon4Path);
         }
      }
      catch(...)
      {
         if( PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 26 )
             MainForm->ImageList2->GetBitmap(53,Image4->Picture->Bitmap);
         else MainForm->ImageList2->GetBitmap(46,Image4->Picture->Bitmap);
      }
      Image4->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Label4->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button4->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button13->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

      if( PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 26 )
          MainForm->ImageList2->GetBitmap(54,Image5->Picture->Bitmap);
      else MainForm->ImageList2->GetBitmap(47,Image5->Picture->Bitmap);
      try
      {
         if( FileExists(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon5Path) )
         {
            Image5->Picture->Bitmap->Dormant();
            Image5->Picture->Bitmap->FreeImage();
            Image5->Picture->LoadFromFile(PCfgObj(MainForm->ObjTree->Selected->Data)->Icon5Path);
         }
      }
      catch(...)
      {
         if( PCfgObj(MainForm->ObjTree->Selected->Data)->Type == 26 )
             MainForm->ImageList2->GetBitmap(54,Image5->Picture->Bitmap);
         else MainForm->ImageList2->GetBitmap(47,Image5->Picture->Bitmap);
      }
      Image5->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Label5->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button5->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;
      Button14->Visible = PCfgObj(MainForm->ObjTree->Selected->Data)->IconVisible;

      Image6->Visible = false;
      Label6->Visible = false;
      Button6->Visible = false;
      Button15->Visible = false;

      Image7->Visible = false;
      Label7->Visible = false;
      Button7->Visible = false;
      Button16->Visible = false;
   }
}
void __fastcall TIconDlg::Button9Click(TObject *Sender)
{
   PCfgObj(MainForm->ObjTree->Selected->Data)->Icon1Path = "";
   PCfgObj(MainForm->ObjTree->Selected->Data)->Icon2Path = "";
   PCfgObj(MainForm->ObjTree->Selected->Data)->Icon3Path = "";
   PCfgObj(MainForm->ObjTree->Selected->Data)->Icon4Path = "";
   PCfgObj(MainForm->ObjTree->Selected->Data)->Icon5Path = "";
   PCfgObj(MainForm->ObjTree->Selected->Data)->Icon6Path = "";
   PCfgObj(MainForm->ObjTree->Selected->Data)->Icon7Path = "";
   PCfgObj(MainForm->ObjTree->Selected->Data)->Icon8Path = "";

   LoadIcons();
}
void __fastcall TIconDlg::Button10Click(TObject *Sender)
{
   PCfgObj(MainForm->ObjTree->Selected->Data)->Icon1Path = "";

   LoadIcons();
}
void __fastcall TIconDlg::Button11Click(TObject *Sender)
{
   PCfgObj(MainForm->ObjTree->Selected->Data)->Icon2Path = "";

   LoadIcons();
}
void __fastcall TIconDlg::Button12Click(TObject *Sender)
{
   PCfgObj(MainForm->ObjTree->Selected->Data)->Icon3Path = "";

   LoadIcons();
}
void __fastcall TIconDlg::Button13Click(TObject *Sender)
{
   PCfgObj(MainForm->ObjTree->Selected->Data)->Icon4Path = "";

   LoadIcons();
}
void __fastcall TIconDlg::Button14Click(TObject *Sender)
{
   PCfgObj(MainForm->ObjTree->Selected->Data)->Icon5Path = "";

   LoadIcons();
}
void __fastcall TIconDlg::Button15Click(TObject *Sender)
{
   PCfgObj(MainForm->ObjTree->Selected->Data)->Icon6Path = "";

   LoadIcons();
}
void __fastcall TIconDlg::Button16Click(TObject *Sender)
{
   PCfgObj(MainForm->ObjTree->Selected->Data)->Icon7Path = "";

   LoadIcons();
}
void __fastcall TIconDlg::Button8Click(TObject *Sender)
{
   
   if( OpenPictureDialog1->Execute() )
   {
      if ( FileExists(OpenPictureDialog1->FileName) )
      {
         AnsiString FileName;

         FileName = ExtractFilePath(OpenPictureDialog1->FileName) + "1.ico";
         if( FileExists(FileName) )
         {
            Image1->Picture->LoadFromFile(FileName);
            PCfgObj(MainForm->ObjTree->Selected->Data)->Icon1Path = FileName;
         }
         FileName = ExtractFilePath(OpenPictureDialog1->FileName) + "2.ico";
         if( FileExists(FileName) )
         {
            Image2->Picture->LoadFromFile(FileName);
            PCfgObj(MainForm->ObjTree->Selected->Data)->Icon2Path = FileName;
         }
         FileName = ExtractFilePath(OpenPictureDialog1->FileName) + "3.ico";
         if( FileExists(FileName) )
         {
            Image3->Picture->LoadFromFile(FileName);
            PCfgObj(MainForm->ObjTree->Selected->Data)->Icon3Path = FileName;
         }
         FileName = ExtractFilePath(OpenPictureDialog1->FileName) + "4.ico";
         if( FileExists(FileName) )
         {
            Image4->Picture->LoadFromFile(FileName);
            PCfgObj(MainForm->ObjTree->Selected->Data)->Icon4Path = FileName;
         }
         FileName = ExtractFilePath(OpenPictureDialog1->FileName) + "5.ico";
         if( FileExists(FileName) )
         {
            Image5->Picture->LoadFromFile(FileName);
            PCfgObj(MainForm->ObjTree->Selected->Data)->Icon5Path = FileName;
         }
         FileName = ExtractFilePath(OpenPictureDialog1->FileName) + "6.ico";
         if( FileExists(FileName) )
         {
            Image6->Picture->LoadFromFile(FileName);
            PCfgObj(MainForm->ObjTree->Selected->Data)->Icon6Path = FileName;
         }
         FileName = ExtractFilePath(OpenPictureDialog1->FileName) + "7.ico";
         if( FileExists(FileName) )
         {
            Image7->Picture->LoadFromFile(FileName);
            PCfgObj(MainForm->ObjTree->Selected->Data)->Icon7Path = FileName;
         }
      }
   }
}
void __fastcall TIconDlg::Button2Click(TObject *Sender)
{
   if( OpenPictureDialog1->Execute() )
   {
      if ( FileExists(OpenPictureDialog1->FileName) )
      {
         Image2->Picture->LoadFromFile(OpenPictureDialog1->FileName);
         PCfgObj(MainForm->ObjTree->Selected->Data)->Icon2Path = OpenPictureDialog1->FileName;
      }
   }
}
void __fastcall TIconDlg::Button3Click(TObject *Sender)
{
   if( OpenPictureDialog1->Execute() )
   {
      if ( FileExists(OpenPictureDialog1->FileName) )
      {
         Image3->Picture->LoadFromFile(OpenPictureDialog1->FileName);
         PCfgObj(MainForm->ObjTree->Selected->Data)->Icon3Path = OpenPictureDialog1->FileName;
      }
   }
}
void __fastcall TIconDlg::Button4Click(TObject *Sender)
{
   if( OpenPictureDialog1->Execute() )
   {
      if ( FileExists(OpenPictureDialog1->FileName) )
      {
         Image4->Picture->LoadFromFile(OpenPictureDialog1->FileName);
         PCfgObj(MainForm->ObjTree->Selected->Data)->Icon4Path = OpenPictureDialog1->FileName;
      }
   }
}
void __fastcall TIconDlg::Button5Click(TObject *Sender)
{
   if( OpenPictureDialog1->Execute() )
   {
      if ( FileExists(OpenPictureDialog1->FileName) )
      {
         Image5->Picture->LoadFromFile(OpenPictureDialog1->FileName);
         PCfgObj(MainForm->ObjTree->Selected->Data)->Icon5Path = OpenPictureDialog1->FileName;
      }
   }
}
void __fastcall TIconDlg::Button6Click(TObject *Sender)
{
   if( OpenPictureDialog1->Execute() )
   {
      if ( FileExists(OpenPictureDialog1->FileName) )
      {
         Image6->Picture->LoadFromFile(OpenPictureDialog1->FileName);
         PCfgObj(MainForm->ObjTree->Selected->Data)->Icon6Path = OpenPictureDialog1->FileName;
      }
   }
}
void __fastcall TIconDlg::Button7Click(TObject *Sender)
{
   if( OpenPictureDialog1->Execute() )
   {
      if ( FileExists(OpenPictureDialog1->FileName) )
      {
         Image7->Picture->LoadFromFile(OpenPictureDialog1->FileName);
         PCfgObj(MainForm->ObjTree->Selected->Data)->Icon7Path = OpenPictureDialog1->FileName;
      }
   }
}

