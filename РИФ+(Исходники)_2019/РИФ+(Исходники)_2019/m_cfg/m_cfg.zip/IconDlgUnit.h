//----------------------------------------------------------------------------
#ifndef IconDlgUnitH
#define IconDlgUnitH
//----------------------------------------------------------------------------
#include <vcl\System.hpp>
#include <vcl\Windows.hpp>
#include <vcl\SysUtils.hpp>
#include <vcl\Classes.hpp>
#include <vcl\Graphics.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\Controls.hpp>
#include <vcl\Buttons.hpp>
#include <vcl\ExtCtrls.hpp>
#include <Dialogs.hpp>
#include <ExtDlgs.hpp>
#include <ImgList.hpp>
//----------------------------------------------------------------------------
#define Ico_Unknown 0
#define Ico_Norma 1
#define Ico_Alarm 2
#define Ico_Warning 3
#define Ico_Defect 4
#define Ico_Up 20
#define Ico_Down 21
//----------------------------------------------------------------------------
class TIconDlg : public TForm
{
__published:
	TButton *CancelBtn;
   TOpenPictureDialog *OpenPictureDialog1;
   TGroupBox *GroupBox3;
   TComboBox *ComboBox1;
   TLabel *Label0;
   TImage *Image1;
   TLabel *Label1;
   TButton *Button1;
   TLabel *Label2;
   TImage *Image2;
   TButton *Button2;
   TLabel *Label3;
   TImage *Image3;
   TButton *Button3;
   TLabel *Label4;
   TImage *Image4;
   TButton *Button4;
   TLabel *Label5;
   TImage *Image5;
   TButton *Button5;
   TLabel *Label6;
   TImage *Image6;
   TButton *Button6;
   TLabel *Label7;
   TImage *Image7;
   TButton *Button7;
   TButton *Button8;
   TButton *Button9;
   TButton *Button10;
   TButton *Button11;
   TButton *Button12;
   TButton *Button13;
   TButton *Button14;
   TButton *Button15;
   TButton *Button16;
   void __fastcall FormCreate(TObject *Sender);
   void __fastcall ComboBox1Change(TObject *Sender);
   void __fastcall Button1Click(TObject *Sender);
   void __fastcall Button9Click(TObject *Sender);
   void __fastcall Button10Click(TObject *Sender);
   void __fastcall Button11Click(TObject *Sender);
   void __fastcall Button12Click(TObject *Sender);
   void __fastcall Button13Click(TObject *Sender);
   void __fastcall Button14Click(TObject *Sender);
   void __fastcall Button15Click(TObject *Sender);
   void __fastcall Button16Click(TObject *Sender);
   void __fastcall Button8Click(TObject *Sender);
   void __fastcall Button2Click(TObject *Sender);
   void __fastcall Button3Click(TObject *Sender);
   void __fastcall Button4Click(TObject *Sender);
   void __fastcall Button5Click(TObject *Sender);
   void __fastcall Button6Click(TObject *Sender);
   void __fastcall Button7Click(TObject *Sender);
private:
public:
	virtual __fastcall TIconDlg(TComponent* AOwner);

   void LoadIcons();
};
//----------------------------------------------------------------------------
extern PACKAGE TIconDlg *IconDlg;
//----------------------------------------------------------------------------
#endif    
