//---------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "TChooseVersionDlgUnit.h"
#include "MainUnit.h"
//---------------------------------------------------------------------
#pragma resource "*.dfm"
TChooseVersionDlg *ChooseVersionDlg;
//---------------------------------------------------------------------
__fastcall TChooseVersionDlg::TChooseVersionDlg(TComponent* AOwner)
	: TForm(AOwner)
{
}
//---------------------------------------------------------------------

