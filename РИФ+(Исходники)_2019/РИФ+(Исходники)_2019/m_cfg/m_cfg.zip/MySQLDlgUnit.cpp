#include <vcl.h>
#pragma hdrstop

#include "MainUnit.h"
#include "MySQLDlgUnit.h"
#include "UserDlgUnit.h"
#pragma link "AdvGrid"
#pragma link "BaseGrid"
#pragma resource "*.dfm"
TMySQLDlg *MySQLDlg;
__fastcall TMySQLDlg::TMySQLDlg(TComponent* AOwner)
	: TForm(AOwner)
{
}
void __fastcall TMySQLDlg::FormCreate(TObject *Sender)
{
   Caption = MainForm->GroupBox12->Caption;
   GroupBox1->Caption = MainForm->MCFGInfoStr67;
   AdvStringGrid1->RowCount = 2;
   AdvStringGrid1->Cells[0][0] = MainForm->MCFGInfoStr64;
   AdvStringGrid1->Cells[1][0] = MainForm->Label46->Caption;
   AdvStringGrid1->Cells[2][0] = MainForm->MCFGInfoStr64;
   Button1->Caption = MainForm->Button4->Caption;
   Button2->Caption = MainForm->Button6->Caption;
   Button3->Caption = MainForm->Button5->Caption;
   AdvStringGrid2->Cells[0][0] = MainForm->Label62->Caption;
   Label2->Caption = MainForm->Label62->Caption;
   Button4->Caption = MainForm->Button4->Caption;
   Button5->Caption = MainForm->Button6->Caption;
   Button6->Caption = MainForm->MCFGInfoStr69;

   Label1->Visible = false;
   GroupBox1->Visible = true;
   GroupBox1->Enabled = true;
   GroupBox2->Visible = true;
   GroupBox2->Enabled = true;

   AnsiString err_str;
   AnsiString server = MainForm->Edit6->Text;
   int port = MainForm->CSpinEdit11->Value;
   AnsiString login = MainForm->Edit10->Text;
   AnsiString password = MainForm->Edit11->Text;
   AnsiString db_name = "MYSQL";

   Con = mysql_init(NULL);
   mysql_real_connect(Con,server.c_str(),login.c_str(),password.c_str(),db_name.c_str(),port,NULL,0);
   int errcode = mysql_errno(Con);
   if(  errcode != 0 && errcode != CR_ALREADY_CONNECTED )
   {
      err_str.sprintf("%s\n %s:%d\n %s:%s", MainForm->InfoStr2, MainForm->InfoStr3, errcode, MainForm->InfoStr4, mysql_error(Con));
      Label1->Caption = err_str;
      Label1->Visible = true;
      GroupBox1->Visible = false;
      GroupBox1->Enabled = false;
      GroupBox2->Visible = false;
      GroupBox2->Enabled = false;
   }
   else
   {
      ReadUsers();
      ReadDatabases();

      ComboBox1->Items->Clear();
      if( MainForm->ComplexVersion == SsoiComplexType ) db_name = "ssoi_db";
      else db_name = "rif_db";

      for( int i = 0; i < MaxDbCnt; i ++)
      {
         err_str.sprintf("%s%d", db_name, i);
         ComboBox1->Items->Add(err_str);
      }
      ComboBox1->ItemIndex = 0;
   }
}
void __fastcall TMySQLDlg::FormClose(TObject *Sender, TCloseAction &Action)
{
   if( Con != NULL ) mysql_close(Con);
}
void __fastcall TMySQLDlg::AdvStringGrid2GetAlignment(TObject *Sender,
      int ARow, int ACol, TAlignment &HAlign, TVAlignment &VAlign)
{
   if( ARow == 0) HAlign = taCenter;
   else HAlign = taLeftJustify;
}
void __fastcall TMySQLDlg::AdvStringGrid1GetAlignment(TObject *Sender,
      int ARow, int ACol, TAlignment &HAlign, TVAlignment &VAlign)
{
   if( ARow == 0) HAlign = taCenter;
   else HAlign = taLeftJustify;
}
void TMySQLDlg::ReadUsers()
{
   
   AnsiString err_str;
   int errcode;

   AnsiString query = "SHOW COLUMNS FROM MYSQL.USER";
   mysql_real_query(Con,query.c_str(),query.Length());
   Result = mysql_store_result(Con);

   int UserColNum = 0;
   int HostColNum = 0;
   int Select_privColNum = 0;
   int Insert_privColNum = 0;
   int Update_privColNum = 0;
   int Delete_privColNum = 0;
   int Create_privColNum = 0;
   int Drop_privColNum = 0;

   unsigned int num_rows;
   num_rows = mysql_num_rows(Result);
   if( num_rows == 0 )
   {
      errcode = mysql_errno(Con);
      err_str.sprintf("%s\n %s:%d\n %s:%s",  MainForm->InfoStr5, MainForm->InfoStr3, errcode, MainForm->InfoStr4, mysql_error(Con));
      ShowMessage(err_str);
      return;
   }
   else
   {
      for( unsigned int i = 0; i < num_rows; i++)
      {
         row = mysql_fetch_row(Result);
         err_str = AnsiString(row[0]);
         if( err_str.AnsiPos("User") != 0 ) UserColNum = i;
         if( err_str.AnsiPos("Host") != 0 ) HostColNum = i;
         if( err_str.AnsiPos("Select_priv") != 0 ) Select_privColNum = i;
         if( err_str.AnsiPos("Insert_priv") != 0 ) Insert_privColNum = i;
         if( err_str.AnsiPos("Update_priv") != 0 ) Update_privColNum = i;
         if( err_str.AnsiPos("Delete_priv") != 0 ) Delete_privColNum = i;
         if( err_str.AnsiPos("Create_priv") != 0 ) Create_privColNum = i;
         if( err_str.AnsiPos("Drop_privC") != 0 ) Drop_privColNum = i;
      }
   }

   query = "SELECT * FROM MYSQL.USER";
   mysql_real_query(Con,query.c_str(),query.Length());
   Result = mysql_store_result(Con);

   num_rows = mysql_num_rows(Result);
   if( num_rows == 0 )
   {
      errcode = mysql_errno(Con);
      err_str.sprintf("%s\n %s:%d\n %s:%s",  MainForm->InfoStr5, MainForm->InfoStr3, errcode, MainForm->InfoStr4, mysql_error(Con));
      ShowMessage(err_str);
      return;
   }
   else
   {
      AdvStringGrid1->RowCount = num_rows+1;
      AdvStringGrid1->ClearRows(1,num_rows+1);

      for( unsigned int i = 0; i < num_rows; i++)
      {
         row = mysql_fetch_row(Result);
         err_str = AnsiString(row[UserColNum]);
         AdvStringGrid1->Cells[0][i+1] = err_str;

         bool admin = true;
         err_str = AnsiString(row[Select_privColNum]);
         if( err_str.AnsiPos("N") != 0 ) admin = false;
         err_str = AnsiString(row[Insert_privColNum]);
         if( err_str.AnsiPos("N") != 0 ) admin = false;
         err_str = AnsiString(row[Update_privColNum]);
         if( err_str.AnsiPos("N") != 0 ) admin = false;
         err_str = AnsiString(row[Delete_privColNum]);
         if( err_str.AnsiPos("N") != 0 ) admin = false;
         err_str = AnsiString(row[Create_privColNum]);
         if( err_str.AnsiPos("N") != 0 ) admin = false;
         err_str = AnsiString(row[Drop_privColNum]);
         if( err_str.AnsiPos("N") != 0 ) admin = false;
         if( admin ) err_str = MainForm->MCFGInfoStr70;
         else  err_str = "-";
         AdvStringGrid1->Cells[1][i+1] = err_str;

         err_str = AnsiString(row[HostColNum]);
         if( err_str.AnsiPos("%") != 0 ) err_str = MainForm->MCFGInfoStr71;
         else if( err_str.AnsiPos("localhost") != 0 ) err_str = MainForm->MCFGInfoStr72;
         AdvStringGrid1->Cells[2][i+1] = err_str;
      }
   }

   mysql_free_result(Result);
}
void TMySQLDlg::ReadDatabases()
{
   
   AnsiString err_str;
   int errcode;

   AnsiString query = "SHOW DATABASES";
   mysql_real_query(Con,query.c_str(),query.Length());
   Result = mysql_store_result(Con);

   unsigned int num_rows;
   num_rows = mysql_num_rows(Result);
   if( num_rows == 0 )
   {
      errcode = mysql_errno(Con);
      err_str.sprintf("%s\n %s:%d\n %s:%s",  MainForm->InfoStr5, MainForm->InfoStr3, errcode, MainForm->InfoStr4, mysql_error(Con));
      ShowMessage(err_str);
      return;
   }
   else
   {
      AdvStringGrid2->RowCount = num_rows+1;
      AdvStringGrid2->ClearRows(1,num_rows+1);

      int k = 0;
      for( unsigned int i = 0; i < num_rows; i++)
      {
         row = mysql_fetch_row(Result);
         err_str = AnsiString(row[0]);
         if( err_str.Pos("ssoi") != 0 || err_str.Pos("rif") != 0 )
         {
            AdvStringGrid2->Cells[0][k+1] = err_str;
            k = k + 1;
         }
      }
      if( k >= 2 ) AdvStringGrid2->RowCount = k + 1;
      else AdvStringGrid2->RowCount = 2;
   }

   mysql_free_result(Result);
}
void __fastcall TMySQLDlg::Button3Click(TObject *Sender)
{
   
   AnsiString str = AdvStringGrid1->SelectedText();
   if( str.Pos("root") != 0 )
   {
      ShowMessage(MainForm->MCFGInfoStr73);
   }
   else
   {
      Type = 1;

      UserDlg = new TUserDlg(this);
      UserDlg->ShowModal();
      delete UserDlg;
   }
}
void __fastcall TMySQLDlg::Button1Click(TObject *Sender)
{
   
   Type = 2;

   UserDlg = new TUserDlg(this);
   UserDlg->ShowModal();
   delete UserDlg;

   ReadUsers();
}
void __fastcall TMySQLDlg::Button2Click(TObject *Sender)
{
   
   AnsiString str = AdvStringGrid1->Cells[0][AdvStringGrid1->Row];
   if( str.Pos("root") != 0 )
   {
      ShowMessage(MainForm->MCFGInfoStr73);
   }
   else
   {
      Type = 3;

      UserDlg = new TUserDlg(this);
      UserDlg->ShowModal();
      delete UserDlg;

      ReadUsers();
   }
}
void __fastcall TMySQLDlg::Button4Click(TObject *Sender)
{
   
   AnsiString err_str;
   AnsiString query = "CREATE DATABASE " + ComboBox1->Text;
   mysql_real_query(MySQLDlg->Con,query.c_str(),query.Length());
   int errcode = mysql_errno(MySQLDlg->Con);
   if( errcode != 0 ) err_str.sprintf("%s!\n %s:%d\n %s:%s", MainForm->MCFGInfoStr74, MainForm->InfoStr3, errcode, MainForm->InfoStr4, mysql_error(MySQLDlg->Con));
   else
   {
      
      query = "CREATE TABLE IF NOT EXISTS " +  ComboBox1->Text + ".events(\
              event_num INT UNSIGNED,\
              event_dt DATETIME NOT NULL,\
              event_code INT UNSIGNED DEFAULT '0',\
              event_name VARCHAR(30) DEFAULT '',\
              dev_type INT UNSIGNED DEFAULT '0',\
              dev_num1 INT UNSIGNED DEFAULT '0',\
              dev_num2 INT UNSIGNED DEFAULT '0',\
              dev_num3 INT UNSIGNED DEFAULT '0',\
              dev_name VARCHAR(25) DEFAULT '',\
              comment1 VARCHAR(25) DEFAULT '',\
              comment2 VARCHAR(25) DEFAULT '',\
              local_operator_fn VARCHAR(15) DEFAULT '',\
              local_operator_n1 VARCHAR(15) DEFAULT '',\
              local_operator_n2 VARCHAR(15) DEFAULT '',\
              client_operator_fn VARCHAR(15) DEFAULT '',\
              client_operator_n1 VARCHAR(15) DEFAULT '',\
              client_operator_n2 VARCHAR(15) DEFAULT '',\
              out_dev_type INT UNSIGNED DEFAULT '0',\
              PRIMARY KEY(event_num),\
              INDEX(event_dt),\
              INDEX(event_code),\
              INDEX(dev_num1),\
              INDEX(dev_num2),\
              INDEX(dev_num3),\
              INDEX(dev_type,dev_num1,dev_num2,dev_num3),\
              INDEX(out_dev_type,dev_type,dev_num1,dev_num2,dev_num3),\
              INDEX(local_operator_fn,local_operator_n1,local_operator_n2),\
              INDEX(client_operator_fn,client_operator_n1,client_operator_n2))";
      mysql_real_query(MySQLDlg->Con,query.c_str(),query.Length());
      errcode = mysql_errno(MySQLDlg->Con);
      if( errcode != 0 ) err_str.sprintf("%s: EVENTS!\n %s:%d\n %s:%s", MainForm->MCFGInfoStr74, MainForm->InfoStr3, errcode, MainForm->InfoStr4, mysql_error(MySQLDlg->Con));
      else err_str = MainForm->MCFGInfoStr75;
   }
   ShowMessage(err_str);

   ReadDatabases();
}
void __fastcall TMySQLDlg::Button5Click(TObject *Sender)
{
   AnsiString err_str;
   err_str = AdvStringGrid2->Cells[0][AdvStringGrid2->Row];

   if( err_str.Pos("rif_db") != 0 || err_str.Pos("ssoi_db") != 0 )
   {
      if( Application->MessageBox( MainForm->MCFGInfoStr76.c_str(), MainForm->WarningMsg.c_str(), MB_YESNO ) == IDYES )
      {
         

         AnsiString query="DROP DATABASE " + err_str;

         mysql_real_query(MySQLDlg->Con,query.c_str(),query.Length());
         int errcode = mysql_errno(MySQLDlg->Con);
         if( errcode != 0 ) err_str.sprintf("%s!\n %s:%d\n %s:%s", MainForm->MCFGInfoStr77, MainForm->InfoStr3, errcode, MainForm->InfoStr4, mysql_error(MySQLDlg->Con));
         else err_str = MainForm->MCFGInfoStr78;
         ShowMessage(err_str);

         ReadDatabases();
      }
   }
}
void __fastcall TMySQLDlg::Button6Click(TObject *Sender)
{
   MainForm->Edit9->Text = AdvStringGrid2->Cells[0][AdvStringGrid2->Row];
}

