//---------------------------------------------------------------------
#include <vcl.h>
#include <Qt.hpp>
#pragma hdrstop

#include "About485DlgUnit.h"
//--------------------------------------------------------------------- 
#pragma resource "*.dfm"
TAbout485Dlg *About485Dlg;
//---------------------------------------------------------------------
__fastcall TAbout485Dlg::TAbout485Dlg(TComponent* AOwner)
	: TForm(AOwner)
{
}
//---------------------------------------------------------------------
void __fastcall TAbout485Dlg::Image1MouseDown(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
/*
   long SC_DRAGMOVE = 0xF012;
   if( Button == mbLeft )
   {
      ReleaseCapture();
      SendMessage(Handle, WM_SYSCOMMAND, SC_DRAGMOVE, 0);
   }
*/
}
//---------------------------------------------------------------------------
void __fastcall TAbout485Dlg::FormKeyPress(TObject *Sender, char &Key)
{
   Close();
}
//---------------------------------------------------------------------------
void __fastcall TAbout485Dlg::Image1Click(TObject *Sender)
{
   Close();
}
//---------------------------------------------------------------------------

