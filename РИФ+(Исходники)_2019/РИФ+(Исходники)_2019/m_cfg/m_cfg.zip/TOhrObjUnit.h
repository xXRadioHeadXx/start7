#ifndef TOhrObjUnitH
#define TOhrObjUnitH
typedef class SCfgObj
{
public:
   int Type; 
   int Num1; 
   int Num2; 
   int Num3; 

   int Level;  
   AnsiString Name; 

   bool IconVisible;
   int X, Y;   

   AnsiString Icon1Path;
   AnsiString Icon2Path;
   AnsiString Icon3Path;
   AnsiString Icon4Path;
   AnsiString Icon5Path;
   AnsiString Icon6Path;
   AnsiString Icon7Path;
   AnsiString Icon8Path;

   int ImgNum;

   bool Dk;
   bool Bazalt;   
   bool Metka;    
   bool Razriv;   

   int AdamOff;   

   bool UdpUse;   
   AnsiString UdpAdress;
   int UpdPort;

   bool AlarmMsgOn;   

   bool ConnectBlock;

   int OutType; 
   int asoosd_kk, asoosd_nn;

   double lan, lon;
   AnsiString description;

   SCfgObj();

} TCfgObj;
typedef TCfgObj* PCfgObj;
typedef TCfgObj* POprosObj;
struct TOutObj
{
   bool CfgMode;
   char PlanPath[500];
   int FileOperationId;

   int ImgOperationId;
   char ObjName[500];
   char ImgName[500];
   int ImgNum;
   char ImgPath[500];
   int ImgLeft;
   int ImgTop;
   bool IconVisible;

   TOutObj();
};
typedef TOutObj* POutObj;
struct TOprosOutObj
{
   bool OprosMode;
   char PlanPath[500];

   bool IconVisible;
   int X, Y;

   TOprosOutObj();
};
typedef TOprosOutObj* POprosOutObj;
typedef class SRastrObj
{
public:
   int Type; 
   int Num1; 
   int Num2; 

   SRastrObj();
} TRastrObj;
typedef TRastrObj* PRastrObj;
#endif
