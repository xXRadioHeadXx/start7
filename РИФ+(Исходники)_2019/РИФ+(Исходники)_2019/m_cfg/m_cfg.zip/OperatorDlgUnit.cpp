//---------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "OperatorDlgUnit.h"
#include "MainUnit.h"
#include "MyApiUnit.h"
//--------------------------------------------------------------------- 
#pragma resource "*.dfm"
TOperatorDlg *OperatorDlg;
//---------------------------------------------------------------------
__fastcall TOperatorDlg::TOperatorDlg(TComponent* AOwner)
	: TForm(AOwner)
{
}
//---------------------------------------------------------------------
void __fastcall TOperatorDlg::FormCreate(TObject *Sender)
{
   switch( MainForm->OpDlgMode )
   {
      case 1:  Caption = MainForm->Button4->Caption;
               break;
      case 2:  Caption = MainForm->Button5->Caption;
               if( MainForm->OpList->Op[MainForm->AdvStringGrid1->Row-1].FamilyName != "(null)" )
                  Edit1->Text = MainForm->OpList->Op[MainForm->AdvStringGrid1->Row-1].FamilyName;
               if( MainForm->OpList->Op[MainForm->AdvStringGrid1->Row-1].FirstName != "(null)" )
                  Edit2->Text = MainForm->OpList->Op[MainForm->AdvStringGrid1->Row-1].FirstName;
               if( MainForm->OpList->Op[MainForm->AdvStringGrid1->Row-1].SecondName != "(null)" )
                  Edit3->Text = MainForm->OpList->Op[MainForm->AdvStringGrid1->Row-1].SecondName;
               if( MainForm->OpList->Op[MainForm->AdvStringGrid1->Row-1].Password != "(null)" )
                  Password->Text = MainForm->OpList->Op[MainForm->AdvStringGrid1->Row-1].Password;
               break;
      case 3:  Caption = MainForm->Button6->Caption;
               if( MainForm->OpList->Op[MainForm->AdvStringGrid1->Row-1].FamilyName != "(null)" )
                  Edit1->Text = MainForm->OpList->Op[MainForm->AdvStringGrid1->Row-1].FamilyName;
               if( MainForm->OpList->Op[MainForm->AdvStringGrid1->Row-1].FirstName != "(null)" )
                  Edit2->Text = MainForm->OpList->Op[MainForm->AdvStringGrid1->Row-1].FirstName;
               if( MainForm->OpList->Op[MainForm->AdvStringGrid1->Row-1].SecondName != "(null)" )
                  Edit3->Text = MainForm->OpList->Op[MainForm->AdvStringGrid1->Row-1].SecondName;
               if( MainForm->OpList->Op[MainForm->AdvStringGrid1->Row-1].Password != "(null)" )
                  Password->Text = MainForm->OpList->Op[MainForm->AdvStringGrid1->Row-1].Password;
               Edit1->ReadOnly = true;
               Edit1->Color = clBtnFace;
               Edit2->ReadOnly = true;
               Edit2->Color = clBtnFace;
               Edit3->ReadOnly = true;
               Edit3->Color = clBtnFace;
               Password->ReadOnly = true;
               Password->Color = clBtnFace;
               break;
   }

   Label2->Caption = MainForm->AdvStringGrid1->Cells[1][0];
   Label3->Caption = MainForm->AdvStringGrid1->Cells[2][0];
   Label4->Caption = MainForm->AdvStringGrid1->Cells[3][0];
   Label1->Caption = MainForm->AdvStringGrid1->Cells[4][0];

}
//---------------------------------------------------------------------------
void __fastcall TOperatorDlg::OKBtnClick(TObject *Sender)
{
   AnsiString FamilyName, FirstName, SecondName;
   FamilyName = Edit1->Text;
   FirstName = Edit2->Text;
   SecondName = Edit3->Text;
   if( FirstName.Length() == 0 ) FirstName = "(null)";
   if( SecondName.Length() == 0 ) SecondName = "(null)";

   if( MainForm->OpDlgMode == 1 )
   {
      if( FamilyName.Length() == 0 )
      {
         MessageBox (NULL,MainForm->MCFGInfoStr79.c_str(),MainForm->ErrorMsg.c_str(),MB_OK|MB_ICONERROR);
         ModalResult = mrNone;
      }
      else
      {
         if( Password->Text.Length() == 0 )
         {
            MessageBox (NULL,MainForm->MCFGInfoStr80.c_str(),MainForm->ErrorMsg.c_str(),MB_OK|MB_ICONERROR);
            ModalResult = mrNone;
         }
         else
         {
            bool flag = false;
            for( int i = 0; i < MaxOperatorCnt; i++ )
            {
               if( FamilyName == MainForm->OpList->Op[i].FamilyName &&
                   FirstName == MainForm->OpList->Op[i].FirstName &&
                   SecondName == MainForm->OpList->Op[i].SecondName )
               {
                  flag = true;
                  break;
               }
            }

            if( flag )
            {
               MessageBox (NULL,MainForm->MCFGInfoStr81.c_str(),MainForm->ErrorMsg.c_str(),MB_OK|MB_ICONERROR);
               ModalResult = mrNone;
            }
            else
            {
               if( MainForm->OpList->OpCnt < MaxOperatorCnt )
               {
                  MainForm->OpList->Op[MainForm->OpList->OpCnt].FamilyName = FamilyName;
                  MainForm->OpList->Op[MainForm->OpList->OpCnt].FirstName = FirstName;
                  MainForm->OpList->Op[MainForm->OpList->OpCnt].SecondName = SecondName;
                  MainForm->OpList->Op[MainForm->OpList->OpCnt].Password = Password->Text;
                  MainForm->OpList->OpCnt = MainForm->OpList->OpCnt + 1;
                  MainForm->OpList->Sort();

                  MainForm->AdvStringGrid1->RowCount = 2;
                  MainForm->AdvStringGrid1->ClearRows(1,2);

                  for( int i = 0; i <  MainForm->OpList->OpCnt; i++ )
                  {
                     MainForm->AdvStringGrid1->AddRow();
                     MainForm->AdvStringGrid1->Cells[0][i+1] = i+1;
                     MainForm->AdvStringGrid1->Cells[1][i+1] = MainForm->OpList->Op[i].FamilyName;
                     MainForm->AdvStringGrid1->Cells[2][i+1] = MainForm->OpList->Op[i].FirstName;
                     MainForm->AdvStringGrid1->Cells[3][i+1] = MainForm->OpList->Op[i].SecondName;
                     if( MainForm->OpList->Op[i].Password.Length() > 0 )
                        MainForm->AdvStringGrid1->Cells[4][i+1] = "+";
                     else
                        MainForm->AdvStringGrid1->Cells[4][i+1] = "-";
                  }

                  if( MainForm->AdvStringGrid1->RowCount < 2 ) MainForm->AdvStringGrid1->RowCount = 2;
                  MainForm->AdvStringGrid1->FixedRows = 1;
               }
               else
               {
                  MessageBox (NULL,"������ ���������� ����������!",MainForm->ErrorMsg.c_str(),MB_OK|MB_ICONERROR);
                  ModalResult = mrNone;
               }
            }
         }
      }
   }
   else if( MainForm->OpDlgMode == 2 )
   {
      if( FamilyName.Length() == 0 )
      {
         MessageBox (NULL,MainForm->MCFGInfoStr79.c_str(),MainForm->ErrorMsg.c_str(),MB_OK|MB_ICONERROR);
         ModalResult = mrNone;
      }
      else
      {
         if( Password->Text.Length() == 0 )
         {
            MessageBox (NULL,MainForm->MCFGInfoStr80.c_str(),MainForm->ErrorMsg.c_str(),MB_OK|MB_ICONERROR);
            ModalResult = mrNone;
         }
         else
         {
                  MainForm->OpList->Op[MainForm->AdvStringGrid1->Row-1].FamilyName = FamilyName;
                  MainForm->OpList->Op[MainForm->AdvStringGrid1->Row-1].FirstName = FirstName;
                  MainForm->OpList->Op[MainForm->AdvStringGrid1->Row-1].SecondName = SecondName;
                  MainForm->OpList->Op[MainForm->AdvStringGrid1->Row-1].Password = Password->Text;
                  MainForm->OpList->Sort();

                  MainForm->AdvStringGrid1->RowCount = 2;
                  MainForm->AdvStringGrid1->ClearRows(1,2);

                  for( int i = 0; i <  MainForm->OpList->OpCnt; i++ )
                  {
                     MainForm->AdvStringGrid1->AddRow();
                     MainForm->AdvStringGrid1->Cells[0][i+1] = i+1;
                     MainForm->AdvStringGrid1->Cells[1][i+1] = MainForm->OpList->Op[i].FamilyName;
                     MainForm->AdvStringGrid1->Cells[2][i+1] = MainForm->OpList->Op[i].FirstName;
                     MainForm->AdvStringGrid1->Cells[3][i+1] = MainForm->OpList->Op[i].SecondName;
                     if( MainForm->OpList->Op[i].Password.Length() > 0 )
                        MainForm->AdvStringGrid1->Cells[4][i+1] = "+";
                     else
                        MainForm->AdvStringGrid1->Cells[4][i+1] = "-";
                  }

                  if( MainForm->AdvStringGrid1->RowCount < 2 ) MainForm->AdvStringGrid1->RowCount = 2;
                  MainForm->AdvStringGrid1->FixedRows = 1;
         }
      }
   }
   else if( MainForm->OpDlgMode == 3 )
   {
      if( FamilyName.Length() == 0 )
      {
         MessageBox (NULL,MainForm->MCFGInfoStr79.c_str(),MainForm->ErrorMsg.c_str(),MB_OK|MB_ICONERROR);
         ModalResult = mrNone;
      }
      else
      {
         if( Password->Text.Length() == 0 )
         {
            MessageBox (NULL,MainForm->MCFGInfoStr80.c_str(),MainForm->ErrorMsg.c_str(),MB_OK|MB_ICONERROR);
            ModalResult = mrNone;
         }
         else
         {
                  MainForm->OpList->Op[MainForm->AdvStringGrid1->Row-1].FamilyName = "";
                  MainForm->OpList->Op[MainForm->AdvStringGrid1->Row-1].FirstName = "";
                  MainForm->OpList->Op[MainForm->AdvStringGrid1->Row-1].SecondName = "";
                  MainForm->OpList->Op[MainForm->AdvStringGrid1->Row-1].Password = "";
                  MainForm->OpList->OpCnt = MainForm->OpList->OpCnt - 1;
                  MainForm->OpList->Sort();

                  MainForm->AdvStringGrid1->RowCount = 2;
                  MainForm->AdvStringGrid1->ClearRows(1,2);

                  for( int i = 0; i <  MainForm->OpList->OpCnt; i++ )
                  {
                     MainForm->AdvStringGrid1->AddRow();
                     MainForm->AdvStringGrid1->Cells[0][i+1] = i+1;
                     MainForm->AdvStringGrid1->Cells[1][i+1] = MainForm->OpList->Op[i].FamilyName;
                     MainForm->AdvStringGrid1->Cells[2][i+1] = MainForm->OpList->Op[i].FirstName;
                     MainForm->AdvStringGrid1->Cells[3][i+1] = MainForm->OpList->Op[i].SecondName;
                     if( MainForm->OpList->Op[i].Password.Length() > 0 )
                        MainForm->AdvStringGrid1->Cells[4][i+1] = "+";
                     else
                        MainForm->AdvStringGrid1->Cells[4][i+1] = "-";
                  }

                  if( MainForm->AdvStringGrid1->RowCount < 2 ) MainForm->AdvStringGrid1->RowCount = 2;
                  MainForm->AdvStringGrid1->FixedRows = 1;
         }
      }
   }
}
//---------------------------------------------------------------------------
void __fastcall TOperatorDlg::Edit1KeyPress(TObject *Sender, char &Key)
{
   if( Key == ' ' &&
       !isdigit( Key ) &&
       !isalpha( Key ) ) Key = 0;
}
//---------------------------------------------------------------------------
void __fastcall TOperatorDlg::Edit2KeyPress(TObject *Sender, char &Key)
{
   if( Key == ' ' &&
       !isdigit( Key ) &&
       !isalpha( Key ) ) Key = 0;
}
//---------------------------------------------------------------------------
void __fastcall TOperatorDlg::Edit3KeyPress(TObject *Sender, char &Key)
{
   if( Key == ' ' &&
       !isdigit( Key ) &&
       !isalpha( Key ) ) Key = 0;
}
//---------------------------------------------------------------------------
void __fastcall TOperatorDlg::PasswordKeyPress(TObject *Sender, char &Key)
{
   if( Key == ' ' &&
       !isdigit( Key ) &&
       !isalpha( Key ) ) Key = 0;
}
//---------------------------------------------------------------------------

