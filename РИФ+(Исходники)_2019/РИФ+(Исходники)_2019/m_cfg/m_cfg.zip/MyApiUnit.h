//---------------------------------------------------------------------------
#ifndef MyApiUnitH
#define MyApiUnitH
//---------------------------------------------------------------------------
void MyDelay(DWORD msec);
BOOL WeAreAlone (LPSTR szName);
BOOL WeAreAlone1 (LPSTR szName);
bool OsTypeNT();
AnsiString XOR_Crypt(AnsiString in, AnsiString pass);
#endif
