//---------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "UserDlgUnit.h"
#include "MySQLDlgUnit.h"
#include "MainUnit.h"
//---------------------------------------------------------------------
#pragma resource "*.dfm"
TUserDlg *UserDlg;
//---------------------------------------------------------------------
__fastcall TUserDlg::TUserDlg(TComponent* AOwner)
	: TForm(AOwner)
{
}
//---------------------------------------------------------------------
void __fastcall TUserDlg::FormCreate(TObject *Sender)
{
   Caption = MainForm->GroupBox12->Caption;
   Label1->Caption = MySQLDlg->AdvStringGrid1->Cells[0][0];
   Label2->Caption = MySQLDlg->AdvStringGrid1->Cells[1][0];
   Label3->Caption = MySQLDlg->AdvStringGrid1->Cells[1][0] + " (" + MainForm->MCFGInfoStr82 + ")";

   Edit1->Enabled = true;
   Edit1->ReadOnly = false;
   Edit1->Color = clWindow;

   AnsiString str;

   if( MySQLDlg->Type == 1 )
   {
      Edit1->Text = MySQLDlg->AdvStringGrid1->Cells[0][MySQLDlg->AdvStringGrid1->Row];
      Edit1->ReadOnly = true;
      Edit1->Color = clBtnFace;
      Edit1->Enabled = false;
   }
   else if( MySQLDlg->Type == 3 )
   {
      Edit1->Text = MySQLDlg->AdvStringGrid1->Cells[0][MySQLDlg->AdvStringGrid1->Row];
      Edit1->ReadOnly = true;
      Edit1->Color = clBtnFace;
      Edit1->Enabled = false;

      Edit2->ReadOnly = true;
      Edit2->Color = clBtnFace;
      Edit2->Enabled = false;

      Edit3->ReadOnly = true;
      Edit3->Color = clBtnFace;
      Edit3->Enabled = false;
   }
}
//---------------------------------------------------------------------------
void __fastcall TUserDlg::OKBtnClick(TObject *Sender)
{
   AnsiString err_str;
   int errcode;
   AnsiString query;

   if( MySQLDlg->Type == 1 )
   {
      if( Edit2->Text == Edit3->Text )
      {
         query = "SET PASSWORD FOR " + Edit1->Text + "@localhost = PASSWORD(\'" + Edit2->Text + "\')";
         mysql_real_query(MySQLDlg->Con,query.c_str(),query.Length());
         errcode = mysql_errno(MySQLDlg->Con);
         if( errcode != 0 ) err_str.sprintf("%s\n %s:%d\n %s:%s", MainForm->MCFGInfoStr83, MainForm->InfoStr3, errcode,  MainForm->InfoStr4, mysql_error(MySQLDlg->Con));
         else
         {
            query = "SET PASSWORD FOR " + Edit1->Text + "@\'%\' = PASSWORD(\'" + Edit2->Text + "\')";
            mysql_real_query(MySQLDlg->Con,query.c_str(),query.Length());
            errcode = mysql_errno(MySQLDlg->Con);
            if( errcode != 0 ) err_str.sprintf("%s\n %s:%d\n %s:%s", MainForm->MCFGInfoStr83, MainForm->InfoStr3, errcode,  MainForm->InfoStr4, mysql_error(MySQLDlg->Con));
            else err_str = MainForm->MCFGInfoStr84;
         }
         ShowMessage(err_str);
         Close();
      }
      else
      {
         ShowMessage(MainForm->MCFGInfoStr83);
      }
   }
   else if( MySQLDlg->Type == 2 )
   {
      if( !Edit1->Text.IsEmpty() )
      {
         if( Edit2->Text == Edit3->Text )
         {
//            query = "GRANT CREATE,DROP,SELECT,INSERT,DELETE,INDEX,SHOW DATABASES,UPDATE ON *.* TO ";
            query = "GRANT ALL PRIVILEGES ON *.* TO ";
            query = query + Edit1->Text + "@localhost IDENTIFIED BY \'" + Edit2->Text + "\'";
            mysql_real_query(MySQLDlg->Con,query.c_str(),query.Length());
            errcode = mysql_errno(MySQLDlg->Con);
            if( errcode != 0 ) err_str.sprintf("%s\n %s:%d\n %s:%s", MainForm->MCFGInfoStr85, MainForm->InfoStr3, errcode, MainForm->InfoStr4,mysql_error(MySQLDlg->Con));
            else
            {
//               query = "GRANT CREATE,DROP,SELECT,INSERT,DELETE,INDEX,SHOW DATABASES,UPDATE ON *.* TO ";
               query = "GRANT ALL PRIVILEGES ON *.* TO ";
               query = query + Edit1->Text + "@\'%\' IDENTIFIED BY \'" + Edit2->Text + "\'";
               mysql_real_query(MySQLDlg->Con,query.c_str(),query.Length());
               errcode = mysql_errno(MySQLDlg->Con);
               if( errcode != 0 ) err_str.sprintf("%s\n %s:%d\n %s:%s", MainForm->MCFGInfoStr85, MainForm->InfoStr3, errcode, MainForm->InfoStr4,mysql_error(MySQLDlg->Con));
               else
               {
                  err_str = "����� ������������ �� ������!";
               }
            }
            ShowMessage(err_str);
            Close();
         }
         else
         {
            ShowMessage(MainForm->MCFGInfoStr83);
         }
      }
      else
      {
         ShowMessage(MainForm->MCFGInfoStr87);
      }
   }
   else if( MySQLDlg->Type == 3 )
   {
      query="DELETE FROM mysql.user WHERE user=\'" + Edit1->Text + "\'";

      mysql_real_query(MySQLDlg->Con,query.c_str(),query.Length());
      errcode = mysql_errno(MySQLDlg->Con);
      if( errcode != 0 ) err_str.sprintf("%s\n %s:%d\n %s:%s",  MainForm->MCFGInfoStr88, MainForm->InfoStr3, errcode, MainForm->InfoStr4, mysql_error(MySQLDlg->Con));
      else err_str = MainForm->MCFGInfoStr89;
      ShowMessage(err_str);
      Close();
   }
}
//---------------------------------------------------------------------------

