//----------------------------------------------------------------------------
#ifndef MySQLDlgUnitH
#define MySQLDlgUnitH
//----------------------------------------------------------------------------
#include <vcl\System.hpp>
#include <vcl\Windows.hpp>
#include <vcl\SysUtils.hpp>
#include <vcl\Classes.hpp>
#include <vcl\Graphics.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\Controls.hpp>
#include <vcl\Buttons.hpp>
#include <vcl\ExtCtrls.hpp>
#include "AdvGrid.hpp"
#include "BaseGrid.hpp"
#include <Grids.hpp>
#include <mysql.h>
#include <errmsg.h>
//----------------------------------------------------------------------------
#define MaxDbCnt 4
//----------------------------------------------------------------------------
class TMySQLDlg : public TForm
{
__published:
	TButton *CancelBtn;
   TLabel *Label1;
   TGroupBox *GroupBox1;
   TGroupBox *GroupBox2;
   TAdvStringGrid *AdvStringGrid1;
   TAdvStringGrid *AdvStringGrid2;
   TButton *Button1;
   TButton *Button2;
   TButton *Button3;
   TButton *Button4;
   TButton *Button5;
   TComboBox *ComboBox1;
   TLabel *Label2;
   TButton *Button6;
   void __fastcall FormCreate(TObject *Sender);
   void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
   void __fastcall AdvStringGrid2GetAlignment(TObject *Sender, int ARow,
          int ACol, TAlignment &HAlign, TVAlignment &VAlign);
   void __fastcall AdvStringGrid1GetAlignment(TObject *Sender, int ARow,
          int ACol, TAlignment &HAlign, TVAlignment &VAlign);
   void __fastcall Button3Click(TObject *Sender);
   void __fastcall Button1Click(TObject *Sender);
   void __fastcall Button2Click(TObject *Sender);
   void __fastcall Button4Click(TObject *Sender);
   void __fastcall Button5Click(TObject *Sender);
   void __fastcall Button6Click(TObject *Sender);
private:
public:
	virtual __fastcall TMySQLDlg(TComponent* AOwner);

   int Type;

   void ReadUsers();
   void ReadDatabases();

   MYSQL *Con;
   MYSQL_RES *Result;
   MYSQL_ROW row;
};
//----------------------------------------------------------------------------
extern PACKAGE TMySQLDlg *MySQLDlg;
//----------------------------------------------------------------------------
#endif    
