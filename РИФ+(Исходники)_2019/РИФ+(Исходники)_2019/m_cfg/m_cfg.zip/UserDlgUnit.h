//----------------------------------------------------------------------------
#ifndef UserDlgUnitH
#define UserDlgUnitH
//----------------------------------------------------------------------------
#include <vcl\System.hpp>
#include <vcl\Windows.hpp>
#include <vcl\SysUtils.hpp>
#include <vcl\Classes.hpp>
#include <vcl\Graphics.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\Controls.hpp>
#include <vcl\Buttons.hpp>
#include <vcl\ExtCtrls.hpp>
//----------------------------------------------------------------------------
class TUserDlg : public TForm
{
__published:        
	TButton *OKBtn;
	TButton *CancelBtn;
	TBevel *Bevel1;
   TLabel *Label1;
   TEdit *Edit1;
   TLabel *Label2;
   TEdit *Edit2;
   TLabel *Label3;
   TEdit *Edit3;
   void __fastcall FormCreate(TObject *Sender);
   void __fastcall OKBtnClick(TObject *Sender);
private:
public:
	virtual __fastcall TUserDlg(TComponent* AOwner);
};
//----------------------------------------------------------------------------
extern PACKAGE TUserDlg *UserDlg;
//----------------------------------------------------------------------------
#endif    
